"""Shared helpers used across blueprints and templates."""

import io
import uuid
import warnings
from dataclasses import dataclass
from datetime import date, timedelta, timezone
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit

from flask import current_app
from PIL import Image, ImageOps, UnidentifiedImageError
from werkzeug.security import safe_join

# Nigeria uses West Africa Time (UTC+1) all year, with no daylight saving.
WAT = timezone(timedelta(hours=1), "WAT")


def to_wat(value):
    """Convert a naive UTC datetime (as stored) to West Africa Time."""
    if value is None:
        return None
    return value.replace(tzinfo=timezone.utc).astimezone(WAT)


def wat_to_utc(value):
    """Convert a naive West Africa Time datetime (from a form) to naive UTC."""
    if value is None:
        return None
    return value.replace(tzinfo=WAT).astimezone(timezone.utc).replace(tzinfo=None)


def format_datetime(value, fmt="%d %b %Y, %H:%M"):
    local = to_wat(value)
    return f"{local.strftime(fmt)} WAT" if local else "—"


def format_date(value, fmt="%d %b %Y"):
    return value.strftime(fmt) if value else "—"


def is_safe_redirect(target):
    """Allow only relative, same-site paths (blocks //evil.com and http://...)."""
    if not target or "\\" in target:
        return False
    parts = urlsplit(target)
    return not parts.scheme and not parts.netloc and target.startswith("/") \
        and not target.startswith("//")


# --------------------------------------------------------------------------
# Image uploads
# --------------------------------------------------------------------------

# Pillow format name -> (file extension, MIME type)
IMAGE_FORMATS = {
    "JPEG": ("jpg", "image/jpeg"),
    "PNG": ("png", "image/png"),
    "WEBP": ("webp", "image/webp"),
}
MAX_IMAGE_PIXELS = 40_000_000  # ~40 megapixels; larger files are refused
THUMBNAIL_SIZE = (480, 480)


class ImageUploadError(ValueError):
    """Raised with a user-friendly message when an upload is rejected."""


@dataclass
class StoredImage:
    relative_path: str
    original_name: str
    content_type: str
    size_bytes: int
    width: int
    height: int


def _extension_of(filename):
    return filename.rsplit(".", 1)[-1].lower() if "." in filename else ""


def save_image(file_storage, subdir):
    """Validate an uploaded image and store it under UPLOAD_FOLDER/subdir.

    - the extension must be an allowed image type;
    - the size must be within MAX_IMAGE_BYTES;
    - Pillow must decode it as a real JPEG, PNG or WebP image;
    - the image is re-encoded, which drops embedded metadata (including any
      GPS location in the photo) and anything appended to the file;
    - the stored filename is random; the user's filename is never used.

    Returns a StoredImage whose relative_path should be saved in the database.
    """
    config = current_app.config
    original_name = (file_storage.filename or "").strip()
    if not original_name:
        raise ImageUploadError("No file was selected.")
    allowed = config["ALLOWED_IMAGE_EXTENSIONS"]
    if _extension_of(original_name) not in allowed:
        raise ImageUploadError(
            "Unsupported file type. Upload a JPEG, PNG or WebP photograph."
        )

    max_bytes = config["MAX_IMAGE_BYTES"]
    data = file_storage.stream.read(max_bytes + 1)
    if not data:
        raise ImageUploadError("The selected file is empty.")
    if len(data) > max_bytes:
        raise ImageUploadError(
            f"The photograph is larger than {max_bytes // (1024 * 1024)} MB."
        )

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(data)) as probe:
                probe.verify()
            image = Image.open(io.BytesIO(data))
            image.load()
    except (UnidentifiedImageError, OSError, SyntaxError, ValueError,
            Image.DecompressionBombWarning, Image.DecompressionBombError):
        raise ImageUploadError("The file is not a valid image or is corrupted.") from None

    if image.format not in IMAGE_FORMATS:
        raise ImageUploadError("Unsupported image format. Upload a JPEG, PNG or WebP photograph.")
    if image.width * image.height > MAX_IMAGE_PIXELS:
        raise ImageUploadError("The image dimensions are too large.")

    fmt = image.format
    extension, content_type = IMAGE_FORMATS[fmt]
    image = ImageOps.exif_transpose(image)  # honour phone camera orientation
    if fmt == "JPEG" and image.mode not in ("RGB", "L"):
        image = image.convert("RGB")

    today = _today_parts()
    relative_dir = PurePosixPath(subdir, *today)
    name = f"{uuid.uuid4().hex}.{extension}"
    relative_path = str(relative_dir / name)
    target = Path(config["UPLOAD_FOLDER"]) / relative_dir
    target.mkdir(parents=True, exist_ok=True)

    full_path = target / name
    _encode(image, fmt, full_path)
    thumb = image.copy()
    thumb.thumbnail(THUMBNAIL_SIZE)
    _encode(thumb, fmt, Path(config["UPLOAD_FOLDER"]) / thumbnail_path(relative_path))

    return StoredImage(
        relative_path=relative_path,
        original_name=Path(original_name).name[:255],
        content_type=content_type,
        size_bytes=full_path.stat().st_size,
        width=image.width,
        height=image.height,
    )


def _today_parts():
    today = date.today()
    return (f"{today.year:04d}", f"{today.month:02d}")


def _encode(image, fmt, path):
    options = {"JPEG": {"quality": 88, "optimize": True},
               "PNG": {"optimize": True},
               "WEBP": {"quality": 85}}[fmt]
    image.save(path, format=fmt, **options)


def thumbnail_path(relative_path):
    path = PurePosixPath(relative_path)
    return str(path.with_name(f"{path.stem}_thumb{path.suffix}"))


def resolve_upload(relative_path):
    """Absolute path for a stored upload, or None if it escapes UPLOAD_FOLDER."""
    if not relative_path:
        return None
    resolved = safe_join(current_app.config["UPLOAD_FOLDER"], relative_path)
    return Path(resolved) if resolved else None


def delete_image_files(relative_path):
    """Remove an image and its thumbnail. Missing files are ignored."""
    for candidate in (relative_path, thumbnail_path(relative_path)):
        path = resolve_upload(candidate)
        if path and path.is_file():
            try:
                path.unlink()
            except OSError:
                current_app.logger.exception("Could not delete upload %s", path)


# --------------------------------------------------------------------------
# CSV
# --------------------------------------------------------------------------

_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def csv_safe(value):
    """Neutralise spreadsheet formula injection (e.g. =HYPERLINK(...)).

    Numbers are returned unchanged so that negative values stay numeric.
    """
    if value is None:
        return ""
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return value
    text = str(value)
    if text.startswith(_FORMULA_PREFIXES):
        return "'" + text
    return text
