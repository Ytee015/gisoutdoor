"""Reference data and geographic helpers for Nigeria."""

DEFAULT_COUNTRY = "Nigeria"

STATE = "state"
TERRITORY = "territory"

# The 36 states plus the Federal Capital Territory, which is a territory,
# not a state.
NIGERIAN_STATES = [
    "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue",
    "Borno", "Cross River", "Delta", "Ebonyi", "Edo", "Ekiti", "Enugu",
    "Gombe", "Imo", "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Kogi",
    "Kwara", "Lagos", "Nasarawa", "Niger", "Ogun", "Ondo", "Osun", "Oyo",
    "Plateau", "Rivers", "Sokoto", "Taraba", "Yobe", "Zamfara",
]
FEDERAL_CAPITAL_TERRITORY = "Federal Capital Territory (FCT), Abuja"

STATES_AND_TERRITORIES = [(name, STATE) for name in NIGERIAN_STATES] + [
    (FEDERAL_CAPITAL_TERRITORY, TERRITORY)
]

# Generous bounding box around Nigeria. Coordinates outside it are almost
# always data-entry mistakes such as swapped latitude and longitude.
NIGERIA_LAT_RANGE = (4.0, 14.0)
NIGERIA_LNG_RANGE = (2.5, 15.0)


def coordinates_in_range(latitude, longitude):
    """True when both values are present and are valid WGS84 coordinates."""
    if latitude is None or longitude is None:
        return False
    try:
        lat, lng = float(latitude), float(longitude)
    except (TypeError, ValueError):
        return False
    return -90 <= lat <= 90 and -180 <= lng <= 180


def coordinates_in_nigeria(latitude, longitude):
    if not coordinates_in_range(latitude, longitude):
        return False
    lat, lng = float(latitude), float(longitude)
    return (
        NIGERIA_LAT_RANGE[0] <= lat <= NIGERIA_LAT_RANGE[1]
        and NIGERIA_LNG_RANGE[0] <= lng <= NIGERIA_LNG_RANGE[1]
    )
