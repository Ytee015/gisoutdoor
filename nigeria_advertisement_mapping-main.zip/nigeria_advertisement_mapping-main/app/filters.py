"""Search / filter parsing shared by the list, map API and reports.

Filters are read from the query string, cleaned, and applied on top of the
caller's *permission-scoped* query, so a filter can only narrow what the
user is already allowed to see.
"""

from datetime import date, datetime, time, timedelta

from sqlalchemy import or_, select

from .extensions import db
from .models import (
    APPROVAL_STATUSES,
    PERMIT_CONDITIONS,
    Advertisement,
    AdvertisementCategory,
    RegulatoryAuthority,
    StateOrTerritory,
    permit_condition_clause,
)

SORT_OPTIONS = {
    "newest": ("Newest first", Advertisement.created_at.desc()),
    "oldest": ("Oldest first", Advertisement.created_at.asc()),
    "code": ("Code", Advertisement.advertisement_code.asc()),
    "title": ("Title A–Z", Advertisement.title.asc()),
    "state": ("State A–Z", Advertisement.state_or_territory.asc()),
    "expiry": ("Permit expiry (soonest)", Advertisement.permit_expiry_date.asc()),
}


def _text(args, key, max_len=100):
    value = (args.get(key) or "").strip()
    return value[:max_len] or None


def _int(args, key):
    try:
        value = int(args.get(key, ""))
        return value if value > 0 else None
    except (TypeError, ValueError):
        return None


def _date(args, key):
    try:
        return date.fromisoformat(args.get(key, ""))
    except (TypeError, ValueError):
        return None


def parse_filters(args):
    """Return a dict of validated filters; unknown or invalid values are dropped."""
    filters = {
        "q": _text(args, "q"),
        "state": _text(args, "state"),
        "city": _text(args, "city"),
        "lga": _text(args, "lga"),
        "category": _int(args, "category"),
        "authority": _int(args, "authority"),
        "approval_status": _text(args, "approval_status"),
        "permit_condition": _text(args, "permit_condition"),
        "photo": _text(args, "photo"),
        "date_from": _date(args, "date_from"),
        "date_to": _date(args, "date_to"),
        "archived": _text(args, "archived"),
    }
    if filters["approval_status"] not in APPROVAL_STATUSES:
        filters["approval_status"] = None
    if filters["permit_condition"] not in PERMIT_CONDITIONS:
        filters["permit_condition"] = None
    if filters["photo"] not in ("with", "without"):
        filters["photo"] = None
    if filters["archived"] not in ("include", "only"):
        filters["archived"] = None
    return filters


def apply_filters(query, filters):
    ad = Advertisement
    if filters.get("q"):
        term = filters["q"]
        query = query.where(or_(
            ad.advertisement_code.icontains(term, autoescape=True),
            ad.title.icontains(term, autoescape=True),
            ad.advertiser_name.icontains(term, autoescape=True),
            ad.full_address.icontains(term, autoescape=True),
            ad.street_or_road.icontains(term, autoescape=True),
            ad.landmark.icontains(term, autoescape=True),
            ad.permit_number.icontains(term, autoescape=True),
        ))
    if filters.get("state"):
        query = query.where(ad.state_or_territory == filters["state"])
    if filters.get("city"):
        query = query.where(ad.city.icontains(filters["city"], autoescape=True))
    if filters.get("lga"):
        query = query.where(ad.lga.icontains(filters["lga"], autoescape=True))
    if filters.get("category"):
        query = query.where(ad.category_id == filters["category"])
    if filters.get("authority"):
        query = query.where(ad.regulatory_authority_id == filters["authority"])
    if filters.get("approval_status"):
        query = query.where(ad.approval_status == filters["approval_status"])
    if filters.get("permit_condition"):
        query = query.where(permit_condition_clause(filters["permit_condition"]))
    if filters.get("photo") == "with":
        query = query.where(ad.photograph_path.is_not(None))
    elif filters.get("photo") == "without":
        query = query.where(ad.photograph_path.is_(None))
    if filters.get("date_from"):
        query = query.where(ad.created_at >= datetime.combine(filters["date_from"], time.min))
    if filters.get("date_to"):
        # inclusive: everything before the start of the following day
        next_day = datetime.combine(filters["date_to"] + timedelta(days=1), time.min)
        query = query.where(ad.created_at < next_day)
    if filters.get("archived") == "only":
        query = query.where(ad.is_archived.is_(True))
    return query


def active_filter_count(filters):
    return sum(1 for key, value in filters.items() if value and key != "archived")


def filter_choices():
    """Option lists for filter drop-downs."""
    return {
        "states": db.session.scalars(select(StateOrTerritory).order_by(StateOrTerritory.name)).all(),
        "categories": db.session.scalars(
            select(AdvertisementCategory).order_by(AdvertisementCategory.name)).all(),
        "authorities": db.session.scalars(
            select(RegulatoryAuthority).order_by(RegulatoryAuthority.name)).all(),
        "approval_statuses": APPROVAL_STATUSES,
        "permit_conditions": PERMIT_CONDITIONS,
    }
