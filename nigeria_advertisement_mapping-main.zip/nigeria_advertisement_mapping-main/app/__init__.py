import os
import secrets
from datetime import date
from pathlib import Path

from flask import Flask, render_template, request, url_for
from flask_wtf.csrf import CSRFError

from config import INSTANCE_DIR, get_config
from .extensions import csrf, db, login_manager, migrate


def create_app(config_name=None, config_overrides=None):
    app = Flask(__name__, instance_path=str(INSTANCE_DIR))
    app.config.from_object(get_config(config_name))
    if config_overrides:
        app.config.update(config_overrides)

    _ensure_directories(app)
    _configure_secret_key(app)

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)

    from . import models  # noqa: F401  (register models with SQLAlchemy)

    @login_manager.user_loader
    def load_user(user_id):
        try:
            return db.session.get(models.User, int(user_id))
        except (TypeError, ValueError):
            return None

    from .cli import register_cli, seed_reference_data

    register_cli(app)
    with app.app_context():
        seed_reference_data()
    _register_blueprints(app)
    _register_error_handlers(app)
    _register_template_helpers(app)
    _register_security_headers(app)
    return app


def _ensure_directories(app):
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    upload_dir = Path(app.config["UPLOAD_FOLDER"]) / app.config["ADVERTISEMENT_UPLOAD_SUBDIR"]
    upload_dir.mkdir(parents=True, exist_ok=True)


def _configure_secret_key(app):
    if app.config.get("SECRET_KEY"):
        return
    if not app.debug and not app.testing:
        raise RuntimeError(
            "SECRET_KEY is not set. Define it in the environment or the .env file "
            "before running in production."
        )
    # Development only: keep a random key in instance/ so sessions survive
    # restarts of the reloader. The file is git-ignored.
    key_file = Path(app.instance_path) / ".dev_secret_key"
    if not key_file.exists():
        key_file.write_text(secrets.token_hex(32))
        os.chmod(key_file, 0o600)
    app.config["SECRET_KEY"] = key_file.read_text().strip()


def _register_blueprints(app):
    from .blueprints.administration import bp as administration_bp
    from .blueprints.advertisements import bp as advertisements_bp
    from .blueprints.auth import bp as auth_bp
    from .blueprints.dashboard import bp as dashboard_bp
    from .blueprints.inspections import bp as inspections_bp
    from .blueprints.map import bp as map_bp
    from .blueprints.reports import bp as reports_bp

    for blueprint in (
        auth_bp, dashboard_bp, advertisements_bp, map_bp, reports_bp,
        administration_bp, inspections_bp,
    ):
        app.register_blueprint(blueprint)


def _register_error_handlers(app):
    @app.errorhandler(403)
    def forbidden(error):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(error):
        return render_template("errors/404.html"), 404

    @app.errorhandler(413)
    def too_large(error):
        max_mb = app.config["MAX_CONTENT_LENGTH"] // (1024 * 1024)
        return render_template(
            "errors/error.html",
            code=413,
            title="Upload too large",
            message=f"The submitted data exceeds the {max_mb} MB limit. "
            "Please choose a smaller photograph and try again.",
        ), 413

    @app.errorhandler(CSRFError)
    def csrf_error(error):
        return render_template(
            "errors/error.html",
            code=400,
            title="Form expired",
            message="Your form session has expired or is invalid. "
            "Please go back, reload the page and try again.",
        ), 400

    @app.errorhandler(500)
    def server_error(error):
        db.session.rollback()
        return render_template("errors/500.html"), 500


def _register_template_helpers(app):
    from .utils import format_date, format_datetime

    app.jinja_env.filters["datetime"] = format_datetime
    app.jinja_env.filters["date"] = format_date

    def url_with(**overrides):
        """Current URL with some query-string values replaced (None removes)."""
        args = request.args.to_dict()
        for key, value in overrides.items():
            if value is None or value == "":
                args.pop(key, None)
            else:
                args[key] = value
        return url_for(request.endpoint, **(request.view_args or {}), **args)

    app.jinja_env.globals["url_with"] = url_with

    @app.context_processor
    def inject_globals():
        return {
            "app_name": app.config["APP_NAME"],
            "current_year": date.today().year,
            "map_default_center": app.config["MAP_DEFAULT_CENTER"],
            "map_default_zoom": app.config["MAP_DEFAULT_ZOOM"],
        }


def _register_security_headers(app):
    @app.after_request
    def set_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        return response
