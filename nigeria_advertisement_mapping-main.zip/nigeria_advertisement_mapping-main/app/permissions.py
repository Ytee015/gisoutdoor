"""Server-side access rules. Every route uses these; the UI only mirrors them."""

from sqlalchemy import false, select

from .models import (
    Advertisement,
    InspectionAssignment,
)


def visible_advertisements_query(user, include_archived=False):
    """SELECT of the advertisements ``user`` may see."""
    query = select(Advertisement)
    if not user or not user.is_authenticated:
        return query.where(false())
    if user.is_admin:
        if not include_archived:
            query = query.where(Advertisement.is_archived.is_(False))
        return query
    if user.is_staff:
        # Staff see only what they submitted; archived records are hidden.
        return query.where(
            Advertisement.submitted_by_id == user.id,
            Advertisement.is_archived.is_(False),
        )
    if user.is_inspector:
        assigned = select(InspectionAssignment.advertisement_id)
        if not user.can_view_all_inspections:
            assigned = assigned.where(InspectionAssignment.inspector_id == user.id)
        return query.where(Advertisement.id.in_(assigned))
    return query.where(false())


def can_view_advertisement(user, advertisement):
    if not user or not user.is_authenticated or advertisement is None:
        return False
    if user.is_admin:
        return True
    if user.is_staff:
        return advertisement.submitted_by_id == user.id and not advertisement.is_archived
    if user.is_inspector:
        return any(
            user.can_view_all_inspections or a.inspector_id == user.id
            for a in advertisement.inspection_assignments
        )
    return False


def can_edit_advertisement(user, advertisement):
    if not can_view_advertisement(user, advertisement) or advertisement.is_archived:
        return False
    if user.is_admin:
        return True
    if user.is_staff:
        return advertisement.is_editable_by_submitter
    return False


def can_view_inspection(user, assignment):
    """Read access to an assignment and its records."""
    if not user or not user.is_authenticated or assignment is None:
        return False
    if user.is_admin:
        return True
    if user.is_inspector:
        return assignment.inspector_id == user.id or user.can_view_all_inspections
    return False


def can_work_on_inspection(user, assignment):
    """Start / edit / submit — only the inspector the work is assigned to."""
    return bool(
        user and user.is_authenticated and user.is_inspector
        and assignment is not None and assignment.inspector_id == user.id
    )


def can_view_inspection_record(user, record):
    if not user or not user.is_authenticated or record is None:
        return False
    if user.is_admin:
        return True
    if user.is_inspector:
        return record.inspector_id == user.id or user.can_view_all_inspections
    return False
