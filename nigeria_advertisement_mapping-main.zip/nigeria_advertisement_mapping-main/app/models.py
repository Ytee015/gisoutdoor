from datetime import date, datetime, timedelta, timezone

from flask import current_app, has_app_context
from flask_login import UserMixin
from sqlalchemy import and_, or_
from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db
from .nigeria import DEFAULT_COUNTRY, STATE, TERRITORY, coordinates_in_range


def utcnow():
    """Naive UTC timestamp (SQLite does not store timezone information)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


# --------------------------------------------------------------------------
# Users
# --------------------------------------------------------------------------

ROLE_ADMIN = "admin"
ROLE_STAFF = "staff"
ROLE_INSPECTOR = "inspector"
ROLE_LABELS = {
    ROLE_ADMIN: "Administrator",
    ROLE_STAFF: "Staff",
    ROLE_INSPECTOR: "Inspector",
}


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, default=ROLE_STAFF, index=True)
    phone = db.Column(db.String(30))
    organization = db.Column(db.String(150))
    # Overrides UserMixin.is_active, so Flask-Login refuses deactivated users.
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    # Granted by an administrator: lets an inspector *read* inspections that
    # are assigned to other inspectors. It never allows submitting for them.
    can_view_all_inspections = db.Column(
        db.Boolean, nullable=False, default=False, server_default=db.false()
    )
    last_login_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=utcnow, onupdate=utcnow)

    submitted_advertisements = db.relationship(
        "Advertisement",
        foreign_keys="Advertisement.submitted_by_id",
        back_populates="submitted_by",
    )

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def is_admin(self):
        return self.role == ROLE_ADMIN

    @property
    def is_staff(self):
        return self.role == ROLE_STAFF

    @property
    def is_inspector(self):
        return self.role == ROLE_INSPECTOR

    @property
    def role_label(self):
        return ROLE_LABELS.get(self.role, self.role.title())

    def __repr__(self):
        return f"<User {self.email} ({self.role})>"


# --------------------------------------------------------------------------
# Locations and reference data
# --------------------------------------------------------------------------

LOCATION_CITY = "city"
LOCATION_LGA = "lga"
LOCATION_ROAD = "road"
LOCATION_LANDMARK = "landmark"
LOCATION_TYPES = {
    LOCATION_CITY: "City / town",
    LOCATION_LGA: "Local Government Area",
    LOCATION_ROAD: "Street / road",
    LOCATION_LANDMARK: "Landmark",
}


class StateOrTerritory(db.Model):
    __tablename__ = "states_and_territories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False, unique=True)
    kind = db.Column(db.String(20), nullable=False, default=STATE)
    is_active = db.Column(db.Boolean, nullable=False, default=True)

    location_options = db.relationship(
        "LocationOption", back_populates="state", cascade="all, delete-orphan"
    )

    @property
    def is_territory(self):
        return self.kind == TERRITORY

    @property
    def kind_label(self):
        return "Territory" if self.is_territory else "State"

    def __repr__(self):
        return f"<StateOrTerritory {self.name}>"


class LocationOption(db.Model):
    """Admin-configurable suggestion lists (cities, LGAs, roads, landmarks).

    Advertisement forms offer these as suggestions but still accept free
    text, since no predefined list can be complete.
    """

    __tablename__ = "location_options"
    __table_args__ = (
        db.UniqueConstraint("state_id", "location_type", "name", name="uq_location_option"),
    )

    id = db.Column(db.Integer, primary_key=True)
    state_id = db.Column(
        db.Integer, db.ForeignKey("states_and_territories.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )
    location_type = db.Column(db.String(20), nullable=False, index=True)
    name = db.Column(db.String(150), nullable=False)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)

    state = db.relationship("StateOrTerritory", back_populates="location_options")

    @property
    def type_label(self):
        return LOCATION_TYPES.get(self.location_type, self.location_type)


class AdvertisementCategory(db.Model):
    __tablename__ = "advertisement_categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)

    advertisements = db.relationship("Advertisement", back_populates="category")

    def __repr__(self):
        return f"<AdvertisementCategory {self.name}>"


class RegulatoryAuthority(db.Model):
    __tablename__ = "regulatory_authorities"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False, unique=True)
    jurisdiction = db.Column(db.String(150))
    state_or_territory = db.Column(db.String(80), index=True)
    contact_email = db.Column(db.String(120))
    contact_phone = db.Column(db.String(30))
    website = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)

    advertisements = db.relationship("Advertisement", back_populates="regulatory_authority")

    def __repr__(self):
        return f"<RegulatoryAuthority {self.name}>"


# --------------------------------------------------------------------------
# Advertisements
# --------------------------------------------------------------------------

APPROVAL_PENDING = "pending"
APPROVAL_APPROVED = "approved"
APPROVAL_REJECTED = "rejected"
APPROVAL_SUSPENDED = "suspended"
APPROVAL_STATUSES = {
    APPROVAL_PENDING: ("Pending", "warning"),
    APPROVAL_APPROVED: ("Approved", "success"),
    APPROVAL_REJECTED: ("Rejected", "danger"),
    APPROVAL_SUSPENDED: ("Suspended", "purple"),
}

# What has been done to check the recorded permit. "checked" means an
# administrator has sighted the permit document; the system cannot prove
# that a permit is authentic.
PERMIT_UNVERIFIED = "unverified"
PERMIT_PENDING_VERIFICATION = "pending_verification"
PERMIT_CHECKED = "checked"
PERMIT_VERIFICATION_STATUSES = {
    PERMIT_UNVERIFIED: "Unverified",
    PERMIT_PENDING_VERIFICATION: "Pending verification",
    PERMIT_CHECKED: "Checked by administrator",
}

ADVERTISEMENT_TYPES = {
    "static": "Static / printed",
    "digital": "Digital / LED",
    "illuminated": "Illuminated / backlit",
    "painted": "Painted",
    "other": "Other",
}

PHYSICAL_CONDITIONS = {
    "good": "Good",
    "fair": "Fair",
    "poor": "Poor",
    "damaged": "Damaged",
    "under_maintenance": "Under maintenance",
    "not_installed": "Not yet installed",
}


# Permit *condition* is always calculated from the stored permit data and the
# current date — it is never stored, so it cannot go stale.
PERMIT_VALID = "valid"
PERMIT_EXPIRING_SOON = "expiring_soon"
PERMIT_EXPIRED = "expired"
PERMIT_MISSING = "missing"
PERMIT_CONDITIONS = {
    PERMIT_VALID: ("Valid", "success"),
    PERMIT_EXPIRING_SOON: ("Expiring soon", "warning"),
    PERMIT_EXPIRED: ("Expired", "danger"),
    PERMIT_MISSING: ("Missing information", "secondary"),
    PERMIT_PENDING_VERIFICATION: ("Pending verification", "info"),
    PERMIT_UNVERIFIED: ("Unverified", "light"),
}


def permit_warning_days():
    if has_app_context():
        return int(current_app.config.get("PERMIT_EXPIRY_WARNING_DAYS", 30))
    return 30


def compute_permit_condition(permit_number, expiry_date, verification_status,
                             today=None, warning_days=None):
    """Return the permit condition key for the given stored values.

    Order of precedence: missing data, then expiry (expired / expiring soon),
    then the verification state. A permit is only "valid" when its dates are
    current *and* an administrator has recorded checking it.
    """
    today = today or date.today()
    warning_days = permit_warning_days() if warning_days is None else warning_days
    if not (permit_number or "").strip() or expiry_date is None:
        return PERMIT_MISSING
    if expiry_date < today:
        return PERMIT_EXPIRED
    if expiry_date <= today + timedelta(days=warning_days):
        return PERMIT_EXPIRING_SOON
    if verification_status == PERMIT_CHECKED:
        return PERMIT_VALID
    if verification_status == PERMIT_PENDING_VERIFICATION:
        return PERMIT_PENDING_VERIFICATION
    return PERMIT_UNVERIFIED


def permit_condition_clause(condition, today=None, warning_days=None):
    """SQL expression equivalent to compute_permit_condition() == condition."""
    today = today or date.today()
    warning_days = permit_warning_days() if warning_days is None else warning_days
    soon = today + timedelta(days=warning_days)
    ad = Advertisement
    missing = or_(
        ad.permit_number.is_(None), db.func.trim(ad.permit_number) == "",
        ad.permit_expiry_date.is_(None),
    )
    present = and_(
        ad.permit_number.is_not(None), db.func.trim(ad.permit_number) != "",
        ad.permit_expiry_date.is_not(None),
    )
    far = and_(present, ad.permit_expiry_date > soon)
    clauses = {
        PERMIT_MISSING: missing,
        PERMIT_EXPIRED: and_(present, ad.permit_expiry_date < today),
        PERMIT_EXPIRING_SOON: and_(
            present, ad.permit_expiry_date >= today, ad.permit_expiry_date <= soon
        ),
        PERMIT_VALID: and_(far, ad.permit_verification_status == PERMIT_CHECKED),
        PERMIT_PENDING_VERIFICATION: and_(
            far, ad.permit_verification_status == PERMIT_PENDING_VERIFICATION
        ),
        PERMIT_UNVERIFIED: and_(
            far,
            ad.permit_verification_status.not_in([PERMIT_CHECKED, PERMIT_PENDING_VERIFICATION]),
        ),
    }
    return clauses[condition]


class AdvertisementCodeSequence(db.Model):
    """Per-year counter used to issue ADV-YYYY-NNNN codes.

    Incrementing a stored counter (instead of counting rows) keeps codes
    unique even after records are deleted.
    """

    __tablename__ = "advertisement_code_sequences"

    year = db.Column(db.Integer, primary_key=True, autoincrement=False)
    last_value = db.Column(db.Integer, nullable=False, default=0)


class Advertisement(db.Model):
    __tablename__ = "advertisements"

    id = db.Column(db.Integer, primary_key=True)
    advertisement_code = db.Column(db.String(20), nullable=False, unique=True, index=True)

    # Basic information
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    category_id = db.Column(
        db.Integer, db.ForeignKey("advertisement_categories.id"), nullable=False, index=True
    )
    advertiser_name = db.Column(db.String(150), nullable=False, index=True)
    contact_person = db.Column(db.String(120))
    contact_phone = db.Column(db.String(30))

    # Geographical information
    country = db.Column(db.String(60), nullable=False, default=DEFAULT_COUNTRY)
    state_or_territory = db.Column(db.String(80), nullable=False, index=True)
    city = db.Column(db.String(100), index=True)
    lga = db.Column(db.String(100), index=True)
    street_or_road = db.Column(db.String(150))
    full_address = db.Column(db.String(255))
    landmark = db.Column(db.String(150))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)

    # Advertisement details
    advertisement_type = db.Column(db.String(30))
    width = db.Column(db.Float)  # metres
    height = db.Column(db.Float)  # metres
    installation_date = db.Column(db.Date)
    condition = db.Column(db.String(30))
    photograph_path = db.Column(db.String(255))

    # Permit information (recorded, not issued, by this system)
    permit_number = db.Column(db.String(80), index=True)
    regulatory_authority_id = db.Column(
        db.Integer, db.ForeignKey("regulatory_authorities.id"), index=True
    )
    permit_issue_date = db.Column(db.Date)
    permit_expiry_date = db.Column(db.Date, index=True)
    permit_verification_status = db.Column(
        db.String(30), nullable=False, default=PERMIT_UNVERIFIED
    )

    # Review workflow
    approval_status = db.Column(
        db.String(20), nullable=False, default=APPROVAL_PENDING, index=True
    )
    review_notes = db.Column(db.Text)
    submitted_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    reviewed_by_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    reviewed_at = db.Column(db.DateTime)

    # Archive instead of delete, so history and files are preserved.
    is_archived = db.Column(db.Boolean, nullable=False, default=False, index=True)
    archived_at = db.Column(db.DateTime)
    archived_by_id = db.Column(db.Integer, db.ForeignKey("users.id"))

    created_at = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)
    updated_at = db.Column(db.DateTime, nullable=False, default=utcnow, onupdate=utcnow)

    category = db.relationship("AdvertisementCategory", back_populates="advertisements")
    regulatory_authority = db.relationship("RegulatoryAuthority", back_populates="advertisements")
    submitted_by = db.relationship(
        "User", foreign_keys=[submitted_by_id], back_populates="submitted_advertisements"
    )
    reviewed_by = db.relationship("User", foreign_keys=[reviewed_by_id])
    archived_by = db.relationship("User", foreign_keys=[archived_by_id])
    history = db.relationship(
        "AdvertisementHistory",
        back_populates="advertisement",
        order_by="AdvertisementHistory.created_at.desc()",
        passive_deletes=True,
    )
    inspection_records = db.relationship(
        "InspectionRecord",
        back_populates="advertisement",
        order_by="InspectionRecord.inspection_date.desc()",
    )
    inspection_assignments = db.relationship(
        "InspectionAssignment",
        back_populates="advertisement",
        order_by="InspectionAssignment.assigned_at.desc()",
    )

    @property
    def approval_status_label(self):
        return APPROVAL_STATUSES.get(self.approval_status, (self.approval_status, "secondary"))[0]

    @property
    def approval_status_badge(self):
        return APPROVAL_STATUSES.get(self.approval_status, (self.approval_status, "secondary"))[1]

    @property
    def permit_condition(self):
        return compute_permit_condition(
            self.permit_number, self.permit_expiry_date, self.permit_verification_status
        )

    @property
    def permit_condition_label(self):
        return PERMIT_CONDITIONS[self.permit_condition][0]

    @property
    def permit_condition_badge(self):
        return PERMIT_CONDITIONS[self.permit_condition][1]

    @property
    def days_until_permit_expiry(self):
        if self.permit_expiry_date is None:
            return None
        return (self.permit_expiry_date - date.today()).days

    @property
    def permit_verification_label(self):
        return PERMIT_VERIFICATION_STATUSES.get(
            self.permit_verification_status, self.permit_verification_status
        )

    @property
    def advertisement_type_label(self):
        return ADVERTISEMENT_TYPES.get(self.advertisement_type)

    @property
    def condition_label(self):
        return PHYSICAL_CONDITIONS.get(self.condition)

    @property
    def has_coordinates(self):
        return coordinates_in_range(self.latitude, self.longitude)

    @property
    def display_address(self):
        if self.full_address:
            return self.full_address
        parts = [self.street_or_road, self.city, self.lga, self.state_or_territory]
        return ", ".join(p for p in parts if p)

    @property
    def is_editable_by_submitter(self):
        return self.approval_status in (APPROVAL_PENDING, APPROVAL_REJECTED) and not self.is_archived

    def __repr__(self):
        return f"<Advertisement {self.advertisement_code}>"


HISTORY_ACTIONS = {
    "created": ("Registered", "primary"),
    "updated": ("Edited", "secondary"),
    "resubmitted": ("Edited and resubmitted for review", "warning"),
    "photo_replaced": ("Photograph replaced", "secondary"),
    "photo_removed": ("Photograph removed", "secondary"),
    "approved": ("Approved", "success"),
    "rejected": ("Rejected", "danger"),
    "suspended": ("Suspended", "purple"),
    "reinstated": ("Suspension lifted", "success"),
    "archived": ("Archived", "dark"),
    "restored": ("Restored from archive", "secondary"),
    "deleted": ("Permanently deleted", "danger"),
    "inspection_assigned": ("Inspection assigned", "info"),
    "inspection_submitted": ("Inspection report submitted", "info"),
}


class AdvertisementHistory(db.Model):
    """Audit trail. Rows survive deletion of the advertisement itself."""

    __tablename__ = "advertisement_history"

    id = db.Column(db.Integer, primary_key=True)
    advertisement_id = db.Column(
        db.Integer, db.ForeignKey("advertisements.id", ondelete="SET NULL"), index=True
    )
    # Copied so the entry stays meaningful if the advertisement is deleted.
    advertisement_code = db.Column(db.String(20), nullable=False, index=True)
    actor_id = db.Column(db.Integer, db.ForeignKey("users.id"), index=True)
    action = db.Column(db.String(40), nullable=False, index=True)
    previous_values = db.Column(db.JSON)
    new_values = db.Column(db.JSON)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)

    advertisement = db.relationship("Advertisement", back_populates="history")
    actor = db.relationship("User")

    @property
    def action_label(self):
        return HISTORY_ACTIONS.get(self.action, (self.action.replace("_", " ").title(), "secondary"))[0]

    @property
    def action_badge(self):
        return HISTORY_ACTIONS.get(self.action, (self.action, "secondary"))[1]


# --------------------------------------------------------------------------
# Field inspections
# --------------------------------------------------------------------------

ASSIGNMENT_ASSIGNED = "assigned"
ASSIGNMENT_IN_PROGRESS = "in_progress"
ASSIGNMENT_COMPLETED = "completed"
ASSIGNMENT_STATUSES = {
    ASSIGNMENT_ASSIGNED: ("Assigned", "primary"),
    ASSIGNMENT_IN_PROGRESS: ("In Progress", "warning"),
    ASSIGNMENT_COMPLETED: ("Completed", "success"),
}

RECORD_DRAFT = "draft"
RECORD_SUBMITTED = "submitted"
RECORD_CORRECTION_REQUESTED = "correction_requested"
RECORD_WITHDRAWN = "withdrawn"  # draft set aside because the inspection was reassigned
RECORD_STATUSES = {
    RECORD_DRAFT: ("Draft", "secondary"),
    RECORD_SUBMITTED: ("Submitted", "success"),
    RECORD_CORRECTION_REQUESTED: ("Correction requested", "warning"),
    RECORD_WITHDRAWN: ("Withdrawn (reassigned)", "dark"),
}

SITE_CONDITIONS = {
    "good": "Good",
    "damaged": "Damaged",
    "unsafe": "Unsafe",
    "removed": "Removed",
    "other": "Other",
}
LOCATION_VERIFICATIONS = {
    "verified": "Verified",
    "location_mismatch": "Location Mismatch",
    "unable_to_verify": "Unable to Verify",
}
DETAILS_VERIFICATIONS = {
    "match": "Match",
    "mismatch": "Mismatch",
    "unable_to_verify": "Unable to Verify",
}
PERMIT_OBSERVATIONS = {
    "appears_valid": "Appears Valid",
    "appears_expired": "Appears Expired",
    "missing_information": "Missing Information",
    "requires_further_verification": "Requires Further Verification",
}
FLAGGED_SITE_CONDITIONS = ("damaged", "unsafe", "removed")
FLAGGED_LOCATION_RESULTS = ("location_mismatch",)

FOLLOW_UP_ACTIONS = {
    "reviewed_no_action": "Reviewed – no action required",
    "advertiser_contacted": "Advertiser contacted",
    "referred_to_authority": "Referred to regulatory authority",
    "reinspection_required": "Re-inspection required",
    "resolved": "Resolved",
    "other": "Other",
}

EVENT_LABELS = {
    "assigned": "Inspection assigned",
    "reassigned": "Inspection reassigned",
    "details_updated": "Assignment details updated",
    "started": "Inspection started",
    "submitted": "Report submitted",
    "correction_requested": "Correction requested",
    "resubmitted": "Corrected report submitted",
    "follow_up": "Administrative follow-up recorded",
}


class InspectionAssignment(db.Model):
    __tablename__ = "inspection_assignments"

    id = db.Column(db.Integer, primary_key=True)
    advertisement_id = db.Column(
        db.Integer, db.ForeignKey("advertisements.id"), nullable=False, index=True
    )
    inspector_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    assigned_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    assigned_at = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)
    due_date = db.Column(db.Date, index=True)
    instructions = db.Column(db.Text)
    status = db.Column(db.String(20), nullable=False, default=ASSIGNMENT_ASSIGNED, index=True)
    started_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    updated_at = db.Column(db.DateTime, nullable=False, default=utcnow, onupdate=utcnow)

    advertisement = db.relationship("Advertisement", back_populates="inspection_assignments")
    inspector = db.relationship("User", foreign_keys=[inspector_id])
    assigned_by = db.relationship("User", foreign_keys=[assigned_by_id])
    records = db.relationship(
        "InspectionRecord",
        back_populates="assignment",
        order_by="InspectionRecord.created_at.desc()",
    )
    events = db.relationship(
        "InspectionEvent",
        back_populates="assignment",
        order_by="InspectionEvent.created_at",
    )

    @property
    def status_label(self):
        return ASSIGNMENT_STATUSES.get(self.status, (self.status, "secondary"))[0]

    @property
    def status_badge(self):
        return ASSIGNMENT_STATUSES.get(self.status, (self.status, "secondary"))[1]

    @property
    def is_open(self):
        return self.status != ASSIGNMENT_COMPLETED

    @property
    def is_overdue(self):
        return bool(self.is_open and self.due_date and self.due_date < date.today())

    @property
    def active_record(self):
        """The current (non-withdrawn) inspection record, if any."""
        for record in self.records:
            if record.status != RECORD_WITHDRAWN:
                return record
        return None

    def log(self, event_type, actor, detail=None):
        event = InspectionEvent(assignment=self, actor=actor, event_type=event_type, detail=detail)
        db.session.add(event)
        return event


class InspectionRecord(db.Model):
    """A real inspection entered by an authorized user. Never auto-created.

    The original fields (inspection_date, condition_found, notes) are kept;
    the inspector workflow adds verification results, findings, drafts and
    revision tracking.
    """

    __tablename__ = "inspection_records"

    id = db.Column(db.Integer, primary_key=True)
    advertisement_id = db.Column(
        db.Integer, db.ForeignKey("advertisements.id"), nullable=False, index=True
    )
    inspector_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    # Date part of inspected_at; set when the record is submitted.
    inspection_date = db.Column(db.Date, index=True)
    condition_found = db.Column(db.String(30), index=True)
    notes = db.Column(db.Text)  # additional notes
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)

    assignment_id = db.Column(
        db.Integer, db.ForeignKey("inspection_assignments.id"), index=True
    )
    status = db.Column(
        db.String(30), nullable=False, default=RECORD_DRAFT,
        server_default=RECORD_SUBMITTED, index=True,
    )
    condition_other = db.Column(db.String(255))
    location_verification = db.Column(db.String(30), index=True)
    details_verification = db.Column(db.String(30))
    permit_observation = db.Column(db.String(40))
    inspected_at = db.Column(db.DateTime)
    findings = db.Column(db.Text)
    recommended_action = db.Column(db.Text)
    # How many times this record has been submitted (0 = never submitted).
    revision_number = db.Column(db.Integer, nullable=False, default=0, server_default="0")
    correction_reason = db.Column(db.Text)
    first_submitted_at = db.Column(db.DateTime)
    submitted_at = db.Column(db.DateTime, index=True)
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow)

    advertisement = db.relationship("Advertisement", back_populates="inspection_records")
    inspector = db.relationship("User", foreign_keys=[inspector_id])
    assignment = db.relationship("InspectionAssignment", back_populates="records")
    photos = db.relationship(
        "InspectionPhoto", back_populates="record", order_by="InspectionPhoto.uploaded_at"
    )
    revisions = db.relationship(
        "InspectionRecordRevision",
        back_populates="record",
        order_by="InspectionRecordRevision.revision_number.desc()",
    )
    follow_ups = db.relationship(
        "InspectionFollowUp",
        back_populates="record",
        order_by="InspectionFollowUp.created_at.desc()",
    )

    @property
    def status_label(self):
        return RECORD_STATUSES.get(self.status, (self.status, "secondary"))[0]

    @property
    def status_badge(self):
        return RECORD_STATUSES.get(self.status, (self.status, "secondary"))[1]

    @property
    def is_editable(self):
        return self.status in (RECORD_DRAFT, RECORD_CORRECTION_REQUESTED)

    @property
    def condition_label(self):
        if self.condition_found == "other" and self.condition_other:
            return f"Other: {self.condition_other}"
        return SITE_CONDITIONS.get(self.condition_found, self.condition_found)

    @property
    def location_verification_label(self):
        return LOCATION_VERIFICATIONS.get(self.location_verification)

    @property
    def details_verification_label(self):
        return DETAILS_VERIFICATIONS.get(self.details_verification)

    @property
    def permit_observation_label(self):
        return PERMIT_OBSERVATIONS.get(self.permit_observation)

    @property
    def flag_reasons(self):
        reasons = []
        if self.condition_found in FLAGGED_SITE_CONDITIONS:
            reasons.append(SITE_CONDITIONS[self.condition_found])
        if self.location_verification in FLAGGED_LOCATION_RESULTS:
            reasons.append(LOCATION_VERIFICATIONS[self.location_verification])
        return reasons

    @property
    def is_flagged(self):
        return bool(self.flag_reasons)

    def snapshot(self):
        """Immutable copy of the submitted content, stored with each revision."""
        return {
            "condition_found": self.condition_found,
            "condition_other": self.condition_other,
            "location_verification": self.location_verification,
            "details_verification": self.details_verification,
            "permit_observation": self.permit_observation,
            "inspected_at": self.inspected_at.isoformat() if self.inspected_at else None,
            "findings": self.findings,
            "recommended_action": self.recommended_action,
            "notes": self.notes,
            "photo_ids": [photo.id for photo in self.photos],
        }


class InspectionPhoto(db.Model):
    __tablename__ = "inspection_photos"

    id = db.Column(db.Integer, primary_key=True)
    record_id = db.Column(
        db.Integer, db.ForeignKey("inspection_records.id"), nullable=False, index=True
    )
    file_path = db.Column(db.String(255), nullable=False, unique=True)
    original_name = db.Column(db.String(255))
    content_type = db.Column(db.String(50), nullable=False)
    size_bytes = db.Column(db.Integer, nullable=False)
    width = db.Column(db.Integer)
    height = db.Column(db.Integer)
    uploaded_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    uploaded_at = db.Column(db.DateTime, nullable=False, default=utcnow)
    # Set once the photo is part of a submitted report; locked photos cannot
    # be removed.
    locked_at = db.Column(db.DateTime)

    record = db.relationship("InspectionRecord", back_populates="photos")
    uploaded_by = db.relationship("User")


class InspectionRecordRevision(db.Model):
    __tablename__ = "inspection_record_revisions"
    __table_args__ = (
        db.UniqueConstraint("record_id", "revision_number", name="uq_inspection_revision_number"),
    )

    id = db.Column(db.Integer, primary_key=True)
    record_id = db.Column(
        db.Integer, db.ForeignKey("inspection_records.id"), nullable=False, index=True
    )
    revision_number = db.Column(db.Integer, nullable=False)
    snapshot = db.Column(db.JSON, nullable=False)
    correction_reason = db.Column(db.Text)
    submitted_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    submitted_at = db.Column(db.DateTime, nullable=False, default=utcnow)

    record = db.relationship("InspectionRecord", back_populates="revisions")
    submitted_by = db.relationship("User")


class InspectionEvent(db.Model):
    __tablename__ = "inspection_events"

    id = db.Column(db.Integer, primary_key=True)
    assignment_id = db.Column(
        db.Integer, db.ForeignKey("inspection_assignments.id"), nullable=False, index=True
    )
    actor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    event_type = db.Column(db.String(40), nullable=False)
    detail = db.Column(db.Text)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)

    assignment = db.relationship("InspectionAssignment", back_populates="events")
    actor = db.relationship("User")

    @property
    def label(self):
        return EVENT_LABELS.get(self.event_type, self.event_type.replace("_", " ").title())


class InspectionFollowUp(db.Model):
    __tablename__ = "inspection_follow_ups"

    id = db.Column(db.Integer, primary_key=True)
    record_id = db.Column(
        db.Integer, db.ForeignKey("inspection_records.id"), nullable=False, index=True
    )
    admin_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    action = db.Column(db.String(40), nullable=False)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)

    record = db.relationship("InspectionRecord", back_populates="follow_ups")
    admin = db.relationship("User")

    @property
    def action_label(self):
        return FOLLOW_UP_ACTIONS.get(self.action, self.action)
