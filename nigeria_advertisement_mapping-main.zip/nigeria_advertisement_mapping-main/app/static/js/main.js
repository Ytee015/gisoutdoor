// Shared behaviour for every page.
(function () {
  "use strict";

  // Forms with data-confirm="message" ask before submitting (e.g. archive).
  document.addEventListener("submit", function (event) {
    const form = event.target;
    const message = form.getAttribute("data-confirm");
    if (message && !window.confirm(message)) {
      event.preventDefault();
    }
  });

  // Individual submit buttons with data-confirm-click="message".
  document.addEventListener("click", function (event) {
    const button = event.target.closest("[data-confirm-click]");
    if (button && !window.confirm(button.getAttribute("data-confirm-click"))) {
      event.preventDefault();
    }
  });
})();
