// Dashboard charts (Chart.js). Data comes from the JSON block rendered by
// the server from live database counts.
(function () {
  "use strict";

  const source = document.getElementById("dashboard-charts");
  if (!source || typeof Chart === "undefined") return;
  const data = JSON.parse(source.textContent);

  const BLUE = "#1f5fd6";
  const STATUS_COLOURS = {
    approved: "#198754", pending: "#fd7e14", rejected: "#dc3545", suspended: "#6f42c1",
    valid: "#198754", expiring_soon: "#ffc107", expired: "#dc3545", missing: "#6c757d",
    pending_verification: "#0dcaf0", unverified: "#adb5bd",
  };

  Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;
  Chart.defaults.color = "#4a5468";
  Chart.defaults.plugins.legend.labels.boxWidth = 12;

  function emptyMessage(canvas, text) {
    const message = document.createElement("p");
    message.className = "text-secondary small text-center my-5";
    message.textContent = text;
    canvas.replaceWith(message);
  }

  function bar(id, series, horizontal) {
    const canvas = document.getElementById(id);
    if (!canvas) return;
    if (!series.values.length) {
      emptyMessage(canvas, "No advertisements registered yet.");
      return;
    }
    new Chart(canvas, {
      type: "bar",
      data: {
        labels: series.labels,
        datasets: [{ label: "Advertisements", data: series.values, backgroundColor: BLUE, borderRadius: 4 }],
      },
      options: {
        indexAxis: horizontal ? "y" : "x",
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { beginAtZero: true, ticks: { precision: 0 }, grid: { display: horizontal } },
          y: { beginAtZero: true, ticks: { precision: 0 }, grid: { display: !horizontal } },
        },
      },
    });
  }

  function doughnut(id, series) {
    const canvas = document.getElementById(id);
    if (!canvas) return;
    const total = series.values.reduce(function (a, b) { return a + b; }, 0);
    if (!total) {
      emptyMessage(canvas, "No advertisements registered yet.");
      return;
    }
    new Chart(canvas, {
      type: "doughnut",
      data: {
        labels: series.labels,
        datasets: [{
          data: series.values,
          backgroundColor: series.keys.map(function (k) { return STATUS_COLOURS[k] || "#adb5bd"; }),
          borderWidth: 1,
        }],
      },
      options: { maintainAspectRatio: false, cutout: "60%", plugins: { legend: { position: "right" } } },
    });
  }

  bar("chart-state", data.state, true);
  bar("chart-category", data.category, true);
  doughnut("chart-approval", data.approval);
  doughnut("chart-permit", data.permit);
})();
