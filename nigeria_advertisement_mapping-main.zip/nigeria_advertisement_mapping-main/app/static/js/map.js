// Leaflet / OpenStreetMap helpers for NOAMS.
// Popups are built with DOM APIs (textContent), never innerHTML, so record
// text can never inject markup.
(function (global) {
  "use strict";

  const TILE_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
  const ATTRIBUTION =
    '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

  const APPROVAL_COLOURS = {
    approved: "#198754",
    pending: "#fd7e14",
    rejected: "#dc3545",
    suspended: "#6f42c1",
  };
  const EXPIRED_FILL = "#8a929e";
  const ASSIGNMENT_COLOURS = {
    assigned: "#1f5fd6",
    in_progress: "#fd7e14",
    completed: "#198754",
  };
  const BADGES = {
    approved: "success", pending: "warning", rejected: "danger", suspended: "purple",
    valid: "success", expiring_soon: "warning", expired: "danger", missing: "secondary",
    pending_verification: "info", unverified: "light",
    assigned: "primary", in_progress: "warning", completed: "success",
  };

  function createMap(elementId, center, zoom) {
    const map = L.map(elementId, { scrollWheelZoom: true }).setView(center, zoom);
    L.tileLayer(TILE_URL, { maxZoom: 19, attribution: ATTRIBUTION }).addTo(map);
    return map;
  }

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = text;
    return node;
  }

  function badge(text, key) {
    const colour = BADGES[key] || "secondary";
    const cls = colour === "light" ? "badge text-bg-light border" : "badge text-bg-" + colour;
    return el("span", cls, text);
  }

  function isValidCoordinate(lat, lng) {
    return Number.isFinite(lat) && Number.isFinite(lng) &&
      lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
  }

  // Approval status sets the ring colour; an expired permit greys the fill,
  // so the two statuses stay visually separate.
  function advertisementMarker(ad) {
    const ring = APPROVAL_COLOURS[ad.approval_status] || "#6c757d";
    const expired = ad.permit_condition === "expired";
    return L.circleMarker([ad.lat, ad.lng], {
      radius: 9,
      color: ring,
      weight: expired ? 4 : 2,
      fillColor: expired ? EXPIRED_FILL : ring,
      fillOpacity: 0.85,
    });
  }

  function labelled(label, value) {
    const row = el("div", "map-popup__row");
    row.appendChild(el("span", "map-popup__label", label));
    row.appendChild(el("span", null, value || "—"));
    return row;
  }

  function advertisementPopup(ad) {
    const root = el("div", "map-popup");
    if (ad.photo_url) {
      const img = el("img", "map-popup__photo");
      img.src = ad.photo_url;
      img.alt = "Photograph of " + ad.title;
      img.loading = "lazy";
      img.addEventListener("error", function () {
        img.replaceWith(placeholder());
      });
      root.appendChild(img);
    } else {
      root.appendChild(placeholder());
    }
    root.appendChild(el("div", "map-popup__code", ad.code));
    root.appendChild(el("div", "map-popup__title", ad.title));
    root.appendChild(labelled("Category", ad.category));
    root.appendChild(labelled("Advertiser", ad.advertiser));
    root.appendChild(labelled("Address", ad.address));
    root.appendChild(labelled("City", ad.city));
    root.appendChild(labelled("State", ad.state));
    const statuses = el("div", "map-popup__badges");
    statuses.appendChild(el("span", "map-popup__label", "Approval"));
    statuses.appendChild(badge(ad.approval_label, ad.approval_status));
    root.appendChild(statuses);
    const permit = el("div", "map-popup__badges");
    permit.appendChild(el("span", "map-popup__label", "Permit"));
    permit.appendChild(badge(ad.permit_label, ad.permit_condition));
    root.appendChild(permit);
    if (ad.permit_expiry) root.appendChild(labelled("Expiry", ad.permit_expiry));
    const link = el("a", "btn btn-primary btn-sm w-100 mt-2", "View details");
    link.href = ad.detail_url;
    root.appendChild(link);
    return root;
  }

  function placeholder() {
    const box = el("div", "map-popup__photo photo-placeholder");
    box.appendChild(el("i", "bi bi-image"));
    box.appendChild(el("span", null, "No photograph"));
    return box;
  }

  // ------------------------------------------------------------------
  // Main GIS map: database-backed markers with server-side filtering
  // ------------------------------------------------------------------
  function initBrowseMap(opts) {
    const map = createMap(opts.mapId, opts.center, opts.zoom);
    const layer = L.featureGroup().addTo(map);
    const form = document.getElementById(opts.formId);
    const boundsBox = document.getElementById(opts.boundsCheckbox);
    const countEl = document.getElementById(opts.countId);
    const loadingEl = document.getElementById(opts.loadingId);
    const emptyEl = document.getElementById(opts.emptyId);
    const emptyText = document.getElementById(opts.emptyTextId);
    let controller = null;
    let moveTimer = null;

    function filterParams() {
      const params = new URLSearchParams();
      new FormData(form).forEach(function (value, key) {
        if (key !== "bounds" && String(value).trim() !== "") params.append(key, String(value).trim());
      });
      return params;
    }

    function showEmpty(message) {
      emptyText.textContent = message;
      emptyEl.hidden = false;
    }

    function load(fitToResults) {
      const params = filterParams();
      const hasFilters = Array.from(params.keys()).length > 0;
      if (boundsBox.checked) {
        const b = map.getBounds();
        params.set("bbox", [b.getSouth(), b.getWest(), b.getNorth(), b.getEast()]
          .map(function (n) { return n.toFixed(5); }).join(","));
      }
      if (controller) controller.abort();
      controller = new AbortController();
      loadingEl.hidden = false;
      emptyEl.hidden = true;
      countEl.textContent = "Loading…";

      fetch(opts.apiUrl + "?" + params.toString(), {
        headers: { Accept: "application/json" },
        credentials: "same-origin",
        signal: controller.signal,
      })
        .then(function (response) {
          if (!response.ok) throw new Error("HTTP " + response.status);
          return response.json();
        })
        .then(function (data) {
          layer.clearLayers();
          data.advertisements.forEach(function (ad) {
            if (!isValidCoordinate(ad.lat, ad.lng)) return;
            advertisementMarker(ad).bindPopup(advertisementPopup(ad), { maxWidth: 280, minWidth: 240 })
              .addTo(layer);
          });
          const n = data.count;
          countEl.textContent = n + " advertisement" + (n === 1 ? "" : "s") + " shown" +
            (data.truncated ? " (limit reached — narrow the filters to see all)" : "");
          if (n === 0) {
            if (!hasFilters && !boundsBox.checked) {
              showEmpty("No advertisements with geographical coordinates are available yet. " +
                "Advertisements must be registered with a latitude and longitude before they can appear on the map.");
            } else {
              showEmpty("No advertisements match the selected filters" +
                (boundsBox.checked ? " in this part of the map." : "."));
            }
          } else if (fitToResults && !boundsBox.checked) {
            map.fitBounds(layer.getBounds(), { padding: [30, 30], maxZoom: 16 });
          }
        })
        .catch(function (error) {
          if (error.name === "AbortError") return;
          countEl.textContent = "";
          showEmpty("The advertisements could not be loaded. Check your connection and try again.");
        })
        .finally(function () {
          loadingEl.hidden = true;
        });
    }

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      load(true);
    });
    form.addEventListener("reset", function () {
      window.setTimeout(function () { load(true); }, 0);
    });
    boundsBox.addEventListener("change", function () { load(!boundsBox.checked); });
    map.on("moveend", function () {
      if (!boundsBox.checked) return;
      window.clearTimeout(moveTimer);
      moveTimer = window.setTimeout(function () { load(false); }, 400);
    });
    load(true);
    return map;
  }

  // ------------------------------------------------------------------
  // Small read-only map on the details page
  // ------------------------------------------------------------------
  function initStaticMap(elementId, markers) {
    const valid = markers.filter(function (m) { return isValidCoordinate(m.lat, m.lng); });
    if (!valid.length) return null;
    const map = createMap(elementId, [valid[0].lat, valid[0].lng], 16);
    valid.forEach(function (m) {
      advertisementMarker(m).bindTooltip(m.code + " · " + m.title).addTo(map);
    });
    return map;
  }

  // ------------------------------------------------------------------
  // Coordinate picker on the registration / edit form
  // ------------------------------------------------------------------
  function initLocationPicker(opts) {
    const latInput = document.getElementById(opts.latInput);
    const lngInput = document.getElementById(opts.lngInput);
    const status = document.getElementById(opts.statusId);
    const map = createMap(opts.mapId, opts.center, opts.zoom);
    let marker = null;

    function setStatus(text, tone) {
      status.textContent = text;
      status.className = "small mb-2 " + (tone === "error" ? "text-danger" : "text-secondary");
    }

    function placeMarker(lat, lng, pan) {
      if (!marker) {
        marker = L.marker([lat, lng], { draggable: true, autoPan: true }).addTo(map);
        marker.on("dragend", function () {
          const p = marker.getLatLng();
          writeInputs(p.lat, p.lng);
          setStatus("Marker moved. Check that it sits on the billboard's actual position.");
        });
      } else {
        marker.setLatLng([lat, lng]);
      }
      if (pan) map.setView([lat, lng], Math.max(map.getZoom(), 16));
    }

    function writeInputs(lat, lng) {
      latInput.value = lat.toFixed(6);
      lngInput.value = lng.toFixed(6);
    }

    function readInputs() {
      const lat = parseFloat(latInput.value);
      const lng = parseFloat(lngInput.value);
      return isValidCoordinate(lat, lng) ? [lat, lng] : null;
    }

    const initial = readInputs();
    if (initial) {
      placeMarker(initial[0], initial[1], true);
      setStatus("Showing the saved coordinates.");
    } else {
      setStatus("No location selected yet. The map is centred on Lagos only as a starting view.");
    }

    map.on("click", function (event) {
      writeInputs(event.latlng.lat, event.latlng.lng);
      placeMarker(event.latlng.lat, event.latlng.lng, false);
      setStatus("Location selected on the map. Check that it matches the billboard's actual position.");
    });

    [latInput, lngInput].forEach(function (input) {
      input.addEventListener("change", function () {
        const value = readInputs();
        if (value) {
          placeMarker(value[0], value[1], true);
          setStatus("Marker updated from the entered coordinates.");
        } else if (latInput.value || lngInput.value) {
          setStatus("Latitude must be between -90 and 90 and longitude between -180 and 180.", "error");
        }
      });
    });

    const locateButton = document.getElementById(opts.locateButton);
    if (locateButton) {
      locateButton.addEventListener("click", function () {
        // Only runs when the user clicks: the browser then asks for permission.
        if (!("geolocation" in navigator)) {
          setStatus("This browser cannot provide your location. Enter the coordinates manually.", "error");
          return;
        }
        if (!window.isSecureContext) {
          setStatus("Location access needs HTTPS (or localhost). Enter the coordinates manually.", "error");
          return;
        }
        setStatus("Requesting your location…");
        navigator.geolocation.getCurrentPosition(function (pos) {
          writeInputs(pos.coords.latitude, pos.coords.longitude);
          placeMarker(pos.coords.latitude, pos.coords.longitude, true);
          setStatus("Your device's location was used (accuracy about ±" + Math.round(pos.coords.accuracy) +
            " m). Only use this if you are standing at the billboard, and adjust the marker if needed.");
        }, function (error) {
          setStatus(error.code === error.PERMISSION_DENIED
            ? "Location permission was denied. Click the map or enter coordinates instead."
            : "Your location could not be determined. Click the map or enter coordinates instead.", "error");
        }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
      });
    }

    const clearButton = document.getElementById(opts.clearButton);
    if (clearButton) {
      clearButton.addEventListener("click", function () {
        latInput.value = "";
        lngInput.value = "";
        if (marker) { map.removeLayer(marker); marker = null; }
        setStatus("Location cleared.");
      });
    }
    return map;
  }

  // ------------------------------------------------------------------
  // Inspector dashboard: assigned advertisements only
  // ------------------------------------------------------------------
  function initInspectorMap(opts) {
    const markers = opts.markers.filter(function (m) { return isValidCoordinate(m.lat, m.lng); });
    const map = createMap(opts.mapId, opts.center, opts.zoom);
    const layer = L.featureGroup().addTo(map);
    markers.forEach(function (m) {
      const colour = ASSIGNMENT_COLOURS[m.status] || "#6c757d";
      const root = el("div", "map-popup");
      root.appendChild(el("div", "map-popup__code", m.code));
      root.appendChild(el("div", "map-popup__title", m.title));
      root.appendChild(labelled("Address", m.address));
      const st = el("div", "map-popup__badges");
      st.appendChild(el("span", "map-popup__label", "Inspection"));
      st.appendChild(badge(m.status_label, m.status));
      root.appendChild(st);
      root.appendChild(el("p", "small text-secondary mb-2 mt-1",
        "Registered location only — a marker does not mean the site has been verified."));
      const open = el("a", "btn btn-primary btn-sm w-100 mb-1", "Open inspection");
      open.href = m.url;
      root.appendChild(open);
      const dirs = el("div", "d-flex gap-1");
      [["Google Maps", m.google_directions], ["OpenStreetMap", m.osm_directions]].forEach(function (pair) {
        const a = el("a", "btn btn-outline-secondary btn-sm flex-fill", pair[0]);
        a.href = pair[1];
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        dirs.appendChild(a);
      });
      root.appendChild(el("div", "small text-secondary mt-1", "Directions:"));
      root.appendChild(dirs);
      L.circleMarker([m.lat, m.lng], {
        radius: 9, color: colour, weight: 2, fillColor: colour, fillOpacity: 0.85,
      }).bindPopup(root, { maxWidth: 260, minWidth: 220 }).addTo(layer);
    });
    if (markers.length) map.fitBounds(layer.getBounds(), { padding: [30, 30], maxZoom: 15 });
    return map;
  }

  // ------------------------------------------------------------------
  // Form helpers
  // ------------------------------------------------------------------
  function initPhotoPreview(opts) {
    const input = document.getElementById(opts.inputId);
    const preview = document.getElementById(opts.previewId);
    const caption = document.getElementById(opts.captionId);
    if (!input || !preview) return;
    const allowed = ["image/jpeg", "image/png", "image/webp"];
    let objectUrl = null;
    input.addEventListener("change", function () {
      const file = input.files && input.files[0];
      if (objectUrl) { URL.revokeObjectURL(objectUrl); objectUrl = null; }
      if (!file) return;
      if (allowed.indexOf(file.type) === -1) {
        caption.textContent = "This file type is not supported. Choose a JPEG, PNG or WebP photograph.";
        caption.className = "small text-danger mt-1 mb-0";
        return;
      }
      objectUrl = URL.createObjectURL(file);
      const img = el("img", "ad-photo ad-photo--preview");
      img.src = objectUrl;
      img.alt = "Preview of the selected photograph";
      preview.replaceChildren(img);
      caption.textContent = "Selected: " + file.name + " (" + (file.size / 1048576).toFixed(1) +
        " MB). It is uploaded when you save.";
      caption.className = "small text-secondary mt-1 mb-0";
    });
  }

  function initLocationSuggestions(opts) {
    const select = document.getElementById(opts.stateSelect);
    if (!select) return;
    function fill(data) {
      Object.keys(opts.lists).forEach(function (key) {
        const list = document.getElementById(opts.lists[key]);
        if (!list) return;
        list.replaceChildren();
        (data[key] || []).forEach(function (name) {
          const option = document.createElement("option");
          option.value = name;
          list.appendChild(option);
        });
      });
    }
    function load() {
      if (!select.value) { fill({}); return; }
      fetch(opts.url + "?state=" + encodeURIComponent(select.value), {
        headers: { Accept: "application/json" }, credentials: "same-origin",
      })
        .then(function (r) { return r.ok ? r.json() : {}; })
        .then(fill)
        .catch(function () { fill({}); });
    }
    select.addEventListener("change", load);
    load();
  }

  global.NOAMS = Object.assign(global.NOAMS || {}, {
    initBrowseMap: initBrowseMap,
    initStaticMap: initStaticMap,
    initLocationPicker: initLocationPicker,
    initInspectorMap: initInspectorMap,
    initPhotoPreview: initPhotoPreview,
    initLocationSuggestions: initLocationSuggestions,
  });
})(window);
