"""Flask CLI commands: ``flask --app run <command>``."""

import re

import click
from email_validator import EmailNotValidError, validate_email
from sqlalchemy import func, select

from .extensions import db
from .models import (
    ROLE_ADMIN,
    AdvertisementCategory,
    RegulatoryAuthority,
    StateOrTerritory,
    User,
)
from .nigeria import STATES_AND_TERRITORIES

DEFAULT_CATEGORIES = [
    ("Large roadside billboard", "Free-standing large-format billboard beside a road."),
    ("Digital LED billboard", "Electronic LED or digital display."),
    ("Wall advertisement", "Advertisement painted or mounted on a building wall."),
    ("Shop signboard", "Business signage on or in front of a shop."),
    ("Streetlight pole advertisement", "Banners or panels mounted on streetlight poles."),
    ("Bus shelter advertisement", "Panels on bus shelters or bus stops."),
    ("Political campaign billboard", "Billboard used for political campaigns."),
    ("Estate entrance signboard", "Signboard at the entrance of an estate."),
    ("Event advertisement", "Temporary advertisement for an event."),
    ("Construction-site banner", "Banner or hoarding at a construction site."),
    ("Large-format outdoor banner", "Large flex or vinyl outdoor banner."),
    ("Commercial building advertisement", "Advertisement on a commercial building façade or rooftop."),
    ("Bridge or flyover advertising structure", "Structure mounted on a bridge or flyover."),
    ("Other outdoor advertising structure", "Any outdoor structure not listed above."),
]

# Example authority named in the project brief. Contact details are left
# blank on purpose — administrators should enter verified details themselves.
EXAMPLE_AUTHORITIES = [
    {
        "name": "Lagos State Signage and Advertisement Agency (LASAA)",
        "jurisdiction": "Lagos State",
        "state_or_territory": "Lagos",
    },
]


def seed_reference_data():
    """Insert missing states, categories and example authorities.

    Safe to run repeatedly: existing rows are never modified or duplicated.
    """
    added = {"states": 0, "categories": 0, "authorities": 0}
    existing_states = set(db.session.scalars(select(StateOrTerritory.name)))
    for name, kind in STATES_AND_TERRITORIES:
        if name not in existing_states:
            db.session.add(StateOrTerritory(name=name, kind=kind))
            added["states"] += 1
    existing_categories = {n.lower() for n in db.session.scalars(select(AdvertisementCategory.name))}
    for name, description in DEFAULT_CATEGORIES:
        if name.lower() not in existing_categories:
            db.session.add(AdvertisementCategory(name=name, description=description))
            added["categories"] += 1
    existing_authorities = set(db.session.scalars(select(RegulatoryAuthority.name)))
    for data in EXAMPLE_AUTHORITIES:
        if data["name"] not in existing_authorities:
            db.session.add(RegulatoryAuthority(**data))
            added["authorities"] += 1
    db.session.commit()
    return added


def _password_problem(password):
    if len(password) < 8 or not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return "Password must be at least 8 characters and include a letter and a number."
    return None


def register_cli(app):
    @app.cli.command("seed-reference-data")
    def seed_reference_data_command():
        """Load Nigerian states/FCT, default categories and example authorities."""
        added = seed_reference_data()
        click.echo(
            f"Added {added['states']} states/territories, {added['categories']} categories "
            f"and {added['authorities']} regulatory authorities (existing rows unchanged)."
        )

    @app.cli.command("create-admin")
    @click.option("--email", prompt="Administrator email")
    @click.option("--full-name", prompt="Full name")
    @click.password_option("--password", prompt="Password", confirmation_prompt=True,
                           help="Prompted securely if omitted.")
    def create_admin_command(email, full_name, password):
        """Create an administrator account (the only way to create the first admin)."""
        try:
            email = validate_email(email.strip(), check_deliverability=False).normalized.lower()
        except EmailNotValidError as exc:
            raise click.ClickException(f"Invalid email address: {exc}") from None
        full_name = full_name.strip()
        if not full_name:
            raise click.ClickException("Full name is required.")
        problem = _password_problem(password)
        if problem:
            raise click.ClickException(problem)
        if db.session.scalar(select(User).where(func.lower(User.email) == email)):
            raise click.ClickException(
                f"A user with email {email} already exists. Use the administration "
                "screen to change that account's role."
            )
        user = User(full_name=full_name, email=email, role=ROLE_ADMIN, is_active=True)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        click.echo(f"Administrator {email} created.")
