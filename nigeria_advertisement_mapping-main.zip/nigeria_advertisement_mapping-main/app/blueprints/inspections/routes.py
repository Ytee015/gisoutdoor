"""Field inspections: inspector workflow and administrator management.

Findings are records only. Nothing here changes an advertisement's approval
status or permit data — administrators act on findings through the normal
review workflow.
"""

from datetime import date, datetime, time, timedelta

from flask import (
    abort,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for,
)
from flask_login import current_user, login_required
from sqlalchemy import exists, func, or_, select

from ...decorators import admin_required, role_required
from ...extensions import db
from ...forms import (
    AssignmentForm,
    AssignmentUpdateForm,
    ConfirmForm,
    CorrectionRequestForm,
    FollowUpForm,
    InspectionReportForm,
    ReassignForm,
)
from ...models import (
    ASSIGNMENT_ASSIGNED,
    ASSIGNMENT_COMPLETED,
    ASSIGNMENT_IN_PROGRESS,
    ASSIGNMENT_STATUSES,
    DETAILS_VERIFICATIONS,
    FLAGGED_LOCATION_RESULTS,
    FLAGGED_SITE_CONDITIONS,
    LOCATION_VERIFICATIONS,
    PERMIT_OBSERVATIONS,
    RECORD_CORRECTION_REQUESTED,
    RECORD_DRAFT,
    RECORD_SUBMITTED,
    RECORD_WITHDRAWN,
    ROLE_INSPECTOR,
    SITE_CONDITIONS,
    Advertisement,
    AdvertisementCategory,
    InspectionAssignment,
    InspectionFollowUp,
    InspectionPhoto,
    InspectionRecord,
    InspectionRecordRevision,
    StateOrTerritory,
    User,
    utcnow,
)
from ...permissions import can_view_inspection, can_view_inspection_record, can_work_on_inspection
from ...services import record_history
from ...utils import (
    ImageUploadError,
    delete_image_files,
    resolve_upload,
    save_image,
    thumbnail_path,
    to_wat,
    wat_to_utc,
)
from . import bp

INSPECTION_UPLOAD_SUBDIR = "inspections"
REPORTED_STATUSES = (RECORD_SUBMITTED, RECORD_CORRECTION_REQUESTED)


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def _assignment_or_404(assignment_id):
    assignment = db.session.get(InspectionAssignment, assignment_id)
    # 404 rather than 403 so other inspectors' assignments are not revealed.
    if assignment is None or not can_view_inspection(current_user, assignment):
        abort(404)
    return assignment


def _workable_assignment_or_404(assignment_id):
    assignment = _assignment_or_404(assignment_id)
    if not can_work_on_inspection(current_user, assignment):
        abort(403)
    return assignment


def _record_or_404(record_id):
    record = db.session.get(InspectionRecord, record_id)
    if record is None or not can_view_inspection_record(current_user, record):
        abort(404)
    return record


def _active_inspectors(exclude_id=None):
    query = select(User).where(User.role == ROLE_INSPECTOR, User.is_active.is_(True))
    if exclude_id:
        query = query.where(User.id != exclude_id)
    return db.session.scalars(query.order_by(User.full_name)).all()


def _paginate(query):
    return db.paginate(query, page=request.args.get("page", 1, type=int),
                       per_page=current_app.config["ITEMS_PER_PAGE"], error_out=False)


def _map_markers(assignments):
    """Markers for assignments whose advertisement has saved coordinates.

    Advertisements without coordinates are simply left off the map — they
    are never placed at a default position.
    """
    markers, seen = [], set()
    for assignment in assignments:
        ad = assignment.advertisement
        if ad.id in seen or not ad.has_coordinates:
            continue
        seen.add(ad.id)
        markers.append({
            "lat": ad.latitude,
            "lng": ad.longitude,
            "code": ad.advertisement_code,
            "title": ad.title,
            "address": ad.display_address,
            "status": assignment.status,
            "status_label": assignment.status_label,
            "url": url_for("inspections.detail", assignment_id=assignment.id),
            "google_directions": "https://www.google.com/maps/dir/?api=1&destination="
                                 f"{ad.latitude},{ad.longitude}",
            "osm_directions": "https://www.openstreetmap.org/directions?route=%3B"
                              f"{ad.latitude}%2C{ad.longitude}",
        })
    return markers


def _status_counts(base_condition=None):
    query = select(InspectionAssignment.status, func.count(InspectionAssignment.id))
    if base_condition is not None:
        query = query.where(base_condition)
    counts = dict(db.session.execute(query.group_by(InspectionAssignment.status)).all())
    return {key: counts.get(key, 0) for key in ASSIGNMENT_STATUSES}


# --------------------------------------------------------------------------
# Inspector: dashboard, lists and history
# --------------------------------------------------------------------------

@bp.route("/dashboard")
@role_required(ROLE_INSPECTOR)
def dashboard():
    mine = InspectionAssignment.inspector_id == current_user.id
    counts = _status_counts(mine)
    overdue = db.session.scalar(
        select(func.count(InspectionAssignment.id)).where(
            mine, InspectionAssignment.status != ASSIGNMENT_COMPLETED,
            InspectionAssignment.due_date < date.today(),
        )
    )
    open_assignments = db.session.scalars(
        select(InspectionAssignment)
        .where(mine, InspectionAssignment.status != ASSIGNMENT_COMPLETED)
        .order_by(InspectionAssignment.due_date.is_(None), InspectionAssignment.due_date,
                  InspectionAssignment.assigned_at)
    ).all()
    all_assignments = db.session.scalars(
        select(InspectionAssignment).where(mine).order_by(InspectionAssignment.assigned_at.desc())
    ).all()
    recent_reports = db.session.scalars(
        select(InspectionRecord)
        .where(InspectionRecord.inspector_id == current_user.id,
               InspectionRecord.status.in_(REPORTED_STATUSES))
        .order_by(InspectionRecord.submitted_at.desc()).limit(5)
    ).all()
    markers = _map_markers(all_assignments)
    return render_template(
        "inspections/dashboard.html",
        counts=counts, total=sum(counts.values()), overdue=overdue,
        open_assignments=open_assignments, recent_reports=recent_reports,
        markers=markers, unmapped=len({a.advertisement_id for a in all_assignments}) - len(markers),
    )


@bp.route("/assigned")
@role_required(ROLE_INSPECTOR)
def assigned():
    status = request.args.get("status")
    scope = request.args.get("scope")
    query = select(InspectionAssignment).order_by(
        InspectionAssignment.status == ASSIGNMENT_COMPLETED,
        InspectionAssignment.due_date.is_(None), InspectionAssignment.due_date,
        InspectionAssignment.assigned_at.desc(),
    )
    if not (scope == "all" and current_user.can_view_all_inspections):
        scope = "mine"
        query = query.where(InspectionAssignment.inspector_id == current_user.id)
    if status in ASSIGNMENT_STATUSES:
        query = query.where(InspectionAssignment.status == status)
    return render_template("inspections/assigned.html", page=_paginate(query), status=status,
                           scope=scope, statuses=ASSIGNMENT_STATUSES)


@bp.route("/history")
@role_required(ROLE_INSPECTOR)
def history():
    query = (
        select(InspectionRecord)
        .where(InspectionRecord.inspector_id == current_user.id,
               InspectionRecord.status.in_(REPORTED_STATUSES))
        .order_by(InspectionRecord.submitted_at.desc())
    )
    return render_template("inspections/history.html", page=_paginate(query))


# --------------------------------------------------------------------------
# Assignment detail (inspector and admin)
# --------------------------------------------------------------------------

@bp.route("/<int:assignment_id>")
@login_required
def detail(assignment_id):
    assignment = _assignment_or_404(assignment_id)
    context = {
        "assignment": assignment,
        "advertisement": assignment.advertisement,
        "record": assignment.active_record,
        "can_work": can_work_on_inspection(current_user, assignment),
        "confirm_form": ConfirmForm(),
        "withdrawn": [r for r in assignment.records if r.status == RECORD_WITHDRAWN],
    }
    if current_user.is_admin:
        reassign_form = ReassignForm()
        reassign_form.inspector_id.choices = [
            (u.id, u.full_name) for u in _active_inspectors(exclude_id=assignment.inspector_id)
        ]
        context["reassign_form"] = reassign_form
        context["update_form"] = AssignmentUpdateForm(obj=assignment)
        context["can_reassign"] = _reassign_blocker(assignment) is None
        context["reassign_blocker"] = _reassign_blocker(assignment)
    return render_template("inspections/detail.html", **context)


@bp.route("/<int:assignment_id>/start", methods=["POST"])
@role_required(ROLE_INSPECTOR)
def start(assignment_id):
    assignment = _workable_assignment_or_404(assignment_id)
    if not ConfirmForm().validate_on_submit():
        abort(400)
    if assignment.status != ASSIGNMENT_ASSIGNED:
        flash("This inspection has already been started.", "info")
        return redirect(url_for("inspections.detail", assignment_id=assignment.id))
    assignment.status = ASSIGNMENT_IN_PROGRESS
    assignment.started_at = utcnow()
    if assignment.active_record is None:
        db.session.add(InspectionRecord(
            assignment=assignment,
            advertisement_id=assignment.advertisement_id,
            inspector_id=current_user.id,
            status=RECORD_DRAFT,
        ))
    assignment.log("started", current_user)
    db.session.commit()
    flash("Inspection started. Your progress is saved each time you choose “Save draft”.", "success")
    return redirect(url_for("inspections.report", assignment_id=assignment.id))


@bp.route("/<int:assignment_id>/report", methods=["GET", "POST"])
@role_required(ROLE_INSPECTOR)
def report(assignment_id):
    assignment = _workable_assignment_or_404(assignment_id)
    record = assignment.active_record
    if assignment.status != ASSIGNMENT_IN_PROGRESS or record is None or not record.is_editable:
        flash("This inspection is not open for editing.", "warning")
        return redirect(url_for("inspections.detail", assignment_id=assignment.id))

    form = InspectionReportForm(obj=record)
    if request.method == "GET" and record.inspected_at:
        form.inspected_at.data = to_wat(record.inspected_at).replace(tzinfo=None)

    if form.validate_on_submit():
        files = [f for f in (form.new_photos.data or []) if f and getattr(f, "filename", "")]
        limit = current_app.config["MAX_INSPECTION_PHOTOS_PER_UPLOAD"]
        if len(files) > limit:
            form.new_photos.errors.append(f"Upload at most {limit} photographs at a time.")
        elif form.is_submission and not record.photos and not files:
            form.new_photos.errors.append("Add at least one photograph taken during the site visit.")
        else:
            stored, errors = [], []
            for file in files:
                try:
                    stored.append(save_image(file, INSPECTION_UPLOAD_SUBDIR))
                except ImageUploadError as exc:
                    errors.append(f"{file.filename}: {exc}")
            if errors:
                # All-or-nothing: discard this request's files so nothing partial is kept.
                for item in stored:
                    delete_image_files(item.relative_path)
                form.new_photos.errors.extend(errors)
            else:
                _save_report(assignment, record, form, stored)
                if form.is_submission:
                    flash("Inspection report submitted.", "success")
                    return redirect(url_for("inspections.record_detail", record_id=record.id))
                flash("Draft saved. You can continue this inspection later.", "success")
                return redirect(url_for("inspections.report", assignment_id=assignment.id))

    return render_template("inspections/report_form.html", form=form, assignment=assignment,
                           record=record, advertisement=assignment.advertisement,
                           confirm_form=ConfirmForm())


def _save_report(assignment, record, form, stored):
    record.condition_found = form.condition_found.data or None
    record.condition_other = (form.condition_other.data or None) if record.condition_found == "other" else None
    record.location_verification = form.location_verification.data or None
    record.details_verification = form.details_verification.data or None
    record.permit_observation = form.permit_observation.data or None
    record.inspected_at = wat_to_utc(form.inspected_at.data)
    record.findings = form.findings.data or None
    record.recommended_action = form.recommended_action.data or None
    record.notes = form.notes.data or None
    for item in stored:
        db.session.add(InspectionPhoto(
            record=record, file_path=item.relative_path, original_name=item.original_name,
            content_type=item.content_type, size_bytes=item.size_bytes,
            width=item.width, height=item.height, uploaded_by=current_user,
        ))

    if form.is_submission:
        db.session.flush()  # give new photos their ids for the snapshot
        now = utcnow()
        correction_reason = record.correction_reason if record.status == RECORD_CORRECTION_REQUESTED else None
        record.revision_number += 1
        record.status = RECORD_SUBMITTED
        record.submitted_at = now
        record.first_submitted_at = record.first_submitted_at or now
        record.inspection_date = to_wat(record.inspected_at).date()
        for photo in record.photos:
            photo.locked_at = photo.locked_at or now
        db.session.add(InspectionRecordRevision(
            record=record, revision_number=record.revision_number, snapshot=record.snapshot(),
            correction_reason=correction_reason, submitted_by=current_user, submitted_at=now,
        ))
        assignment.status = ASSIGNMENT_COMPLETED
        assignment.completed_at = now
        resubmission = record.revision_number > 1
        assignment.log("resubmitted" if resubmission else "submitted", current_user,
                       f"Revision {record.revision_number}")
        record_history(
            assignment.advertisement, current_user, "inspection_submitted",
            notes=f"Inspection report revision {record.revision_number} by {current_user.full_name}: "
                  f"site condition {record.condition_label}, location "
                  f"{record.location_verification_label}. No change was made to the "
                  "advertisement's approval or permit status.",
        )
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        for item in stored:
            delete_image_files(item.relative_path)
        raise


@bp.route("/photos/<int:photo_id>")
@login_required
def photo(photo_id):
    item = db.session.get(InspectionPhoto, photo_id)
    if item is None or not can_view_inspection_record(current_user, item.record):
        abort(404)
    relative = item.file_path
    if request.args.get("size") == "thumb":
        thumb = thumbnail_path(relative)
        thumb_file = resolve_upload(thumb)
        if thumb_file and thumb_file.is_file():
            relative = thumb
    path = resolve_upload(relative)
    if path is None or not path.is_file():
        abort(404)
    response = send_from_directory(current_app.config["UPLOAD_FOLDER"], relative, max_age=3600)
    response.headers["Cache-Control"] = "private, max-age=3600"
    return response


@bp.route("/photos/<int:photo_id>/delete", methods=["POST"])
@role_required(ROLE_INSPECTOR)
def delete_photo(photo_id):
    item = db.session.get(InspectionPhoto, photo_id)
    if item is None or not can_view_inspection_record(current_user, item.record):
        abort(404)
    record = item.record
    if record.inspector_id != current_user.id or not ConfirmForm().validate_on_submit():
        abort(403)
    if item.locked_at or not record.is_editable:
        flash("Photographs that are part of a submitted report cannot be removed.", "danger")
    else:
        path = item.file_path
        db.session.delete(item)
        db.session.commit()
        delete_image_files(path)
        flash("Photograph removed.", "success")
    return redirect(url_for("inspections.report", assignment_id=record.assignment_id))


# --------------------------------------------------------------------------
# Inspection records (reports) and revisions
# --------------------------------------------------------------------------

@bp.route("/records/<int:record_id>")
@login_required
def record_detail(record_id):
    record = _record_or_404(record_id)
    context = {"record": record, "assignment": record.assignment, "advertisement": record.advertisement}
    if current_user.is_admin:
        context["correction_form"] = CorrectionRequestForm()
        context["follow_up_form"] = FollowUpForm()
    return render_template("inspections/record_detail.html", **context)


@bp.route("/records/<int:record_id>/revisions/<int:revision_number>")
@login_required
def revision_detail(record_id, revision_number):
    record = _record_or_404(record_id)
    revision = db.session.scalar(select(InspectionRecordRevision).where(
        InspectionRecordRevision.record_id == record.id,
        InspectionRecordRevision.revision_number == revision_number,
    )) or abort(404)
    snap = revision.snapshot
    photos = db.session.scalars(
        select(InspectionPhoto).where(InspectionPhoto.id.in_(snap.get("photo_ids") or []))
    ).all()
    inspected_at = datetime.fromisoformat(snap["inspected_at"]) if snap.get("inspected_at") else None
    labels = {
        "condition": SITE_CONDITIONS.get(snap.get("condition_found"), snap.get("condition_found")),
        "location": LOCATION_VERIFICATIONS.get(snap.get("location_verification")),
        "details": DETAILS_VERIFICATIONS.get(snap.get("details_verification")),
        "permit": PERMIT_OBSERVATIONS.get(snap.get("permit_observation")),
    }
    return render_template("inspections/revision_detail.html", record=record, revision=revision,
                           snap=snap, photos=photos, inspected_at=inspected_at, labels=labels)


# --------------------------------------------------------------------------
# Administrator: management, assignment, corrections and follow-ups
# --------------------------------------------------------------------------

def _reported_record_exists(*conditions):
    return exists(select(InspectionRecord.id).where(
        InspectionRecord.assignment_id == InspectionAssignment.id,
        InspectionRecord.status.in_(REPORTED_STATUSES),
        *conditions,
    ))


FLAGGED_CONDITION = or_(
    InspectionRecord.condition_found.in_(FLAGGED_SITE_CONDITIONS),
    InspectionRecord.location_verification.in_(FLAGGED_LOCATION_RESULTS),
)


@bp.route("/manage")
@admin_required
def manage():
    args = request.args
    query = select(InspectionAssignment).join(InspectionAssignment.advertisement)
    inspector_id = args.get("inspector", type=int)
    if inspector_id:
        query = query.where(InspectionAssignment.inspector_id == inspector_id)
    state = (args.get("state") or "").strip()[:80]
    if state:
        query = query.where(Advertisement.state_or_territory == state)
    lga = (args.get("lga") or "").strip()[:100]
    if lga:
        query = query.where(Advertisement.lga.icontains(lga, autoescape=True))
    category_id = args.get("category", type=int)
    if category_id:
        query = query.where(Advertisement.category_id == category_id)
    status = args.get("status")
    if status in ASSIGNMENT_STATUSES:
        query = query.where(InspectionAssignment.status == status)
    if args.get("flagged") == "1":
        query = query.where(_reported_record_exists(FLAGGED_CONDITION))
    if args.get("overdue") == "1":
        query = query.where(InspectionAssignment.status != ASSIGNMENT_COMPLETED,
                            InspectionAssignment.due_date < date.today())

    date_field = args.get("date_field", "assigned")
    date_from, date_to = _parse_date(args.get("date_from")), _parse_date(args.get("date_to"))
    if date_from or date_to:
        start = datetime.combine(date_from, time.min) if date_from else None
        end = datetime.combine(date_to + timedelta(days=1), time.min) if date_to else None
        if date_field == "inspected":
            conditions = []
            if start:
                conditions.append(InspectionRecord.inspection_date >= date_from)
            if end:
                conditions.append(InspectionRecord.inspection_date <= date_to)
            query = query.where(_reported_record_exists(*conditions))
        elif date_field == "due":
            if date_from:
                query = query.where(InspectionAssignment.due_date >= date_from)
            if date_to:
                query = query.where(InspectionAssignment.due_date <= date_to)
        else:
            date_field = "assigned"
            if start:
                query = query.where(InspectionAssignment.assigned_at >= start)
            if end:
                query = query.where(InspectionAssignment.assigned_at < end)

    query = query.order_by(InspectionAssignment.assigned_at.desc())
    flagged_count = db.session.scalar(
        select(func.count(InspectionAssignment.id)).where(_reported_record_exists(FLAGGED_CONDITION))
    )
    return render_template(
        "inspections/manage.html",
        page=_paginate(query), counts=_status_counts(), flagged_count=flagged_count,
        inspectors=db.session.scalars(select(User).where(User.role == ROLE_INSPECTOR)
                                      .order_by(User.full_name)).all(),
        states=db.session.scalars(select(StateOrTerritory).order_by(StateOrTerritory.name)).all(),
        categories=db.session.scalars(select(AdvertisementCategory)
                                      .order_by(AdvertisementCategory.name)).all(),
        statuses=ASSIGNMENT_STATUSES, args=args, date_field=date_field,
    )


def _parse_date(value):
    try:
        return datetime.strptime(value or "", "%Y-%m-%d").date()
    except ValueError:
        return None


def _assignable_advertisements():
    has_open = exists(select(InspectionAssignment.id).where(
        InspectionAssignment.advertisement_id == Advertisement.id,
        InspectionAssignment.status != ASSIGNMENT_COMPLETED,
    ))
    return db.session.scalars(
        select(Advertisement).where(Advertisement.is_archived.is_(False), ~has_open)
        .order_by(Advertisement.advertisement_code)
    ).all()


@bp.route("/manage/assign", methods=["GET", "POST"])
@admin_required
def assign():
    form = AssignmentForm()
    advertisements = _assignable_advertisements()
    inspectors = _active_inspectors()
    form.advertisement_id.choices = [(0, "— Select advertisement —")] + [
        (ad.id, f"{ad.advertisement_code} · {ad.title} ({ad.city or ad.state_or_territory})")
        for ad in advertisements
    ]
    form.inspector_id.choices = [(0, "— Select inspector —")] + [
        (u.id, f"{u.full_name} ({u.email})") for u in inspectors
    ]
    if request.method == "GET" and request.args.get("advertisement_id", type=int):
        form.advertisement_id.data = request.args.get("advertisement_id", type=int)

    if form.validate_on_submit():
        advertisement = db.session.get(Advertisement, form.advertisement_id.data)
        inspector = db.session.get(User, form.inspector_id.data)
        if advertisement is None or advertisement not in advertisements:
            form.advertisement_id.errors.append(
                "Select an active advertisement that has no open inspection.")
        elif inspector is None or inspector not in inspectors:
            form.inspector_id.errors.append("Select an active inspector.")
        else:
            assignment = InspectionAssignment(
                advertisement=advertisement, inspector=inspector, assigned_by=current_user,
                due_date=form.due_date.data, instructions=form.instructions.data or None,
            )
            db.session.add(assignment)
            assignment.log("assigned", current_user, f"Assigned to {inspector.full_name}")
            record_history(advertisement, current_user, "inspection_assigned",
                           notes=f"Field inspection assigned to {inspector.full_name}.")
            db.session.commit()
            flash(f"Inspection of {advertisement.advertisement_code} assigned to "
                  f"{inspector.full_name}.", "success")
            return redirect(url_for("inspections.detail", assignment_id=assignment.id))
    return render_template("inspections/assign.html", form=form,
                           no_inspectors=not inspectors, no_advertisements=not advertisements)


def _reassign_blocker(assignment):
    if assignment.status == ASSIGNMENT_COMPLETED:
        return "Completed inspections cannot be reassigned."
    record = assignment.active_record
    if record is not None and record.revision_number > 0:
        return ("A report has already been submitted for this inspection. Request a correction "
                "from the original inspector instead.")
    return None


@bp.route("/<int:assignment_id>/reassign", methods=["POST"])
@admin_required
def reassign(assignment_id):
    assignment = _assignment_or_404(assignment_id)
    form = ReassignForm()
    form.inspector_id.choices = [
        (u.id, u.full_name) for u in _active_inspectors(exclude_id=assignment.inspector_id)
    ]
    blocker = _reassign_blocker(assignment)
    if blocker:
        flash(blocker, "danger")
    elif not form.validate_on_submit():
        for errors in form.errors.values():
            for error in errors:
                flash(error, "danger")
    else:
        previous = assignment.inspector
        new_inspector = db.session.get(User, form.inspector_id.data)
        draft = assignment.active_record
        if draft is not None:
            # Keep the previous inspector's unfinished draft for the record.
            draft.status = RECORD_WITHDRAWN
        assignment.inspector = new_inspector
        assignment.status = ASSIGNMENT_ASSIGNED
        assignment.started_at = None
        assignment.log("reassigned", current_user,
                       f"From {previous.full_name} to {new_inspector.full_name}. Reason: {form.reason.data}")
        db.session.commit()
        flash(f"Inspection reassigned to {new_inspector.full_name}.", "success")
    return redirect(url_for("inspections.detail", assignment_id=assignment.id))


@bp.route("/<int:assignment_id>/update", methods=["POST"])
@admin_required
def update_assignment(assignment_id):
    assignment = _assignment_or_404(assignment_id)
    form = AssignmentUpdateForm()
    if not assignment.is_open:
        flash("Completed inspections cannot be changed.", "danger")
    elif form.validate_on_submit():
        assignment.due_date = form.due_date.data
        assignment.instructions = form.instructions.data or None
        assignment.log("details_updated", current_user)
        db.session.commit()
        flash("Assignment updated.", "success")
    else:
        flash("Please check the due date and instructions.", "danger")
    return redirect(url_for("inspections.detail", assignment_id=assignment.id))


@bp.route("/records/<int:record_id>/request-correction", methods=["POST"])
@admin_required
def request_correction(record_id):
    record = _record_or_404(record_id)
    form = CorrectionRequestForm()
    if record.status != RECORD_SUBMITTED:
        flash("Corrections can only be requested for a submitted report.", "danger")
    elif not form.validate_on_submit():
        flash("Explain what needs to be corrected.", "danger")
    else:
        # The submitted version is already preserved as a revision snapshot;
        # the inspector edits a new revision.
        record.status = RECORD_CORRECTION_REQUESTED
        record.correction_reason = form.reason.data
        assignment = record.assignment
        assignment.status = ASSIGNMENT_IN_PROGRESS
        assignment.completed_at = None
        assignment.log("correction_requested", current_user, form.reason.data)
        db.session.commit()
        flash("Correction requested. The inspector can now submit a corrected revision; "
              "earlier revisions remain on record.", "success")
    return redirect(url_for("inspections.record_detail", record_id=record.id))


@bp.route("/records/<int:record_id>/follow-up", methods=["POST"])
@admin_required
def follow_up(record_id):
    record = _record_or_404(record_id)
    form = FollowUpForm()
    if record.status not in REPORTED_STATUSES:
        flash("Follow-ups can only be recorded for submitted reports.", "danger")
    elif form.validate_on_submit():
        db.session.add(InspectionFollowUp(record=record, admin=current_user,
                                          action=form.action.data, notes=form.notes.data or None))
        record.assignment.log("follow_up", current_user, form.action.data)
        db.session.commit()
        flash("Follow-up recorded. No change was made to the advertisement or its permit.", "success")
    else:
        for errors in form.errors.values():
            for error in errors:
                flash(error, "danger")
    return redirect(url_for("inspections.record_detail", record_id=record.id))
