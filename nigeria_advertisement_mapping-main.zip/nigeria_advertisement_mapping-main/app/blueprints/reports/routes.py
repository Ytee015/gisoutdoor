import csv
import io
from collections import Counter

from flask import Response, current_app, render_template, request
from flask_login import current_user
from ...decorators import role_required
from ...extensions import db
from ...filters import apply_filters, filter_choices, parse_filters
from ...models import (
    APPROVAL_STATUSES,
    PERMIT_CONDITIONS,
    ROLE_ADMIN,
    ROLE_STAFF,
    Advertisement,
    AdvertisementCategory,
    RegulatoryAuthority,
    utcnow,
)
from ...permissions import visible_advertisements_query
from ...reports_pdf import build_advertisement_report
from ...utils import csv_safe, format_date, format_datetime, to_wat
from . import bp

MAX_REPORT_ROWS = 10000
MAX_PDF_ROWS = 1500
PREVIEW_ROWS = 25

GROUP_OPTIONS = {
    "state": ("state / territory", lambda ad: ad.state_or_territory),
    "city": ("city / town", lambda ad: ad.city or "Not recorded"),
    "lga": ("LGA", lambda ad: ad.lga or "Not recorded"),
    "category": ("category", lambda ad: ad.category.name if ad.category else "Not recorded"),
    "approval": ("approval status", lambda ad: ad.approval_status_label),
    "permit": ("permit condition", lambda ad: ad.permit_condition_label),
    "authority": ("regulatory authority",
                  lambda ad: ad.regulatory_authority.name if ad.regulatory_authority else "Not specified"),
}

PRESETS = [
    ("All registered advertisements", {}),
    ("By state / territory", {"group": "state"}),
    ("By city / town", {"group": "city"}),
    ("By LGA", {"group": "lga"}),
    ("By category", {"group": "category"}),
    ("By approval status", {"group": "approval"}),
    ("By permit condition", {"group": "permit"}),
    ("By regulatory authority", {"group": "authority"}),
    ("Expired permits", {"permit_condition": "expired"}),
    ("Permits expiring soon", {"permit_condition": "expiring_soon"}),
    ("Missing permit information", {"permit_condition": "missing"}),
    ("Without photographs", {"photo": "without"}),
]

CSV_COLUMNS = [
    ("Advertisement code", lambda ad: ad.advertisement_code),
    ("Title", lambda ad: ad.title),
    ("Category", lambda ad: ad.category.name if ad.category else ""),
    ("Advertiser", lambda ad: ad.advertiser_name),
    ("Contact person", lambda ad: ad.contact_person),
    ("Contact phone", lambda ad: ad.contact_phone),
    ("Country", lambda ad: ad.country),
    ("State / territory", lambda ad: ad.state_or_territory),
    ("City / town", lambda ad: ad.city),
    ("LGA", lambda ad: ad.lga),
    ("Street / road", lambda ad: ad.street_or_road),
    ("Full address", lambda ad: ad.full_address),
    ("Landmark", lambda ad: ad.landmark),
    ("Latitude", lambda ad: ad.latitude),
    ("Longitude", lambda ad: ad.longitude),
    ("Advertisement type", lambda ad: ad.advertisement_type_label),
    ("Width (m)", lambda ad: ad.width),
    ("Height (m)", lambda ad: ad.height),
    ("Installation date", lambda ad: ad.installation_date.isoformat() if ad.installation_date else ""),
    ("Physical condition", lambda ad: ad.condition_label),
    ("Approval status", lambda ad: ad.approval_status_label),
    ("Permit number", lambda ad: ad.permit_number),
    ("Regulatory authority", lambda ad: ad.regulatory_authority.name if ad.regulatory_authority else ""),
    ("Permit issue date", lambda ad: ad.permit_issue_date.isoformat() if ad.permit_issue_date else ""),
    ("Permit expiry date", lambda ad: ad.permit_expiry_date.isoformat() if ad.permit_expiry_date else ""),
    ("Permit verification", lambda ad: ad.permit_verification_label),
    ("Permit condition (calculated today)", lambda ad: ad.permit_condition_label),
    ("Has photograph", lambda ad: "Yes" if ad.photograph_path else "No"),
    ("Registered (WAT)", lambda ad: to_wat(ad.created_at).strftime("%Y-%m-%d %H:%M")),
    ("Archived", lambda ad: "Yes" if ad.is_archived else "No"),
]


def _report_query():
    filters = parse_filters(request.args)
    include_archived = current_user.is_admin and filters["archived"] in ("include", "only")
    query = visible_advertisements_query(current_user, include_archived=include_archived)
    query = apply_filters(query, filters).order_by(Advertisement.advertisement_code)
    return filters, query


def _filter_lines(filters):
    lines = []
    labels = {
        "q": "Search", "state": "State / territory", "city": "City / town", "lga": "LGA",
        "photo": "Photograph", "date_from": "Registered from", "date_to": "Registered to",
    }
    for key, label in labels.items():
        value = filters.get(key)
        if value:
            if key == "photo":
                value = "With photograph" if value == "with" else "Without photograph"
            elif key in ("date_from", "date_to"):
                value = format_date(value)
            lines.append(f"{label}: {value}")
    if filters.get("category"):
        category = db.session.get(AdvertisementCategory, filters["category"])
        lines.append(f"Category: {category.name if category else 'Unknown'}")
    if filters.get("authority"):
        authority = db.session.get(RegulatoryAuthority, filters["authority"])
        lines.append(f"Regulatory authority: {authority.name if authority else 'Unknown'}")
    if filters.get("approval_status"):
        lines.append(f"Approval status: {APPROVAL_STATUSES[filters['approval_status']][0]}")
    if filters.get("permit_condition"):
        lines.append(f"Permit condition: {PERMIT_CONDITIONS[filters['permit_condition']][0]}")
    if filters.get("archived"):
        lines.append("Archived records: " + ("only" if filters["archived"] == "only" else "included"))
    if not current_user.is_admin:
        lines.append(f"Scope: advertisements submitted by {current_user.full_name}")
    return lines


def _summary(advertisements):
    approvals = Counter(ad.approval_status for ad in advertisements)
    permits = Counter(ad.permit_condition for ad in advertisements)
    rows = [("Total advertisements", len(advertisements))]
    rows += [(f"Approval: {label}", approvals.get(key, 0)) for key, (label, _) in APPROVAL_STATUSES.items()]
    rows += [(f"Permit: {label}", permits.get(key, 0)) for key, (label, _) in PERMIT_CONDITIONS.items()]
    rows.append(("Without photograph", sum(1 for ad in advertisements if not ad.photograph_path)))
    return rows


def _groups(advertisements, group):
    if group not in GROUP_OPTIONS:
        return None, []
    label, key = GROUP_OPTIONS[group]
    counts = Counter(key(ad) for ad in advertisements)
    return label, sorted(counts.items(), key=lambda item: (-item[1], str(item[0])))


def _timestamp():
    return to_wat(utcnow()).strftime("%Y%m%d-%H%M")


@bp.route("/")
@role_required(ROLE_ADMIN, ROLE_STAFF)
def index():
    filters, query = _report_query()
    advertisements = db.session.scalars(query.limit(MAX_REPORT_ROWS)).all()
    group = request.args.get("group")
    group_label, groups = _groups(advertisements, group)
    return render_template(
        "reports/index.html",
        filters=filters, group=group, group_options=GROUP_OPTIONS, presets=PRESETS,
        summary=_summary(advertisements), group_label=group_label, groups=groups,
        preview=advertisements[:PREVIEW_ROWS], total=len(advertisements),
        filter_lines=_filter_lines(filters), **filter_choices(),
        export_args={k: v for k, v in request.args.items() if k not in ("photos", "page")},
    )


@bp.route("/export.csv")
@role_required(ROLE_ADMIN, ROLE_STAFF)
def export_csv():
    _, query = _report_query()
    advertisements = db.session.scalars(query.limit(MAX_REPORT_ROWS)).all()
    columns = list(CSV_COLUMNS)
    if current_user.is_admin:
        columns.append(("Submitted by", lambda ad: ad.submitted_by.full_name if ad.submitted_by else ""))

    output = io.StringIO()
    output.write("﻿")  # BOM so Excel opens the UTF-8 file correctly
    writer = csv.writer(output)
    writer.writerow([name for name, _ in columns])
    for ad in advertisements:
        writer.writerow([csv_safe(getter(ad)) for _, getter in columns])
    return Response(
        output.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="advertisements-{_timestamp()}.csv"'},
    )


@bp.route("/export.pdf")
@role_required(ROLE_ADMIN, ROLE_STAFF)
def export_pdf():
    filters, query = _report_query()
    advertisements = db.session.scalars(query.limit(MAX_REPORT_ROWS)).all()
    group_label, groups = _groups(advertisements, request.args.get("group"))
    title = "Outdoor Advertisement Report"
    if group_label:
        title += f" by {group_label.title()}"
    pdf = build_advertisement_report(
        app_name=current_app.config["APP_NAME"],
        title=title,
        generated_at=format_datetime(utcnow()),
        generated_by=f"{current_user.full_name} ({current_user.role_label})",
        filter_lines=_filter_lines(filters),
        summary=_summary(advertisements),
        groups=groups,
        group_label=group_label or "",
        advertisements=advertisements[:MAX_PDF_ROWS],
        include_photos=request.args.get("photos") == "1",
        truncated=len(advertisements) > MAX_PDF_ROWS,
    )
    return Response(
        pdf,
        mimetype="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="advertisements-{_timestamp()}.pdf"'},
    )
