from flask import abort, current_app, flash, redirect, render_template, request, url_for
from flask_login import current_user
from sqlalchemy import func, select

from ...decorators import admin_required
from ...extensions import db
from ...forms import (
    AuthorityForm,
    CategoryForm,
    ConfirmForm,
    LocationOptionForm,
    UserCreateForm,
    UserEditForm,
)
from ...models import (
    HISTORY_ACTIONS,
    LOCATION_TYPES,
    ROLE_ADMIN,
    ROLE_INSPECTOR,
    ROLE_LABELS,
    Advertisement,
    AdvertisementCategory,
    AdvertisementHistory,
    LocationOption,
    RegulatoryAuthority,
    StateOrTerritory,
    User,
)
from . import bp


@bp.before_request
@admin_required
def _require_admin():
    """Every route in this blueprint is administrator-only."""
    return None


def _paginate(query):
    return db.paginate(query, page=request.args.get("page", 1, type=int),
                       per_page=current_app.config["ITEMS_PER_PAGE"], error_out=False)


def _state_choices(blank="— None —"):
    states = db.session.scalars(select(StateOrTerritory).order_by(StateOrTerritory.name))
    return [("", blank)] + [(s.name, s.name) for s in states]


# --------------------------------------------------------------------------
# Users
# --------------------------------------------------------------------------

def _email_taken(email, exclude_id=None):
    query = select(User.id).where(func.lower(User.email) == email.lower())
    if exclude_id:
        query = query.where(User.id != exclude_id)
    return db.session.scalar(query) is not None


def _active_admin_count():
    return db.session.scalar(
        select(func.count(User.id)).where(User.role == ROLE_ADMIN, User.is_active.is_(True))
    )


@bp.route("/users")
def users():
    query = select(User).order_by(User.created_at.desc())
    role = request.args.get("role")
    if role in ROLE_LABELS:
        query = query.where(User.role == role)
    status = request.args.get("status")
    if status == "active":
        query = query.where(User.is_active.is_(True))
    elif status == "inactive":
        query = query.where(User.is_active.is_(False))
    q = (request.args.get("q") or "").strip()[:100]
    if q:
        query = query.where(User.full_name.icontains(q, autoescape=True)
                            | User.email.icontains(q, autoescape=True))
    return render_template("administration/users.html", page=_paginate(query), roles=ROLE_LABELS,
                           role=role, status=status, q=q, confirm_form=ConfirmForm())


@bp.route("/users/new", methods=["GET", "POST"])
def create_user():
    form = UserCreateForm()
    if form.validate_on_submit():
        if _email_taken(form.email.data):
            form.email.errors.append("An account with this email address already exists.")
        else:
            user = User(full_name=form.full_name.data, email=form.email.data, role=form.role.data,
                        organization=form.organization.data or None, phone=form.phone.data or None)
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            flash(f"{user.role_label} account created for {user.email}.", "success")
            return redirect(url_for("administration.users"))
    return render_template("administration/user_form.html", form=form, user=None)


@bp.route("/users/<int:user_id>/edit", methods=["GET", "POST"])
def edit_user(user_id):
    user = db.session.get(User, user_id) or abort(404)
    form = UserEditForm(obj=user)
    if form.validate_on_submit():
        is_self = user.id == current_user.id
        losing_admin = user.is_admin and user.is_active and (
            form.role.data != ROLE_ADMIN or not form.is_active.data
        )
        if _email_taken(form.email.data, exclude_id=user.id):
            form.email.errors.append("An account with this email address already exists.")
        elif is_self and (form.role.data != user.role or not form.is_active.data):
            flash("You cannot change your own role or deactivate your own account.", "danger")
        elif losing_admin and _active_admin_count() <= 1:
            flash("At least one active administrator must remain.", "danger")
        else:
            user.full_name = form.full_name.data
            user.email = form.email.data
            user.role = form.role.data
            user.organization = form.organization.data or None
            user.phone = form.phone.data or None
            user.is_active = form.is_active.data
            user.can_view_all_inspections = (
                form.can_view_all_inspections.data and form.role.data == ROLE_INSPECTOR
            )
            if form.new_password.data:
                user.set_password(form.new_password.data)
            db.session.commit()
            flash("User account updated.", "success")
            return redirect(url_for("administration.users"))
    return render_template("administration/user_form.html", form=form, user=user)


@bp.route("/users/<int:user_id>/toggle-active", methods=["POST"])
def toggle_user(user_id):
    user = db.session.get(User, user_id) or abort(404)
    form = ConfirmForm()
    if not form.validate_on_submit():
        abort(400)
    if user.id == current_user.id:
        flash("You cannot deactivate your own account.", "danger")
    elif user.is_admin and user.is_active and _active_admin_count() <= 1:
        flash("At least one active administrator must remain.", "danger")
    else:
        user.is_active = not user.is_active
        db.session.commit()
        flash(f"{user.email} {'activated' if user.is_active else 'deactivated'}.", "success")
    return redirect(request.referrer if request.referrer and request.referrer.startswith(request.host_url)
                    else url_for("administration.users"))


# --------------------------------------------------------------------------
# Categories
# --------------------------------------------------------------------------

def _category_name_taken(name, exclude_id=None):
    query = select(AdvertisementCategory.id).where(
        func.lower(AdvertisementCategory.name) == name.lower())
    if exclude_id:
        query = query.where(AdvertisementCategory.id != exclude_id)
    return db.session.scalar(query) is not None


@bp.route("/categories", methods=["GET", "POST"])
def categories():
    form = CategoryForm()
    if form.validate_on_submit():
        if _category_name_taken(form.name.data):
            form.name.errors.append("A category with this name already exists.")
        else:
            db.session.add(AdvertisementCategory(name=form.name.data,
                                                 description=form.description.data or None,
                                                 is_active=form.is_active.data))
            db.session.commit()
            flash("Category added.", "success")
            return redirect(url_for("administration.categories"))
    rows = db.session.execute(
        select(AdvertisementCategory, func.count(Advertisement.id))
        .outerjoin(Advertisement, Advertisement.category_id == AdvertisementCategory.id)
        .group_by(AdvertisementCategory.id)
        .order_by(AdvertisementCategory.name)
    ).all()
    return render_template("administration/categories.html", form=form, rows=rows,
                           confirm_form=ConfirmForm())


@bp.route("/categories/<int:category_id>/edit", methods=["GET", "POST"])
def edit_category(category_id):
    category = db.session.get(AdvertisementCategory, category_id) or abort(404)
    form = CategoryForm(obj=category)
    if form.validate_on_submit():
        if _category_name_taken(form.name.data, exclude_id=category.id):
            form.name.errors.append("A category with this name already exists.")
        else:
            form.populate_obj(category)
            category.description = category.description or None
            db.session.commit()
            flash("Category updated.", "success")
            return redirect(url_for("administration.categories"))
    return render_template("administration/simple_form.html", form=form,
                           title=f"Edit category: {category.name}",
                           back_url=url_for("administration.categories"))


@bp.route("/categories/<int:category_id>/toggle", methods=["POST"])
def toggle_category(category_id):
    category = db.session.get(AdvertisementCategory, category_id) or abort(404)
    if ConfirmForm().validate_on_submit():
        category.is_active = not category.is_active
        db.session.commit()
        flash(f"Category “{category.name}” {'activated' if category.is_active else 'deactivated'}. "
              "Deactivated categories are hidden from new registrations but kept on existing records.",
              "success")
    return redirect(url_for("administration.categories"))


# --------------------------------------------------------------------------
# Regulatory authorities
# --------------------------------------------------------------------------

def _authority_name_taken(name, exclude_id=None):
    query = select(RegulatoryAuthority.id).where(func.lower(RegulatoryAuthority.name) == name.lower())
    if exclude_id:
        query = query.where(RegulatoryAuthority.id != exclude_id)
    return db.session.scalar(query) is not None


def _save_authority(form, authority):
    form.populate_obj(authority)
    for field in ("jurisdiction", "state_or_territory", "contact_email", "contact_phone", "website"):
        if not getattr(authority, field):
            setattr(authority, field, None)


@bp.route("/authorities", methods=["GET", "POST"])
def authorities():
    form = AuthorityForm()
    form.state_or_territory.choices = _state_choices()
    if form.validate_on_submit():
        if _authority_name_taken(form.name.data):
            form.name.errors.append("An authority with this name already exists.")
        else:
            authority = RegulatoryAuthority()
            _save_authority(form, authority)
            db.session.add(authority)
            db.session.commit()
            flash("Regulatory authority added.", "success")
            return redirect(url_for("administration.authorities"))
    rows = db.session.execute(
        select(RegulatoryAuthority, func.count(Advertisement.id))
        .outerjoin(Advertisement, Advertisement.regulatory_authority_id == RegulatoryAuthority.id)
        .group_by(RegulatoryAuthority.id)
        .order_by(RegulatoryAuthority.name)
    ).all()
    return render_template("administration/authorities.html", form=form, rows=rows,
                           confirm_form=ConfirmForm())


@bp.route("/authorities/<int:authority_id>/edit", methods=["GET", "POST"])
def edit_authority(authority_id):
    authority = db.session.get(RegulatoryAuthority, authority_id) or abort(404)
    form = AuthorityForm(obj=authority)
    form.state_or_territory.choices = _state_choices()
    if form.validate_on_submit():
        if _authority_name_taken(form.name.data, exclude_id=authority.id):
            form.name.errors.append("An authority with this name already exists.")
        else:
            _save_authority(form, authority)
            db.session.commit()
            flash("Regulatory authority updated.", "success")
            return redirect(url_for("administration.authorities"))
    return render_template("administration/simple_form.html", form=form,
                           title=f"Edit authority: {authority.name}",
                           back_url=url_for("administration.authorities"))


@bp.route("/authorities/<int:authority_id>/toggle", methods=["POST"])
def toggle_authority(authority_id):
    authority = db.session.get(RegulatoryAuthority, authority_id) or abort(404)
    if ConfirmForm().validate_on_submit():
        authority.is_active = not authority.is_active
        db.session.commit()
        flash(f"“{authority.name}” {'activated' if authority.is_active else 'deactivated'}.", "success")
    return redirect(url_for("administration.authorities"))


# --------------------------------------------------------------------------
# States, territories and location options
# --------------------------------------------------------------------------

@bp.route("/locations")
def locations():
    rows = db.session.execute(
        select(StateOrTerritory, func.count(LocationOption.id))
        .outerjoin(LocationOption)
        .group_by(StateOrTerritory.id)
        .order_by(StateOrTerritory.kind, StateOrTerritory.name)
    ).all()
    return render_template("administration/locations.html", rows=rows, confirm_form=ConfirmForm())


@bp.route("/locations/<int:state_id>/toggle", methods=["POST"])
def toggle_state(state_id):
    state = db.session.get(StateOrTerritory, state_id) or abort(404)
    if ConfirmForm().validate_on_submit():
        state.is_active = not state.is_active
        db.session.commit()
        flash(f"{state.name} {'enabled' if state.is_active else 'disabled'} for new registrations.",
              "success")
    return redirect(url_for("administration.locations"))


@bp.route("/locations/<int:state_id>", methods=["GET", "POST"])
def state_locations(state_id):
    state = db.session.get(StateOrTerritory, state_id) or abort(404)
    form = LocationOptionForm()
    if form.validate_on_submit():
        exists = db.session.scalar(select(LocationOption.id).where(
            LocationOption.state_id == state.id,
            LocationOption.location_type == form.location_type.data,
            func.lower(LocationOption.name) == form.name.data.lower(),
        ))
        if exists:
            form.name.errors.append("This entry already exists.")
        else:
            db.session.add(LocationOption(state=state, location_type=form.location_type.data,
                                          name=form.name.data))
            db.session.commit()
            flash(f"{LOCATION_TYPES[form.location_type.data]} “{form.name.data}” added.", "success")
            return redirect(url_for("administration.state_locations", state_id=state.id))
    options = db.session.scalars(
        select(LocationOption).where(LocationOption.state_id == state.id)
        .order_by(LocationOption.location_type, LocationOption.name)
    ).all()
    grouped = {key: [o for o in options if o.location_type == key] for key in LOCATION_TYPES}
    return render_template("administration/state_locations.html", state=state, form=form,
                           grouped=grouped, location_types=LOCATION_TYPES, confirm_form=ConfirmForm())


@bp.route("/location-options/<int:option_id>/toggle", methods=["POST"])
def toggle_location_option(option_id):
    option = db.session.get(LocationOption, option_id) or abort(404)
    if ConfirmForm().validate_on_submit():
        option.is_active = not option.is_active
        db.session.commit()
    return redirect(url_for("administration.state_locations", state_id=option.state_id))


@bp.route("/location-options/<int:option_id>/delete", methods=["POST"])
def delete_location_option(option_id):
    option = db.session.get(LocationOption, option_id) or abort(404)
    state_id = option.state_id
    if ConfirmForm().validate_on_submit():
        # Options are only suggestions; advertisements store their own text,
        # so deleting an option never changes an existing record.
        db.session.delete(option)
        db.session.commit()
        flash("Location option deleted.", "success")
    return redirect(url_for("administration.state_locations", state_id=state_id))


# --------------------------------------------------------------------------
# Audit history
# --------------------------------------------------------------------------

@bp.route("/activity")
def activity():
    query = select(AdvertisementHistory).order_by(AdvertisementHistory.created_at.desc())
    action = request.args.get("action")
    if action in HISTORY_ACTIONS:
        query = query.where(AdvertisementHistory.action == action)
    code = (request.args.get("code") or "").strip()[:20]
    if code:
        query = query.where(AdvertisementHistory.advertisement_code.icontains(code, autoescape=True))
    return render_template("administration/activity.html", page=_paginate(query),
                           actions=HISTORY_ACTIONS, action=action, code=code)
