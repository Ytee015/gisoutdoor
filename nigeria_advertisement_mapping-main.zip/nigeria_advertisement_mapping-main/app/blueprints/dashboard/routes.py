from flask import abort, redirect, render_template, url_for
from flask_login import current_user, login_required
from sqlalchemy import func, select

from ...extensions import db
from ...models import (
    APPROVAL_STATUSES,
    ASSIGNMENT_STATUSES,
    PERMIT_CONDITIONS,
    PERMIT_EXPIRED,
    PERMIT_EXPIRING_SOON,
    PERMIT_MISSING,
    RECORD_SUBMITTED,
    Advertisement,
    AdvertisementCategory,
    AdvertisementHistory,
    InspectionAssignment,
    InspectionRecord,
    permit_condition_clause,
)
from . import bp


def _count(*conditions):
    query = select(func.count(Advertisement.id)).where(Advertisement.is_archived.is_(False))
    for condition in conditions:
        query = query.where(condition)
    return db.session.scalar(query) or 0


@bp.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.home"))
    return render_template("dashboard/index.html")


@bp.route("/dashboard")
@login_required
def home():
    if current_user.is_admin:
        return _admin_dashboard()
    if current_user.is_staff:
        return _staff_dashboard()
    if current_user.is_inspector:
        return redirect(url_for("inspections.dashboard"))
    abort(403)


def _admin_dashboard():
    status_counts = dict(
        db.session.execute(
            select(Advertisement.approval_status, func.count(Advertisement.id))
            .where(Advertisement.is_archived.is_(False))
            .group_by(Advertisement.approval_status)
        ).all()
    )
    permit_counts = {key: _count(permit_condition_clause(key)) for key in PERMIT_CONDITIONS}
    stats = {
        "total": sum(status_counts.values()),
        "approved": status_counts.get("approved", 0),
        "pending": status_counts.get("pending", 0),
        "rejected": status_counts.get("rejected", 0),
        "suspended": status_counts.get("suspended", 0),
        "expired": permit_counts[PERMIT_EXPIRED],
        "expiring": permit_counts[PERMIT_EXPIRING_SOON],
        "missing_permit": permit_counts[PERMIT_MISSING],
        "no_photo": _count(Advertisement.photograph_path.is_(None)),
        "no_coordinates": _count(
            (Advertisement.latitude.is_(None)) | (Advertisement.longitude.is_(None))
        ),
    }

    by_state = db.session.execute(
        select(Advertisement.state_or_territory, func.count(Advertisement.id))
        .where(Advertisement.is_archived.is_(False))
        .group_by(Advertisement.state_or_territory)
        .order_by(func.count(Advertisement.id).desc())
        .limit(10)
    ).all()
    by_category = db.session.execute(
        select(AdvertisementCategory.name, func.count(Advertisement.id))
        .join(Advertisement.category)
        .where(Advertisement.is_archived.is_(False))
        .group_by(AdvertisementCategory.name)
        .order_by(func.count(Advertisement.id).desc())
    ).all()
    charts = {
        "state": {"labels": [r[0] for r in by_state], "values": [r[1] for r in by_state]},
        "category": {"labels": [r[0] for r in by_category], "values": [r[1] for r in by_category]},
        "approval": {
            "labels": [label for label, _ in APPROVAL_STATUSES.values()],
            "values": [status_counts.get(key, 0) for key in APPROVAL_STATUSES],
            "keys": list(APPROVAL_STATUSES),
        },
        "permit": {
            "labels": [label for label, _ in PERMIT_CONDITIONS.values()],
            "values": [permit_counts[key] for key in PERMIT_CONDITIONS],
            "keys": list(PERMIT_CONDITIONS),
        },
    }

    recent = db.session.scalars(
        select(Advertisement).where(Advertisement.is_archived.is_(False))
        .order_by(Advertisement.created_at.desc()).limit(6)
    ).all()
    activity = db.session.scalars(
        select(AdvertisementHistory).order_by(AdvertisementHistory.created_at.desc()).limit(10)
    ).all()

    inspection_counts = dict(
        db.session.execute(
            select(InspectionAssignment.status, func.count(InspectionAssignment.id))
            .group_by(InspectionAssignment.status)
        ).all()
    )
    inspections = {key: inspection_counts.get(key, 0) for key in ASSIGNMENT_STATUSES}
    recent_records = db.session.scalars(
        select(InspectionRecord).where(InspectionRecord.status == RECORD_SUBMITTED)
        .order_by(InspectionRecord.submitted_at.desc()).limit(20)
    ).all()
    flagged = [r for r in recent_records if r.is_flagged][:5]

    return render_template(
        "dashboard/admin.html",
        stats=stats, charts=charts, recent=recent, activity=activity,
        inspections=inspections, flagged=flagged,
    )


def _staff_dashboard():
    mine = Advertisement.submitted_by_id == current_user.id
    stats = {
        "total": _count(mine),
        "pending": _count(mine, Advertisement.approval_status == "pending"),
        "approved": _count(mine, Advertisement.approval_status == "approved"),
        "rejected": _count(mine, Advertisement.approval_status == "rejected"),
        "suspended": _count(mine, Advertisement.approval_status == "suspended"),
    }
    recent = db.session.scalars(
        select(Advertisement).where(mine, Advertisement.is_archived.is_(False))
        .order_by(Advertisement.created_at.desc()).limit(6)
    ).all()
    return render_template("dashboard/staff.html", stats=stats, recent=recent)
