from flask import jsonify, render_template, request, url_for
from flask_login import current_user, login_required

from ...extensions import db
from ...filters import apply_filters, filter_choices, parse_filters
from ...models import Advertisement
from ...permissions import visible_advertisements_query
from ...utils import format_date
from . import bp

MAX_MARKERS = 1000


def _parse_bbox(value):
    """'south,west,north,east' -> tuple of floats, or None if invalid."""
    try:
        south, west, north, east = (float(part) for part in (value or "").split(","))
    except ValueError:
        return None
    if not (-90 <= south <= north <= 90 and -180 <= west <= 180 and -180 <= east <= 180):
        return None
    return south, west, north, east


def advertisement_feature(ad):
    """Only the fields the map needs — no submitter, contact or account data."""
    return {
        "id": ad.id,
        "code": ad.advertisement_code,
        "title": ad.title,
        "category": ad.category.name if ad.category else None,
        "advertiser": ad.advertiser_name,
        "address": ad.display_address,
        "city": ad.city,
        "state": ad.state_or_territory,
        "lat": ad.latitude,
        "lng": ad.longitude,
        "approval_status": ad.approval_status,
        "approval_label": ad.approval_status_label,
        "permit_condition": ad.permit_condition,
        "permit_label": ad.permit_condition_label,
        "permit_expiry": format_date(ad.permit_expiry_date) if ad.permit_expiry_date else None,
        "photo_url": url_for("advertisements.photo", advertisement_id=ad.id, size="thumb")
        if ad.photograph_path else None,
        "detail_url": url_for("advertisements.detail", advertisement_id=ad.id),
    }


@bp.route("/")
@login_required
def index():
    return render_template("map/index.html", **filter_choices())


@bp.route("/api/advertisements")
@login_required
def api_advertisements():
    filters = parse_filters(request.args)
    query = visible_advertisements_query(current_user)
    query = apply_filters(query, filters).where(
        Advertisement.latitude.is_not(None),
        Advertisement.longitude.is_not(None),
        Advertisement.latitude.between(-90, 90),
        Advertisement.longitude.between(-180, 180),
    )
    bbox = _parse_bbox(request.args.get("bbox"))
    if bbox:
        south, west, north, east = bbox
        query = query.where(Advertisement.latitude.between(south, north))
        if west <= east:
            query = query.where(Advertisement.longitude.between(west, east))
        else:  # view crosses the antimeridian
            query = query.where(
                (Advertisement.longitude >= west) | (Advertisement.longitude <= east)
            )
    rows = db.session.scalars(
        query.order_by(Advertisement.created_at.desc()).limit(MAX_MARKERS + 1)
    ).all()
    truncated = len(rows) > MAX_MARKERS
    features = [advertisement_feature(ad) for ad in rows[:MAX_MARKERS]]
    return jsonify({"count": len(features), "truncated": truncated, "advertisements": features})
