from flask import Blueprint

bp = Blueprint("map", __name__, url_prefix="/map")

from . import routes  # noqa: E402,F401
