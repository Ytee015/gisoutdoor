from flask import Blueprint

bp = Blueprint("advertisements", __name__, url_prefix="/advertisements")

from . import routes  # noqa: E402,F401
