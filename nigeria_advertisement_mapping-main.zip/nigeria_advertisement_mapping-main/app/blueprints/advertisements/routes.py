from flask import (
    abort,
    current_app,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for,
)
from flask_login import current_user, login_required
from sqlalchemy import func, select

from ...decorators import admin_required, role_required
from ...extensions import db
from ...filters import (
    SORT_OPTIONS,
    active_filter_count,
    apply_filters,
    filter_choices,
    parse_filters,
)
from ...forms import AdvertisementForm, ConfirmForm, ReviewForm
from ...models import (
    APPROVAL_APPROVED,
    APPROVAL_PENDING,
    APPROVAL_REJECTED,
    APPROVAL_STATUSES,
    APPROVAL_SUSPENDED,
    LOCATION_TYPES,
    PERMIT_CHECKED,
    PERMIT_CONDITIONS,
    PERMIT_EXPIRED,
    PERMIT_EXPIRING_SOON,
    PERMIT_VERIFICATION_STATUSES,
    ROLE_ADMIN,
    ROLE_STAFF,
    Advertisement,
    AdvertisementCategory,
    LocationOption,
    RegulatoryAuthority,
    StateOrTerritory,
    permit_condition_clause,
    utcnow,
)
from ...nigeria import DEFAULT_COUNTRY
from ...permissions import (
    can_edit_advertisement,
    can_view_advertisement,
    visible_advertisements_query,
)
from ...services import diff_snapshots, generate_advertisement_code, record_history, snapshot_advertisement
from ...utils import ImageUploadError, delete_image_files, resolve_upload, save_image, thumbnail_path
from . import bp

# decision -> (allowed current statuses, new status, history action)
REVIEW_TRANSITIONS = {
    "approve": ((APPROVAL_PENDING,), APPROVAL_APPROVED, "approved"),
    "reject": ((APPROVAL_PENDING,), APPROVAL_REJECTED, "rejected"),
    "suspend": ((APPROVAL_APPROVED,), APPROVAL_SUSPENDED, "suspended"),
    "reinstate": ((APPROVAL_SUSPENDED,), APPROVAL_APPROVED, "reinstated"),
}
DECISION_LABELS = {
    "approve": "Approve",
    "reject": "Reject",
    "suspend": "Suspend",
    "reinstate": "Lift suspension (approve)",
}
PERMIT_FIELDS = ("permit_number", "regulatory_authority_id", "permit_issue_date", "permit_expiry_date")


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def get_visible_advertisement_or_404(advertisement_id):
    advertisement = db.session.get(Advertisement, advertisement_id)
    # 404 (not 403) so other users' records are not revealed to exist.
    if advertisement is None or not can_view_advertisement(current_user, advertisement):
        abort(404)
    return advertisement


def _choices_with_current(rows, current_id, label=lambda r: r.name):
    choices = [(r.id, label(r)) for r in rows if r.is_active or r.id == current_id]
    return choices


def prepare_advertisement_form(form, advertisement=None):
    current = advertisement or Advertisement()
    categories = db.session.scalars(select(AdvertisementCategory).order_by(AdvertisementCategory.name))
    form.category_id.choices = [(0, "— Select category —")] + _choices_with_current(
        categories, current.category_id
    )
    states = db.session.scalars(select(StateOrTerritory).order_by(StateOrTerritory.name)).all()
    form.state_or_territory.choices = [("", "— Select state / territory —")] + [
        (s.name, f"{s.name} (Territory)" if s.is_territory else s.name)
        for s in states if s.is_active or s.name == current.state_or_territory
    ]
    authorities = db.session.scalars(select(RegulatoryAuthority).order_by(RegulatoryAuthority.name))
    form.regulatory_authority_id.choices = [(0, "— Not specified —")] + _choices_with_current(
        authorities, current.regulatory_authority_id
    )
    statuses = dict(PERMIT_VERIFICATION_STATUSES)
    if not current_user.is_admin and current.permit_verification_status != PERMIT_CHECKED:
        # Only administrators may record that a permit was checked.
        statuses.pop(PERMIT_CHECKED)
    form.permit_verification_status.choices = list(statuses.items())


def _populate(advertisement, form):
    for name in (
        "title", "description", "advertiser_name", "contact_person", "contact_phone",
        "state_or_territory", "city", "lga", "street_or_road", "full_address", "landmark",
        "latitude", "longitude", "advertisement_type", "width", "height", "installation_date",
        "condition", "permit_number", "permit_issue_date", "permit_expiry_date",
        "permit_verification_status",
    ):
        value = getattr(form, name).data
        setattr(advertisement, name, value if value != "" else None)
    advertisement.category_id = form.category_id.data
    advertisement.regulatory_authority_id = form.regulatory_authority_id.data or None
    advertisement.country = DEFAULT_COUNTRY


def _validate_choices(form):
    """Reject the 0 placeholder for required select fields."""
    if not form.category_id.data:
        form.category_id.errors.append("Select a category.")
        return False
    return True


def _photo_still_referenced(relative_path):
    count = db.session.scalar(
        select(func.count(Advertisement.id)).where(Advertisement.photograph_path == relative_path)
    )
    return bool(count)


def _discard_photo(relative_path):
    """Delete files for a photo that is no longer referenced by any record."""
    if relative_path and not _photo_still_referenced(relative_path):
        delete_image_files(relative_path)


def _store_uploaded_photo(form):
    file = form.photograph.data
    if not (file and file.filename):
        return None
    try:
        return save_image(file, current_app.config["ADVERTISEMENT_UPLOAD_SUBDIR"])
    except ImageUploadError as exc:
        form.photograph.errors.append(str(exc))
        return False


def _commit_or_cleanup(stored):
    """Commit; if that fails, remove the file that was just written."""
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        if stored:
            delete_image_files(stored.relative_path)
        raise


# --------------------------------------------------------------------------
# List / create / detail / edit
# --------------------------------------------------------------------------

@bp.route("/")
@role_required(ROLE_ADMIN, ROLE_STAFF)
def list_advertisements():
    filters = parse_filters(request.args)
    sort = request.args.get("sort", "newest")
    if sort not in SORT_OPTIONS:
        sort = "newest"
    include_archived = current_user.is_admin and filters["archived"] in ("include", "only")
    query = visible_advertisements_query(current_user, include_archived=include_archived)
    query = apply_filters(query, filters).order_by(SORT_OPTIONS[sort][1], Advertisement.id.desc())
    page = db.paginate(query, page=request.args.get("page", 1, type=int),
                       per_page=current_app.config["ITEMS_PER_PAGE"], error_out=False)
    return render_template(
        "advertisements/list.html",
        page=page, filters=filters, sort=sort, sort_options=SORT_OPTIONS,
        filter_count=active_filter_count(filters), **filter_choices(),
    )


@bp.route("/new", methods=["GET", "POST"])
@role_required(ROLE_ADMIN, ROLE_STAFF)
def create():
    # Staff must supply an actual photograph and coordinates; administrators
    # may record legacy entries without them.
    form = AdvertisementForm(
        require_coordinates=current_user.is_staff, require_photograph=current_user.is_staff
    )
    prepare_advertisement_form(form)
    if form.validate_on_submit() and _validate_choices(form):
        stored = _store_uploaded_photo(form)
        if stored is not False:
            advertisement = Advertisement(
                submitted_by=current_user,
                approval_status=APPROVAL_PENDING,
                advertisement_code=generate_advertisement_code(),
            )
            _populate(advertisement, form)
            if stored:
                advertisement.photograph_path = stored.relative_path
            db.session.add(advertisement)
            db.session.flush()
            record_history(advertisement, current_user, "created",
                           new=snapshot_advertisement(advertisement))
            _commit_or_cleanup(stored)
            flash(f"Advertisement {advertisement.advertisement_code} registered and submitted "
                  "for review.", "success")
            return redirect(url_for("advertisements.detail", advertisement_id=advertisement.id))
    if request.method == "POST" and form.photograph.data and form.photograph.data.filename:
        flash("Please correct the highlighted fields and select the photograph again.", "warning")
    return render_template("advertisements/form.html", form=form, advertisement=None)


@bp.route("/<int:advertisement_id>")
@login_required
def detail(advertisement_id):
    advertisement = get_visible_advertisement_or_404(advertisement_id)
    review_form = None
    if current_user.is_admin and not advertisement.is_archived:
        review_form = ReviewForm()
        review_form.decision.choices = [
            (key, DECISION_LABELS[key]) for key, (allowed, _, _) in REVIEW_TRANSITIONS.items()
            if advertisement.approval_status in allowed
        ]
    show_history = current_user.is_admin or advertisement.submitted_by_id == current_user.id
    return render_template(
        "advertisements/detail.html",
        advertisement=advertisement,
        review_form=review_form,
        confirm_form=ConfirmForm(),
        can_edit=can_edit_advertisement(current_user, advertisement),
        show_history=show_history,
    )


@bp.route("/<int:advertisement_id>/edit", methods=["GET", "POST"])
@role_required(ROLE_ADMIN, ROLE_STAFF)
def edit(advertisement_id):
    advertisement = get_visible_advertisement_or_404(advertisement_id)
    if not can_edit_advertisement(current_user, advertisement):
        abort(403)
    form = AdvertisementForm(obj=advertisement, require_coordinates=current_user.is_staff)
    prepare_advertisement_form(form, advertisement)
    if form.validate_on_submit() and _validate_choices(form):
        stored = _store_uploaded_photo(form)
        if stored is not False:
            before = snapshot_advertisement(advertisement)
            _populate(advertisement, form)

            if (current_user.is_staff and before["permit_verification_status"] == PERMIT_CHECKED
                    and any(before[f] != snapshot_advertisement(advertisement, (f,))[f]
                            for f in PERMIT_FIELDS)):
                # Changed permit details have not been checked by an admin.
                advertisement.permit_verification_status = "unverified"

            old_photo = None
            if stored:
                old_photo = advertisement.photograph_path
                advertisement.photograph_path = stored.relative_path
            elif current_user.is_admin and form.remove_photograph.data and advertisement.photograph_path:
                old_photo = advertisement.photograph_path
                advertisement.photograph_path = None

            action = "updated"
            if current_user.is_staff and advertisement.approval_status == APPROVAL_REJECTED:
                advertisement.approval_status = APPROVAL_PENDING
                action = "resubmitted"

            previous, new = diff_snapshots(before, snapshot_advertisement(advertisement))
            if previous or new:
                if action == "updated" and set(new) == {"photograph_path"}:
                    action = "photo_replaced" if stored else "photo_removed"
                record_history(advertisement, current_user, action, previous, new)
            _commit_or_cleanup(stored)
            _discard_photo(old_photo)
            flash("Advertisement updated." if action != "resubmitted"
                  else "Advertisement updated and resubmitted for review.", "success")
            return redirect(url_for("advertisements.detail", advertisement_id=advertisement.id))
    if request.method == "POST" and form.photograph.data and form.photograph.data.filename:
        flash("Please correct the highlighted fields and select the photograph again.", "warning")
    return render_template("advertisements/form.html", form=form, advertisement=advertisement)


@bp.route("/<int:advertisement_id>/photo")
@login_required
def photo(advertisement_id):
    advertisement = get_visible_advertisement_or_404(advertisement_id)
    if not advertisement.photograph_path:
        abort(404)
    relative = advertisement.photograph_path
    if request.args.get("size") == "thumb":
        thumb = thumbnail_path(relative)
        if resolve_upload(thumb) and resolve_upload(thumb).is_file():
            relative = thumb
    path = resolve_upload(relative)
    if path is None or not path.is_file():
        abort(404)
    response = send_from_directory(current_app.config["UPLOAD_FOLDER"], relative, max_age=3600)
    response.headers["Cache-Control"] = "private, max-age=3600"
    return response


# --------------------------------------------------------------------------
# Review workflow
# --------------------------------------------------------------------------

@bp.route("/<int:advertisement_id>/review", methods=["POST"])
@admin_required
def review(advertisement_id):
    advertisement = get_visible_advertisement_or_404(advertisement_id)
    if advertisement.is_archived:
        abort(409)
    form = ReviewForm()
    form.decision.choices = [(key, label) for key, label in DECISION_LABELS.items()]
    back = (url_for("advertisements.review_queue") if request.form.get("next") == "queue"
            else url_for("advertisements.detail", advertisement_id=advertisement.id))
    if not form.validate_on_submit():
        for errors in form.errors.values():
            for error in errors:
                flash(f"{advertisement.advertisement_code}: {error}", "danger")
        return redirect(back)

    allowed, new_status, action = REVIEW_TRANSITIONS[form.decision.data]
    if advertisement.approval_status not in allowed:
        flash(f"An advertisement that is {advertisement.approval_status_label.lower()} cannot be "
              f"given the decision “{DECISION_LABELS[form.decision.data]}”.", "danger")
        return redirect(back)

    previous = {"approval_status": advertisement.approval_status,
                "review_notes": advertisement.review_notes}
    advertisement.approval_status = new_status
    advertisement.review_notes = form.notes.data or None
    advertisement.reviewed_by = current_user
    advertisement.reviewed_at = utcnow()
    record_history(advertisement, current_user, action, previous,
                   {"approval_status": new_status, "review_notes": advertisement.review_notes},
                   notes=form.notes.data or None)
    db.session.commit()
    flash(f"{advertisement.advertisement_code}: {APPROVAL_STATUSES[new_status][0]}.", "success")
    return redirect(back)


@bp.route("/review-queue")
@admin_required
def review_queue():
    query = (
        select(Advertisement)
        .where(Advertisement.approval_status == APPROVAL_PENDING, Advertisement.is_archived.is_(False))
        .order_by(Advertisement.created_at.asc())
    )
    page = db.paginate(query, page=request.args.get("page", 1, type=int),
                       per_page=current_app.config["ITEMS_PER_PAGE"], error_out=False)
    review_form = ReviewForm()
    review_form.decision.choices = [("approve", "Approve"), ("reject", "Reject")]
    return render_template("advertisements/review_queue.html", page=page, review_form=review_form)


# --------------------------------------------------------------------------
# Archive / restore / delete
# --------------------------------------------------------------------------

@bp.route("/<int:advertisement_id>/archive", methods=["POST"])
@admin_required
def archive(advertisement_id):
    advertisement = get_visible_advertisement_or_404(advertisement_id)
    form = ConfirmForm()
    if form.validate_on_submit() and not advertisement.is_archived:
        if any(a.is_open for a in advertisement.inspection_assignments):
            flash("This advertisement has an open inspection. Complete or reassign it before "
                  "archiving.", "danger")
        else:
            advertisement.is_archived = True
            advertisement.archived_at = utcnow()
            advertisement.archived_by = current_user
            record_history(advertisement, current_user, "archived",
                           {"is_archived": False}, {"is_archived": True})
            db.session.commit()
            flash(f"{advertisement.advertisement_code} archived. It is hidden from lists, the map "
                  "and reports, and can be restored.", "success")
    return redirect(url_for("advertisements.detail", advertisement_id=advertisement.id))


@bp.route("/<int:advertisement_id>/restore", methods=["POST"])
@admin_required
def restore(advertisement_id):
    advertisement = get_visible_advertisement_or_404(advertisement_id)
    form = ConfirmForm()
    if form.validate_on_submit() and advertisement.is_archived:
        advertisement.is_archived = False
        advertisement.archived_at = None
        advertisement.archived_by = None
        record_history(advertisement, current_user, "restored",
                       {"is_archived": True}, {"is_archived": False})
        db.session.commit()
        flash(f"{advertisement.advertisement_code} restored.", "success")
    return redirect(url_for("advertisements.detail", advertisement_id=advertisement.id))


@bp.route("/<int:advertisement_id>/delete", methods=["GET", "POST"])
@admin_required
def delete(advertisement_id):
    advertisement = get_visible_advertisement_or_404(advertisement_id)
    blockers = []
    if not advertisement.is_archived:
        blockers.append("Archive the advertisement before deleting it permanently.")
    if advertisement.inspection_assignments or advertisement.inspection_records:
        blockers.append("It has inspection records, which must be preserved. Keep it archived instead.")
    form = ConfirmForm()
    if request.method == "POST":
        if blockers or not form.validate_on_submit():
            abort(409)
        code = advertisement.advertisement_code
        photo_path = advertisement.photograph_path
        # The history entry outlives the record (its advertisement_id becomes NULL).
        record_history(advertisement, current_user, "deleted",
                       previous=snapshot_advertisement(advertisement),
                       notes="Record permanently deleted by an administrator.")
        db.session.flush()
        db.session.delete(advertisement)
        db.session.commit()
        _discard_photo(photo_path)
        flash(f"{code} was permanently deleted. Its audit history has been kept.", "success")
        return redirect(url_for("advertisements.list_advertisements", archived="only"))
    return render_template("advertisements/delete_confirm.html", advertisement=advertisement,
                           blockers=blockers, form=form)


# --------------------------------------------------------------------------
# Permit monitoring
# --------------------------------------------------------------------------

@bp.route("/permits")
@admin_required
def permits():
    condition = request.args.get("condition", "alerts")
    if condition not in PERMIT_CONDITIONS and condition != "alerts":
        condition = "alerts"
    base = visible_advertisements_query(current_user)
    counts = {
        key: db.session.scalar(
            select(func.count()).select_from(base.where(permit_condition_clause(key)).subquery())
        )
        for key in PERMIT_CONDITIONS
    }
    if condition == "alerts":
        clause = permit_condition_clause(PERMIT_EXPIRED) | permit_condition_clause(PERMIT_EXPIRING_SOON)
    else:
        clause = permit_condition_clause(condition)
    query = base.where(clause).order_by(
        Advertisement.permit_expiry_date.is_(None), Advertisement.permit_expiry_date.asc()
    )
    page = db.paginate(query, page=request.args.get("page", 1, type=int),
                       per_page=current_app.config["ITEMS_PER_PAGE"], error_out=False)
    return render_template(
        "advertisements/permits.html", page=page, counts=counts, condition=condition,
        conditions=PERMIT_CONDITIONS,
        warning_days=current_app.config["PERMIT_EXPIRY_WARNING_DAYS"],
    )


# --------------------------------------------------------------------------
# Location suggestions for the registration form
# --------------------------------------------------------------------------

@bp.route("/api/location-options")
@role_required(ROLE_ADMIN, ROLE_STAFF)
def location_options():
    state = db.session.scalar(
        select(StateOrTerritory).where(StateOrTerritory.name == request.args.get("state", ""))
    )
    result = {key: [] for key in LOCATION_TYPES}
    if state:
        rows = db.session.scalars(
            select(LocationOption)
            .where(LocationOption.state_id == state.id, LocationOption.is_active.is_(True))
            .order_by(LocationOption.name)
        )
        for row in rows:
            result[row.location_type].append(row.name)
    return jsonify(result)
