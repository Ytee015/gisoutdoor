from flask import flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required, login_user, logout_user
from sqlalchemy import func, select

from ...extensions import db
from ...forms import ChangePasswordForm, LoginForm, ProfileForm, RegistrationForm
from ...models import ROLE_ADMIN, ROLE_INSPECTOR, ROLE_STAFF, ROLE_LABELS, User, utcnow
from ...utils import is_safe_redirect
from . import bp

ROLE_LOGIN_ROUTES = {
    "admin": ROLE_ADMIN,
    "inspector": ROLE_INSPECTOR,
    "staff": ROLE_STAFF,
}
ROLE_LOGIN_LABELS = {
    "admin": "Administrator",
    "inspector": "Inspector",
    "staff": "Staff",
}


def _email_taken(email, exclude_id=None):
    query = select(User.id).where(func.lower(User.email) == email.lower())
    if exclude_id:
        query = query.where(User.id != exclude_id)
    return db.session.scalar(query) is not None


@bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.home"))
    form = RegistrationForm()
    if form.validate_on_submit():
        if _email_taken(form.email.data):
            form.email.errors.append("An account with this email address already exists.")
        else:
            # Role is fixed server-side; nothing in the request can change it.
            user = User(
                full_name=form.full_name.data,
                email=form.email.data,
                organization=form.organization.data or None,
                phone=form.phone.data or None,
                role=ROLE_STAFF,
            )
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            flash("Your staff account has been created. Please sign in.", "success")
            return redirect(url_for("auth.login"))
    return render_template("auth/register.html", form=form)


def _login_for_role(role=None):
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.home"))
    required_role = ROLE_LOGIN_ROUTES.get(role) if role else None
    form = LoginForm()
    if form.validate_on_submit():
        user = db.session.scalar(select(User).where(func.lower(User.email) == form.email.data))
        if user is None or not user.check_password(form.password.data):
            flash("Invalid email address or password.", "danger")
        elif required_role and user.role != required_role:
            label = ROLE_LOGIN_LABELS.get(role, role.title())
            flash(f"This email is not registered as a {label} account.", "danger")
        elif not user.is_active:
            flash("This account has been deactivated. Please contact an administrator.", "danger")
        else:
            login_user(user, remember=form.remember.data)
            user.last_login_at = utcnow()
            db.session.commit()
            flash(f"Welcome back, {user.full_name}.", "success")
            target = request.args.get("next")
            if is_safe_redirect(target):
                return redirect(target)
            return redirect(url_for("dashboard.home"))
    return render_template(
        "auth/login.html",
        form=form,
        required_role=role,
        required_label=ROLE_LOGIN_LABELS.get(role, "Account"),
        role_choices=ROLE_LOGIN_LABELS,
    )


@bp.route("/login", methods=["GET", "POST"])
def login():
    return _login_for_role()


@bp.route("/login/<role>", methods=["GET", "POST"]) 
def login_as(role):
    if role not in ROLE_LOGIN_ROUTES:
        return redirect(url_for("auth.login"))
    return _login_for_role(role)


@bp.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    flash("You have been signed out.", "info")
    return redirect(url_for("auth.login"))


@bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    profile_form = ProfileForm(obj=current_user, prefix="profile")
    password_form = ChangePasswordForm(prefix="password")

    if profile_form.submit.data and profile_form.validate_on_submit():
        current_user.full_name = profile_form.full_name.data
        current_user.organization = profile_form.organization.data or None
        current_user.phone = profile_form.phone.data or None
        db.session.commit()
        flash("Profile updated.", "success")
        return redirect(url_for("auth.profile"))

    if password_form.submit_password.data and password_form.validate_on_submit():
        if not current_user.check_password(password_form.current_password.data):
            password_form.current_password.errors.append("Your current password is incorrect.")
        else:
            current_user.set_password(password_form.new_password.data)
            db.session.commit()
            flash("Password changed.", "success")
            return redirect(url_for("auth.profile"))

    return render_template(
        "auth/profile.html", profile_form=profile_form, password_form=password_form
    )
