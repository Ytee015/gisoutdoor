"""Flask-WTF forms. Every FlaskForm carries CSRF protection.

Choice lists that depend on the database or on the user's role are set in
the route before validation, so WTForms rejects any value that was not
offered (e.g. a staff member posting permit_verification_status=checked).
"""

import re
from datetime import date, timedelta

from flask_wtf import FlaskForm
from flask_wtf.file import FileAllowed, FileField
from wtforms import (
    BooleanField,
    DateField,
    DateTimeLocalField,
    EmailField,
    FloatField,
    MultipleFileField,
    PasswordField,
    SelectField,
    StringField,
    SubmitField,
    TextAreaField,
    URLField,
)
from wtforms.validators import (
    URL,
    DataRequired,
    Email,
    EqualTo,
    InputRequired,
    Length,
    NumberRange,
    Optional,
    Regexp,
    ValidationError,
)

from .models import (
    ADVERTISEMENT_TYPES,
    DETAILS_VERIFICATIONS,
    FOLLOW_UP_ACTIONS,
    LOCATION_TYPES,
    LOCATION_VERIFICATIONS,
    PERMIT_OBSERVATIONS,
    PHYSICAL_CONDITIONS,
    ROLE_LABELS,
    SITE_CONDITIONS,
    utcnow,
)
from .nigeria import NIGERIA_LAT_RANGE, NIGERIA_LNG_RANGE, coordinates_in_nigeria

IMAGE_TYPES = ["jpg", "jpeg", "png", "webp"]
PHONE_PATTERN = r"^[0-9+()\-\s]{7,20}$"
PHONE_MESSAGE = "Enter a valid phone number (digits, spaces, +, - and brackets only)."


def _blank(label="— Select —"):
    return [("", label)]


def strip(value):
    return value.strip() if isinstance(value, str) else value


def lower_strip(value):
    return value.strip().lower() if isinstance(value, str) else value


class StrongPassword:
    def __call__(self, form, field):
        value = field.data or ""
        if len(value) < 8 or not re.search(r"[A-Za-z]", value) or not re.search(r"\d", value):
            raise ValidationError(
                "Use at least 8 characters, including at least one letter and one number."
            )


# --------------------------------------------------------------------------
# Authentication and profile
# --------------------------------------------------------------------------

class LoginForm(FlaskForm):
    email = EmailField("Email address", validators=[DataRequired(), Email()],
                       filters=[lower_strip])
    password = PasswordField("Password", validators=[DataRequired()])
    remember = BooleanField("Keep me signed in on this device")
    submit = SubmitField("Sign in")


class RegistrationForm(FlaskForm):
    """Public sign-up. There is deliberately no role field: accounts created
    here are always Staff."""

    full_name = StringField("Full name", validators=[DataRequired(), Length(max=120)],
                            filters=[strip])
    email = EmailField("Email address", validators=[DataRequired(), Email(), Length(max=120)],
                       filters=[lower_strip])
    organization = StringField("Organisation / company", validators=[Optional(), Length(max=150)],
                               filters=[strip])
    phone = StringField("Phone number", validators=[Optional(), Regexp(PHONE_PATTERN, message=PHONE_MESSAGE)],
                        filters=[strip])
    password = PasswordField("Password", validators=[DataRequired(), StrongPassword()])
    confirm_password = PasswordField(
        "Confirm password", validators=[DataRequired(), EqualTo("password", "Passwords do not match.")]
    )
    submit = SubmitField("Create staff account")


class ProfileForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(max=120)],
                            filters=[strip])
    organization = StringField("Organisation / company", validators=[Optional(), Length(max=150)],
                               filters=[strip])
    phone = StringField("Phone number", validators=[Optional(), Regexp(PHONE_PATTERN, message=PHONE_MESSAGE)],
                        filters=[strip])
    submit = SubmitField("Save profile")


class ChangePasswordForm(FlaskForm):
    current_password = PasswordField("Current password", validators=[DataRequired()])
    new_password = PasswordField("New password", validators=[DataRequired(), StrongPassword()])
    confirm_password = PasswordField(
        "Confirm new password",
        validators=[DataRequired(), EqualTo("new_password", "Passwords do not match.")],
    )
    submit_password = SubmitField("Change password")


class ConfirmForm(FlaskForm):
    """Empty form used for CSRF-protected POST buttons (archive, start, ...)."""

    submit = SubmitField("Confirm")


# --------------------------------------------------------------------------
# Advertisements
# --------------------------------------------------------------------------

class AdvertisementForm(FlaskForm):
    # Basic information
    title = StringField("Advertisement title / name", validators=[DataRequired(), Length(max=150)],
                        filters=[strip])
    description = TextAreaField("Description", validators=[Optional(), Length(max=2000)],
                                filters=[strip])
    category_id = SelectField("Category", coerce=int, validators=[InputRequired()])
    advertiser_name = StringField("Advertiser / company name",
                                  validators=[DataRequired(), Length(max=150)], filters=[strip])
    contact_person = StringField("Contact person", validators=[Optional(), Length(max=120)],
                                 filters=[strip])
    contact_phone = StringField("Contact phone", validators=[Optional(), Regexp(PHONE_PATTERN, message=PHONE_MESSAGE)],
                                filters=[strip])

    # Geographical information
    state_or_territory = SelectField("State / territory", validators=[DataRequired()])
    city = StringField("City / town", validators=[DataRequired(), Length(max=100)], filters=[strip])
    lga = StringField("Local Government Area (LGA)", validators=[Optional(), Length(max=100)],
                      filters=[strip])
    street_or_road = StringField("Street / road", validators=[Optional(), Length(max=150)],
                                 filters=[strip])
    full_address = StringField("Full address", validators=[DataRequired(), Length(max=255)],
                               filters=[strip])
    landmark = StringField("Nearby landmark", validators=[Optional(), Length(max=150)],
                           filters=[strip])
    latitude = FloatField("Latitude", validators=[Optional()])
    longitude = FloatField("Longitude", validators=[Optional()])

    # Advertisement details
    advertisement_type = SelectField(
        "Advertisement type",
        choices=_blank() + list(ADVERTISEMENT_TYPES.items()),
        validators=[DataRequired()],
    )
    width = FloatField("Width (m)", validators=[Optional(), NumberRange(min=0.1, max=500)])
    height = FloatField("Height (m)", validators=[Optional(), NumberRange(min=0.1, max=500)])
    installation_date = DateField("Installation date", validators=[Optional()])
    condition = SelectField(
        "Physical condition",
        choices=_blank() + list(PHYSICAL_CONDITIONS.items()),
        validators=[DataRequired()],
    )

    # Photograph
    photograph = FileField(
        "Upload Billboard Photograph",
        validators=[FileAllowed(IMAGE_TYPES, "Upload a JPEG, PNG or WebP photograph.")],
    )
    remove_photograph = BooleanField("Remove the current photograph")

    # Permit information
    permit_number = StringField("Permit number", validators=[Optional(), Length(max=80)],
                                filters=[strip])
    regulatory_authority_id = SelectField("Regulatory authority", coerce=int, default=0)
    permit_issue_date = DateField("Permit issue date", validators=[Optional()])
    permit_expiry_date = DateField("Permit expiry date", validators=[Optional()])
    permit_verification_status = SelectField("Permit verification status")

    submit = SubmitField("Save advertisement")

    def __init__(self, *args, require_coordinates=False, require_photograph=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.require_coordinates = require_coordinates
        self.require_photograph = require_photograph

    def validate_latitude(self, field):
        if field.data is not None and not -90 <= field.data <= 90:
            raise ValidationError("Latitude must be between -90 and 90.")

    def validate_longitude(self, field):
        if field.data is not None and not -180 <= field.data <= 180:
            raise ValidationError("Longitude must be between -180 and 180.")

    def validate_installation_date(self, field):
        if field.data and field.data > date.today():
            raise ValidationError("The installation date cannot be in the future.")

    def validate_permit_expiry_date(self, field):
        issue = self.permit_issue_date.data
        if field.data and issue and field.data < issue:
            raise ValidationError("The expiry date cannot be before the issue date.")

    def validate(self, extra_validators=None):
        valid = super().validate(extra_validators)
        lat, lng = self.latitude.data, self.longitude.data
        if (lat is None) != (lng is None):
            target = self.longitude if lng is None else self.latitude
            target.errors.append("Enter both latitude and longitude, or leave both empty.")
            valid = False
        elif lat is None and self.require_coordinates and not self.latitude.errors:
            self.latitude.errors.append(
                "Coordinates are required. Click the map or enter the latitude and longitude."
            )
            valid = False
        elif (lat is not None and not self.latitude.errors and not self.longitude.errors
              and not coordinates_in_nigeria(lat, lng)):
            self.latitude.errors.append(
                "These coordinates are outside Nigeria (latitude "
                f"{NIGERIA_LAT_RANGE[0]}–{NIGERIA_LAT_RANGE[1]}, longitude "
                f"{NIGERIA_LNG_RANGE[0]}–{NIGERIA_LNG_RANGE[1]}). "
                "Check that latitude and longitude are not swapped."
            )
            valid = False
        if self.require_photograph and not (self.photograph.data and self.photograph.data.filename):
            self.photograph.errors.append("A photograph of the actual billboard is required.")
            valid = False
        return valid


class ReviewForm(FlaskForm):
    decision = SelectField("Decision", validators=[DataRequired()])
    notes = TextAreaField("Review notes", validators=[Optional(), Length(max=2000)],
                          filters=[strip])
    submit = SubmitField("Record decision")

    def validate(self, extra_validators=None):
        # Checked here rather than in validate_notes(): Optional() stops the
        # validator chain for empty input, so an inline validator never runs.
        valid = super().validate(extra_validators)
        if self.decision.data in ("reject", "suspend") and not self.notes.data:
            self.notes.errors.append("Please explain the reason for this decision.")
            valid = False
        return valid


# --------------------------------------------------------------------------
# Administration
# --------------------------------------------------------------------------

class UserCreateForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(max=120)],
                            filters=[strip])
    email = EmailField("Email address", validators=[DataRequired(), Email(), Length(max=120)],
                       filters=[lower_strip])
    role = SelectField("Role", choices=list(ROLE_LABELS.items()), validators=[DataRequired()])
    organization = StringField("Organisation / company", validators=[Optional(), Length(max=150)],
                               filters=[strip])
    phone = StringField("Phone number", validators=[Optional(), Regexp(PHONE_PATTERN, message=PHONE_MESSAGE)],
                        filters=[strip])
    password = PasswordField("Initial password", validators=[DataRequired(), StrongPassword()])
    submit = SubmitField("Create user")


class UserEditForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(max=120)],
                            filters=[strip])
    email = EmailField("Email address", validators=[DataRequired(), Email(), Length(max=120)],
                       filters=[lower_strip])
    role = SelectField("Role", choices=list(ROLE_LABELS.items()), validators=[DataRequired()])
    organization = StringField("Organisation / company", validators=[Optional(), Length(max=150)],
                               filters=[strip])
    phone = StringField("Phone number", validators=[Optional(), Regexp(PHONE_PATTERN, message=PHONE_MESSAGE)],
                        filters=[strip])
    is_active = BooleanField("Account is active")
    can_view_all_inspections = BooleanField(
        "Inspector may view (read-only) inspections assigned to other inspectors"
    )
    new_password = PasswordField("Set a new password",
                                 validators=[Optional(), StrongPassword()])
    submit = SubmitField("Save changes")


class CategoryForm(FlaskForm):
    name = StringField("Category name", validators=[DataRequired(), Length(max=100)],
                       filters=[strip])
    description = StringField("Description", validators=[Optional(), Length(max=255)],
                              filters=[strip])
    is_active = BooleanField("Active", default=True)
    submit = SubmitField("Save category")


class AuthorityForm(FlaskForm):
    name = StringField("Authority name", validators=[DataRequired(), Length(max=150)],
                       filters=[strip])
    jurisdiction = StringField("Jurisdiction", validators=[Optional(), Length(max=150)],
                               filters=[strip])
    state_or_territory = SelectField("State / territory", validators=[Optional()])
    contact_email = EmailField("Contact email", validators=[Optional(), Email(), Length(max=120)],
                               filters=[lower_strip])
    contact_phone = StringField("Contact phone", validators=[Optional(), Regexp(PHONE_PATTERN, message=PHONE_MESSAGE)],
                                filters=[strip])
    website = URLField("Website", validators=[Optional(), URL(require_tld=True), Length(max=255)],
                       filters=[strip])
    is_active = BooleanField("Active", default=True)
    submit = SubmitField("Save authority")


class LocationOptionForm(FlaskForm):
    location_type = SelectField("Type", choices=list(LOCATION_TYPES.items()),
                                validators=[DataRequired()])
    name = StringField("Name", validators=[DataRequired(), Length(max=150)], filters=[strip])
    submit = SubmitField("Add")


# --------------------------------------------------------------------------
# Inspections
# --------------------------------------------------------------------------

class AssignmentForm(FlaskForm):
    advertisement_id = SelectField("Advertisement", coerce=int, validators=[InputRequired()])
    inspector_id = SelectField("Inspector", coerce=int, validators=[InputRequired()])
    due_date = DateField("Due date", validators=[Optional()])
    instructions = TextAreaField("Instructions / notes for the inspector",
                                 validators=[Optional(), Length(max=2000)], filters=[strip])
    submit = SubmitField("Assign inspection")

    def validate_due_date(self, field):
        if field.data and field.data < date.today():
            raise ValidationError("The due date cannot be in the past.")


class ReassignForm(FlaskForm):
    inspector_id = SelectField("New inspector", coerce=int, validators=[InputRequired()])
    reason = TextAreaField("Reason for reassignment", validators=[DataRequired(), Length(max=1000)],
                           filters=[strip])
    submit_reassign = SubmitField("Reassign")


class AssignmentUpdateForm(FlaskForm):
    due_date = DateField("Due date", validators=[Optional()])
    instructions = TextAreaField("Instructions / notes", validators=[Optional(), Length(max=2000)],
                                 filters=[strip])
    submit_update = SubmitField("Update assignment")


class InspectionReportForm(FlaskForm):
    """Used both to save a draft and to submit.

    Drafts accept incomplete data; submission requires every field marked
    required below (checked in validate()).
    """

    condition_found = SelectField("Actual site condition",
                                  choices=_blank() + list(SITE_CONDITIONS.items()))
    condition_other = StringField("Describe the condition", validators=[Optional(), Length(max=255)],
                                  filters=[strip])
    location_verification = SelectField("Physical location verification",
                                        choices=_blank() + list(LOCATION_VERIFICATIONS.items()))
    details_verification = SelectField("Advertisement details verification",
                                       choices=_blank() + list(DETAILS_VERIFICATIONS.items()))
    permit_observation = SelectField("Permit information observation",
                                     choices=_blank() + list(PERMIT_OBSERVATIONS.items()))
    inspected_at = DateTimeLocalField("Inspection date and time (WAT)", format="%Y-%m-%dT%H:%M",
                                      validators=[Optional()])
    findings = TextAreaField("Inspection findings and observations",
                             validators=[Optional(), Length(max=5000)], filters=[strip])
    recommended_action = TextAreaField("Recommended corrective action",
                                       validators=[Optional(), Length(max=3000)], filters=[strip])
    notes = TextAreaField("Additional notes", validators=[Optional(), Length(max=3000)],
                          filters=[strip])
    new_photos = MultipleFileField("Add site photographs")
    save_draft = SubmitField("Save draft")
    submit_report = SubmitField("Submit report")

    REQUIRED_ON_SUBMIT = (
        "condition_found", "location_verification", "details_verification",
        "permit_observation", "inspected_at", "findings", "recommended_action",
    )

    def validate_inspected_at(self, field):
        # Values are entered in WAT (UTC+1); allow small clock differences.
        if field.data and field.data > utcnow() + timedelta(hours=1, minutes=10):
            raise ValidationError("The inspection time cannot be in the future.")

    @property
    def is_submission(self):
        return bool(self.submit_report.data)

    def validate(self, extra_validators=None):
        valid = super().validate(extra_validators)
        if self.is_submission:
            for name in self.REQUIRED_ON_SUBMIT:
                field = getattr(self, name)
                if not field.data and not field.errors:
                    field.errors.append("This field is required to submit the report.")
                    valid = False
            if self.condition_found.data == "other" and not self.condition_other.data:
                self.condition_other.errors.append("Describe the condition when selecting Other.")
                valid = False
        return valid


class CorrectionRequestForm(FlaskForm):
    reason = TextAreaField("What needs to be corrected?",
                           validators=[DataRequired(), Length(max=2000)], filters=[strip])
    submit_correction = SubmitField("Request correction")


class FollowUpForm(FlaskForm):
    action = SelectField("Follow-up action", choices=list(FOLLOW_UP_ACTIONS.items()),
                         validators=[DataRequired()])
    notes = TextAreaField("Notes", validators=[Optional(), Length(max=2000)], filters=[strip])
    submit_follow_up = SubmitField("Record follow-up")

    def validate(self, extra_validators=None):
        valid = super().validate(extra_validators)
        if self.action.data == "other" and not self.notes.data:
            self.notes.errors.append("Add notes describing the follow-up.")
            valid = False
        return valid
