"""PDF report generation with ReportLab."""

import io
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas as pdf_canvas
from reportlab.platypus import (
    Image,
    KeepTogether,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from .utils import resolve_upload, thumbnail_path

NAVY = colors.HexColor("#0f1f3d")
BORDER = colors.HexColor("#d6dbe5")
STRIPE = colors.HexColor("#f4f6fa")


class NumberedCanvas(pdf_canvas.Canvas):
    """Adds 'Page X of Y' and a footer to every page."""

    def __init__(self, *args, footer_text="", **kwargs):
        super().__init__(*args, **kwargs)
        self.footer_text = footer_text
        self._saved_pages = []

    def showPage(self):
        self._saved_pages.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total = len(self._saved_pages)
        for state in self._saved_pages:
            self.__dict__.update(state)
            self._draw_footer(total)
            super().showPage()
        super().save()

    def _draw_footer(self, total):
        width, _ = self._pagesize
        self.setFont("Helvetica", 8)
        self.setFillColor(colors.HexColor("#6b7486"))
        self.drawString(15 * mm, 9 * mm, self.footer_text)
        self.drawRightString(width - 15 * mm, 9 * mm, f"Page {self._pageNumber} of {total}")


def _styles():
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("title", parent=base["Title"], fontSize=17, textColor=NAVY,
                                alignment=0, spaceAfter=2),
        "subtitle": ParagraphStyle("subtitle", parent=base["Normal"], fontSize=9,
                                   textColor=colors.HexColor("#4a5468")),
        "h2": ParagraphStyle("h2", parent=base["Heading2"], fontSize=11, textColor=NAVY,
                             spaceBefore=8, spaceAfter=4),
        "cell": ParagraphStyle("cell", parent=base["Normal"], fontSize=7.2, leading=9),
        "cell_head": ParagraphStyle("cell_head", parent=base["Normal"], fontSize=7.2, leading=9,
                                    textColor=colors.white, fontName="Helvetica-Bold"),
        "small": ParagraphStyle("small", parent=base["Normal"], fontSize=8, leading=10),
        "right": ParagraphStyle("right", parent=base["Normal"], fontSize=8, alignment=TA_RIGHT),
    }


def _p(text, style):
    return Paragraph(escape(str(text)) if text not in (None, "") else "—", style)


def _grid(data, col_widths, header_rows=1):
    table = Table(data, colWidths=col_widths, repeatRows=header_rows)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, header_rows - 1), NAVY),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
        ("ROWBACKGROUNDS", (0, header_rows), (-1, -1), [colors.white, STRIPE]),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return table


def _thumbnail(ad, size=16 * mm):
    if not ad.photograph_path:
        return None
    for candidate in (thumbnail_path(ad.photograph_path), ad.photograph_path):
        path = resolve_upload(candidate)
        if path and path.is_file():
            try:
                image = Image(str(path))
                ratio = min(size / image.imageWidth, size / image.imageHeight)
                image.drawWidth = image.imageWidth * ratio
                image.drawHeight = image.imageHeight * ratio
                return image
            except Exception:  # unreadable file: fall back to the text placeholder
                return None
    return None


def build_advertisement_report(*, app_name, title, generated_at, generated_by, filter_lines,
                               summary, groups, group_label, advertisements,
                               include_photos=False, truncated=False):
    buffer = io.BytesIO()
    page_size = landscape(A4)
    doc = SimpleDocTemplate(
        buffer, pagesize=page_size, leftMargin=15 * mm, rightMargin=15 * mm,
        topMargin=14 * mm, bottomMargin=16 * mm, title=title, author=app_name,
    )
    s = _styles()
    story = [
        Paragraph(escape(title), s["title"]),
        Paragraph(escape(app_name), s["subtitle"]),
        Paragraph(f"Generated {escape(generated_at)} by {escape(generated_by)}", s["subtitle"]),
        Spacer(1, 6),
    ]

    story.append(Paragraph("Selected filters", s["h2"]))
    story.append(Paragraph(
        "<br/>".join(escape(line) for line in filter_lines) if filter_lines else "None (all accessible records)",
        s["small"],
    ))

    story.append(Paragraph("Summary", s["h2"]))
    summary_rows = [[_p(label, s["cell"]), _p(value, s["cell"])] for label, value in summary]
    summary_table = _grid([[_p("Measure", s["cell_head"]), _p("Count", s["cell_head"])]] + summary_rows,
                          [70 * mm, 25 * mm])
    story.append(KeepTogether(summary_table))

    if groups:
        story.append(Paragraph(f"Advertisements by {escape(group_label)}", s["h2"]))
        group_rows = [[_p(name, s["cell"]), _p(count, s["cell"])] for name, count in groups]
        story.append(_grid([[_p(group_label.title(), s["cell_head"]), _p("Count", s["cell_head"])]]
                           + group_rows, [90 * mm, 25 * mm]))

    story.append(Paragraph("Advertisement records", s["h2"]))
    if truncated:
        story.append(Paragraph(
            f"Only the first {len(advertisements)} matching records are listed. "
            "Narrow the filters or use the CSV export for the full list.", s["small"]))
    headers = ["Code", "Title", "Category", "Advertiser", "Location", "Approval",
               "Permit no.", "Expiry", "Permit condition"]
    widths = [24 * mm, 38 * mm, 32 * mm, 32 * mm, 52 * mm, 19 * mm, 24 * mm, 19 * mm, 25 * mm]
    if include_photos:
        headers.insert(0, "Photo")
        widths = [19 * mm] + [w * 0.93 for w in widths]
    rows = [[_p(h, s["cell_head"]) for h in headers]]
    for ad in advertisements:
        location = ", ".join(p for p in (ad.display_address, ad.city, ad.state_or_territory) if p)
        row = [
            _p(ad.advertisement_code, s["cell"]),
            _p(ad.title, s["cell"]),
            _p(ad.category.name if ad.category else None, s["cell"]),
            _p(ad.advertiser_name, s["cell"]),
            _p(location, s["cell"]),
            _p(ad.approval_status_label, s["cell"]),
            _p(ad.permit_number, s["cell"]),
            _p(ad.permit_expiry_date.strftime("%d %b %Y") if ad.permit_expiry_date else None, s["cell"]),
            _p(ad.permit_condition_label, s["cell"]),
        ]
        if include_photos:
            row.insert(0, _thumbnail(ad) or _p("No photo", s["cell"]))
        rows.append(row)
    if len(rows) == 1:
        story.append(Paragraph("No advertisements match the selected filters.", s["small"]))
    else:
        story.append(_grid(rows, widths))

    footer = f"{app_name} — {title}"
    doc.build(story, canvasmaker=lambda *a, **k: NumberedCanvas(*a, footer_text=footer, **k))
    return buffer.getvalue()
