from functools import wraps

from flask import abort
from flask_login import current_user, login_required


def role_required(*roles):
    """Require login and one of ``roles``; otherwise respond 403.

    Checked on the server for every request, so hiding a button in the UI is
    never the only protection.
    """

    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            if current_user.role not in roles:
                abort(403)
            return view(*args, **kwargs)

        return wrapped

    return decorator


def admin_required(view):
    from .models import ROLE_ADMIN

    return role_required(ROLE_ADMIN)(view)
