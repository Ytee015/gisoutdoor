"""Domain operations shared by several blueprints."""

from datetime import date, datetime

from sqlalchemy import update
from sqlalchemy.exc import IntegrityError

from .extensions import db
from .models import AdvertisementCodeSequence, AdvertisementHistory

# Fields compared when recording an edit in the audit history.
TRACKED_FIELDS = (
    "title", "description", "category_id", "advertiser_name", "contact_person",
    "contact_phone", "country", "state_or_territory", "city", "lga",
    "street_or_road", "full_address", "landmark", "latitude", "longitude",
    "advertisement_type", "width", "height", "installation_date", "condition",
    "photograph_path", "permit_number", "regulatory_authority_id",
    "permit_issue_date", "permit_expiry_date", "permit_verification_status",
    "approval_status", "review_notes", "is_archived",
)


def generate_advertisement_code(year=None):
    """Reserve the next ADV-YYYY-NNNN code inside the current transaction.

    The per-year counter is incremented with a single UPDATE, so two
    concurrent requests cannot receive the same number, and deleting records
    never causes a code to be reissued. The unique constraint on
    advertisement_code remains the final safeguard.
    """
    year = year or date.today().year
    stmt = (
        update(AdvertisementCodeSequence)
        .where(AdvertisementCodeSequence.year == year)
        .values(last_value=AdvertisementCodeSequence.last_value + 1)
        .returning(AdvertisementCodeSequence.last_value)
        .execution_options(synchronize_session=False)
    )
    value = db.session.execute(stmt).scalar()
    if value is None:
        try:
            with db.session.begin_nested():
                db.session.add(AdvertisementCodeSequence(year=year, last_value=1))
            value = 1
        except IntegrityError:
            # Another request created this year's counter first.
            value = db.session.execute(stmt).scalar()
    return f"ADV-{year}-{value:04d}"


def _serialise(value):
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return value


def snapshot_advertisement(advertisement, fields=TRACKED_FIELDS):
    return {field: _serialise(getattr(advertisement, field)) for field in fields}


def diff_snapshots(before, after):
    """Return (previous, new) dicts containing only the changed fields."""
    changed = [key for key in after if before.get(key) != after.get(key)]
    return ({k: before.get(k) for k in changed}, {k: after.get(k) for k in changed})


def record_history(advertisement, actor, action, previous=None, new=None, notes=None):
    entry = AdvertisementHistory(
        advertisement=advertisement,
        advertisement_code=advertisement.advertisement_code,
        actor=actor,
        action=action,
        previous_values=previous or None,
        new_values=new or None,
        notes=notes,
    )
    db.session.add(entry)
    return entry
