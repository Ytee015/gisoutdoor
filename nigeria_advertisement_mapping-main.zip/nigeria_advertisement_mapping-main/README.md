# Nigeria Outdoor Advertisement Mapping System (NOAMS)

A GIS-based web application for registering, photographing, locating, visualising and
monitoring outdoor advertisements — billboards, digital LED displays, signboards and
banners — across Nigeria's 36 states and the Federal Capital Territory (FCT), Abuja.

> **Status:** under phased development. Phase 1 (foundation) is complete. This README
> will be completed in Phase 10.

## Overview

Outdoor-advertising companies and regulators often track billboard locations, photos
and permits in spreadsheets, which makes it hard to see where structures are, which
permits are about to expire, and which submissions still need review. NOAMS keeps
these records in one database and shows each registered advertisement at its recorded
coordinates on an interactive OpenStreetMap-based map.

**What the system does not do**

- It maps advertisements that users have **registered**. It does not automatically
  detect billboards, and it never downloads photographs of billboards.
- Map positions are only as accurate as the coordinates that users supply.
- It **records** permit information. It does not issue government permits and cannot
  prove that a permit is authentic.

## User roles

| Role | Summary |
|------|---------|
| Administrator | Reviews, approves, rejects and suspends submissions; manages users, categories, locations and regulatory authorities; monitors permits; generates reports. |
| Staff | Registers advertisements with photographs and coordinates; tracks the status of their own submissions. |

Public registration creates **Staff** accounts only. The first administrator is
created with a CLI command (added in Phase 2).

## Technology stack

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.12, Flask, Flask-SQLAlchemy, Flask-Login, Flask-Migrate, Flask-WTF/WTForms, Werkzeug security |
| Database | SQLite (`instance/advertisement_mapping.db`) through the SQLAlchemy ORM |
| Frontend | Jinja2, HTML5, CSS3, Bootstrap 5 (CDN), Bootstrap Icons, vanilla JavaScript |
| GIS | Leaflet.js with OpenStreetMap tiles |
| Reports | Chart.js (dashboards), ReportLab (PDF), Python `csv` (CSV) |

## Project structure

```
nigeria_advertisement_mapping/
├── run.py                 # entry point (python run.py / flask --app run ...)
├── config.py              # Development / Production / Testing configuration
├── requirements.txt       # pinned dependency versions
├── .env.example           # template for environment variables
├── app/
│   ├── __init__.py        # create_app() application factory
│   ├── extensions.py      # db, migrate, login_manager, csrf
│   ├── models.py          # SQLAlchemy models
│   ├── nigeria.py         # states/FCT list and coordinate helpers
│   ├── forms.py, decorators.py, utils.py
│   ├── blueprints/        # auth, dashboard, advertisements, map, reports, administration
│   ├── templates/         # base.html, partials, per-blueprint folders, errors/
│   └── static/            # css/style.css, js/main.js
├── instance/              # SQLite database (not committed)
├── uploads/advertisements/# uploaded billboard photographs (not committed)
├── migrations/            # Flask-Migrate / Alembic migration scripts
└── tests/                 # pytest suite
```

## Local setup

Requires Python 3.12.

```bash
# 1. Create and activate a virtual environment
python -m venv .venv
.venv\Scripts\activate          # Windows
source .venv/bin/activate       # macOS / Linux

# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure the environment
copy .env.example .env          # Windows  (cp .env.example .env on macOS / Linux)
#    then edit .env — SECRET_KEY is required when APP_CONFIG=production

# 4. Create or update the database schema
flask --app run db upgrade

# 5. Run the development server
python run.py
```

Then open <http://127.0.0.1:8000>.

### About migrations

This project **already includes** a `migrations/` folder, so **do not run
`flask --app run db init`** — that command is only for a project that has no migration
repository yet, and running it again will fail.

- `flask --app run db upgrade` creates the database on first run and applies any new
  migrations later. It never deletes existing data.
- After changing `app/models.py`, generate a migration with
  `flask --app run db migrate -m "describe the change"`, review the generated file in
  `migrations/versions/`, then run `flask --app run db upgrade`.
- The application never creates or drops tables on start-up.

In development, if `SECRET_KEY` is not set, a random key is generated once and stored
in `instance/.dev_secret_key`. Production mode refuses to start without `SECRET_KEY`.

## Running the tests

```bash
python -m pytest
```

Tests use a separate in-memory SQLite database and a temporary upload folder, and they
do not need internet access.

## OpenStreetMap attribution

Map data © [OpenStreetMap](https://www.openstreetmap.org/copyright) contributors.
