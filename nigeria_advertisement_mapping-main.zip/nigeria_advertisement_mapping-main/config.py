"""Centralised configuration.

All persistent paths are absolute and derived from this file's location, so
the application never depends on the current working directory (important
on PythonAnywhere, where the WSGI process starts elsewhere).
"""

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"

load_dotenv(BASE_DIR / ".env")


def _env_bool(name, default=False):
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name, default):
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


class Config:
    APP_NAME = "Nigeria Outdoor Advertisement Mapping System"
    SECRET_KEY = os.environ.get("SECRET_KEY")

    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{INSTANCE_DIR / 'advertisement_mapping.db'}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Uploads are kept outside /static and served only through a route that
    # checks the viewer's permission to see the advertisement.
    UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER", str(BASE_DIR / "uploads"))
    ADVERTISEMENT_UPLOAD_SUBDIR = "advertisements"
    ALLOWED_IMAGE_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}
    MAX_IMAGE_BYTES = 5 * 1024 * 1024  # per photograph
    MAX_INSPECTION_PHOTOS_PER_UPLOAD = 5
    MAX_CONTENT_LENGTH = 30 * 1024 * 1024  # whole request, incl. form fields

    PERMIT_EXPIRY_WARNING_DAYS = _env_int("PERMIT_EXPIRY_WARNING_DAYS", 30)
    ITEMS_PER_PAGE = 20

    # Default map view (Lagos). Only positions the map — never assigned to
    # an advertisement.
    MAP_DEFAULT_CENTER = (6.5244, 3.3792)
    MAP_DEFAULT_ZOOM = 11

    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _env_bool("SESSION_COOKIE_SECURE")
    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SAMESITE = "Lax"
    REMEMBER_COOKIE_SECURE = _env_bool("SESSION_COOKIE_SECURE")

    DEBUG = False
    TESTING = False


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False
    SESSION_COOKIE_SECURE = _env_bool("SESSION_COOKIE_SECURE", default=True)
    REMEMBER_COOKIE_SECURE = SESSION_COOKIE_SECURE


class TestingConfig(Config):
    TESTING = True
    SECRET_KEY = "testing-only-secret-key"
    SQLALCHEMY_DATABASE_URI = "sqlite://"  # separate, in-memory test database
    WTF_CSRF_ENABLED = False


CONFIGS = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
}


def get_config(name=None):
    name = (name or os.environ.get("APP_CONFIG") or "development").lower()
    if name not in CONFIGS:
        raise RuntimeError(f"Unknown APP_CONFIG '{name}'. Use one of: {', '.join(CONFIGS)}")
    return CONFIGS[name]
