from app import create_app

app = create_app()

if __name__ == "__main__":
    # Debug mode comes from the active configuration and is off in production.
    # Chrome blocks port 6000 as an unsafe port, so use a common local dev port.
    app.run(debug=app.config["DEBUG"], port=8000)
