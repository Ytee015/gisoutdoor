"""Phase 1 — application foundation."""

from pathlib import Path

import pytest
from alembic.autogenerate import compare_metadata
from alembic.migration import MigrationContext
from flask import render_template
from flask_migrate import upgrade
from sqlalchemy import inspect, text

from app import create_app
from app.extensions import db

EXPECTED_TABLES = {
    "users",
    "states_and_territories",
    "location_options",
    "advertisement_categories",
    "regulatory_authorities",
    "advertisement_code_sequences",
    "advertisements",
    "advertisement_history",
    "inspection_records",
}
MIGRATIONS_DIR = Path(__file__).resolve().parent.parent / "migrations"


def test_application_starts_in_testing_mode(app):
    assert app.testing
    assert app.config["SQLALCHEMY_DATABASE_URI"] == "sqlite://"
    assert not app.config["WTF_CSRF_ENABLED"]


def test_all_blueprints_registered(app):
    assert {"auth", "dashboard", "advertisements", "map", "reports", "administration"} <= set(
        app.blueprints
    )


def test_home_page_renders(client):
    response = client.get("/")
    assert response.status_code == 200
    body = response.get_data(as_text=True)
    assert "Nigeria Outdoor Advertisement Mapping System" in body
    assert "does not automatically detect" in body


def test_unknown_url_uses_custom_404_page(client):
    response = client.get("/no-such-page")
    assert response.status_code == 404
    assert "Page not found" in response.get_data(as_text=True)


@pytest.mark.parametrize(
    "template, text_expected",
    [("errors/403.html", "Access denied"), ("errors/500.html", "Something went wrong")],
)
def test_error_templates_render(app, template, text_expected):
    with app.test_request_context("/"):
        assert text_expected in render_template(template)


def test_security_headers_present(client):
    response = client.get("/")
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Frame-Options"] == "SAMEORIGIN"


def test_models_create_expected_tables(app):
    assert EXPECTED_TABLES <= set(inspect(db.engine).get_table_names())


def test_sqlite_foreign_keys_are_enforced(app):
    assert db.session.execute(text("PRAGMA foreign_keys")).scalar() == 1


def test_production_refuses_to_start_without_secret_key(tmp_path):
    with pytest.raises(RuntimeError, match="SECRET_KEY"):
        create_app(
            "production",
            config_overrides={"SECRET_KEY": None, "UPLOAD_FOLDER": str(tmp_path)},
        )


def test_upload_directory_is_created(app):
    upload_dir = Path(app.config["UPLOAD_FOLDER"]) / "advertisements"
    assert upload_dir.is_dir()


def test_migrations_build_the_same_schema_as_the_models(tmp_path):
    """Running every migration on a fresh file database matches models.py."""
    app = create_app(
        "testing",
        config_overrides={
            "SQLALCHEMY_DATABASE_URI": f"sqlite:///{tmp_path / 'migrated.db'}",
            "UPLOAD_FOLDER": str(tmp_path / "uploads"),
        },
    )
    with app.app_context():
        upgrade(directory=str(MIGRATIONS_DIR))
        with db.engine.connect() as connection:
            context = MigrationContext.configure(
                connection, opts={"render_as_batch": True}
            )
            diff = compare_metadata(context, db.metadata)
        assert diff == []
        assert EXPECTED_TABLES <= set(inspect(db.engine).get_table_names())
        db.engine.dispose()
