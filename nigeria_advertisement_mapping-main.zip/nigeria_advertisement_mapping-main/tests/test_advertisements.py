"""Advertisement registration, photographs, editing, approval workflow and permits."""

import io
import os
from datetime import date, timedelta
from pathlib import Path

import pytest
from PIL import Image
from sqlalchemy import func, select

from app.extensions import db
from app.models import (
    PERMIT_CHECKED,
    Advertisement,
    AdvertisementHistory,
    compute_permit_condition,
)
from app.services import generate_advertisement_code

from .conftest import ad_form_data, image_file, login, logout, make_ad


def _post_new(client, photo=True, **overrides):
    data = ad_form_data(**overrides)
    if photo:
        data["photograph"] = image_file() if photo is True else photo
    return client.post("/advertisements/new", data=data, content_type="multipart/form-data")


def _only_ad():
    return db.session.scalar(select(Advertisement))


# --------------------------------------------------------------------------
# Registration and validation
# --------------------------------------------------------------------------

def test_staff_can_register_advertisement_with_photo(client, app, staff):
    login(client, staff)
    response = _post_new(client)
    assert response.status_code == 302
    ad = _only_ad()
    assert ad.advertisement_code == f"ADV-{date.today().year}-0001"
    assert ad.approval_status == "pending"
    assert ad.submitted_by_id == staff.id
    assert ad.country == "Nigeria"
    assert ad.latitude == pytest.approx(6.5966) and ad.longitude == pytest.approx(3.3421)
    assert ad.photograph_path.startswith("advertisements/")
    stored = Path(app.config["UPLOAD_FOLDER"]) / ad.photograph_path
    assert stored.is_file()
    assert ad.photograph_path.endswith(".jpg") and "billboard" not in ad.photograph_path
    history = ad.history
    assert [h.action for h in history] == ["created"]


@pytest.mark.parametrize("missing", ["title", "advertiser_name", "state_or_territory", "city",
                                     "full_address", "advertisement_type", "condition"])
def test_required_fields_are_validated(client, staff, missing):
    login(client, staff)
    response = _post_new(client, **{missing: ""})
    assert response.status_code == 200
    assert "This field is required" in response.get_data(as_text=True)
    assert db.session.scalar(select(func.count(Advertisement.id))) == 0


def test_category_is_required(client, staff):
    login(client, staff)
    response = _post_new(client, category_id="0")
    assert "Select a category" in response.get_data(as_text=True)
    assert _only_ad() is None


@pytest.mark.parametrize("lat, lng, message", [
    ("95", "3.3", "Latitude must be between -90 and 90"),
    ("6.5", "-190", "Longitude must be between -180 and 180"),
    ("3.3792", "6.5244", "outside Nigeria"),          # swapped values
    ("51.5", "-0.12", "outside Nigeria"),             # London
    ("6.5", "", "Enter both latitude and longitude"),
    ("abc", "3.3", "Not a valid float value"),
])
def test_invalid_coordinates_are_rejected(client, staff, lat, lng, message):
    login(client, staff)
    response = _post_new(client, latitude=lat, longitude=lng)
    assert response.status_code == 200
    assert message in response.get_data(as_text=True)
    assert _only_ad() is None


def test_staff_must_supply_coordinates_and_photo(client, staff):
    login(client, staff)
    response = _post_new(client, photo=False, latitude="", longitude="")
    body = response.get_data(as_text=True)
    assert "Coordinates are required" in body
    assert "photograph of the actual billboard is required" in body
    assert _only_ad() is None


def test_admin_may_register_without_coordinates_and_photo(client, admin):
    login(client, admin)
    response = _post_new(client, photo=False, latitude="", longitude="")
    assert response.status_code == 302
    ad = _only_ad()
    assert ad.latitude is None and ad.photograph_path is None
    assert ad.approval_status == "pending"


def test_future_installation_date_and_inverted_permit_dates_rejected(client, staff):
    login(client, staff)
    body = _post_new(client, installation_date=(date.today() + timedelta(days=5)).isoformat(),
                     permit_issue_date="2026-05-01", permit_expiry_date="2026-01-01").get_data(as_text=True)
    assert "cannot be in the future" in body
    assert "cannot be before the issue date" in body


def test_staff_cannot_mark_permit_as_checked(client, staff):
    login(client, staff)
    response = _post_new(client, permit_verification_status=PERMIT_CHECKED)
    assert response.status_code == 200
    assert "Not a valid choice" in response.get_data(as_text=True)
    assert _only_ad() is None


def test_admin_can_mark_permit_as_checked(client, admin):
    login(client, admin)
    _post_new(client, permit_verification_status=PERMIT_CHECKED)
    assert _only_ad().permit_verification_status == PERMIT_CHECKED


# --------------------------------------------------------------------------
# Advertisement codes
# --------------------------------------------------------------------------

def test_codes_are_unique_sequential_and_never_reused(app, staff):
    first = make_ad(staff)
    second = make_ad(staff)
    year = date.today().year
    assert (first.advertisement_code, second.advertisement_code) == (f"ADV-{year}-0001", f"ADV-{year}-0002")
    db.session.delete(second)
    db.session.commit()
    third = make_ad(staff)
    assert third.advertisement_code == f"ADV-{year}-0003"  # not a recount of rows


def test_code_sequence_restarts_each_year(app):
    assert generate_advertisement_code(2030) == "ADV-2030-0001"
    assert generate_advertisement_code(2030) == "ADV-2030-0002"
    assert generate_advertisement_code(2031) == "ADV-2031-0001"


# --------------------------------------------------------------------------
# Photographs
# --------------------------------------------------------------------------

def test_non_image_file_with_image_extension_is_rejected(client, staff):
    login(client, staff)
    fake = (io.BytesIO(b"#!/bin/sh\necho not an image\n"), "billboard.jpg")
    body = _post_new(client, photo=fake).get_data(as_text=True)
    assert "not a valid image" in body
    assert _only_ad() is None


@pytest.mark.parametrize("name", ["billboard.exe", "billboard.php", "billboard.gif", "billboard"])
def test_disallowed_extensions_are_rejected(client, staff, name):
    login(client, staff)
    buffer, _ = image_file()
    body = _post_new(client, photo=(buffer, name)).get_data(as_text=True)
    assert "JPEG, PNG or WebP" in body
    assert _only_ad() is None


def test_oversized_photo_is_rejected(client, app, staff):
    app.config["MAX_IMAGE_BYTES"] = 1024
    login(client, staff)
    # Random pixels do not compress, so this PNG is far larger than 1 KB.
    img = Image.frombytes("RGB", (200, 200), os.urandom(200 * 200 * 3))
    big = io.BytesIO()
    img.save(big, format="PNG")
    big.seek(0)
    body = _post_new(client, photo=(big, "big.png")).get_data(as_text=True)
    assert "larger than" in body
    assert _only_ad() is None


@pytest.mark.parametrize("fmt, extension", [("PNG", ".png"), ("WEBP", ".webp")])
def test_png_and_webp_photos_are_accepted(client, staff, fmt, extension):
    login(client, staff)
    response = _post_new(client, photo=image_file(fmt=fmt))
    assert response.status_code == 302
    assert _only_ad().photograph_path.endswith(extension)


def test_photo_is_served_to_owner_and_admin_only(client, staff, staff2, admin):
    login(client, staff)
    _post_new(client)
    ad = _only_ad()
    url = f"/advertisements/{ad.id}/photo"
    response = client.get(url)
    assert response.status_code == 200 and response.mimetype == "image/jpeg"
    assert client.get(url + "?size=thumb").status_code == 200
    logout(client)
    login(client, staff2)
    assert client.get(url).status_code == 404
    logout(client)
    login(client, admin)
    assert client.get(url).status_code == 200
    logout(client)
    assert client.get(url).status_code == 302  # anonymous -> login


def test_photo_shows_on_detail_and_placeholder_when_missing(client, admin, staff):
    login(client, staff)
    _post_new(client)
    ad = _only_ad()
    body = client.get(f"/advertisements/{ad.id}").get_data(as_text=True)
    assert f"/advertisements/{ad.id}/photo" in body
    logout(client)
    login(client, admin)
    no_photo = make_ad(admin)
    body = client.get(f"/advertisements/{no_photo.id}").get_data(as_text=True)
    assert "No photograph" in body


# --------------------------------------------------------------------------
# Viewing and editing
# --------------------------------------------------------------------------

def test_staff_list_shows_only_their_advertisements(client, staff, staff2):
    mine = make_ad(staff, title="Mine Billboard")
    theirs = make_ad(staff2, title="Their Billboard")
    login(client, staff)
    body = client.get("/advertisements/").get_data(as_text=True)
    assert "Mine Billboard" in body and "Their Billboard" not in body
    assert client.get(f"/advertisements/{theirs.id}").status_code == 404
    assert client.get(f"/advertisements/{mine.id}").status_code == 200


def test_list_search_filter_sort_and_pagination(client, admin, staff):
    make_ad(staff, title="Lekki Toll Gate LED", state_or_territory="Lagos", city="Lekki")
    make_ad(staff, title="Wuse Market Banner", state_or_territory="Federal Capital Territory (FCT), Abuja",
            city="Wuse", latitude=9.07, longitude=7.47)
    login(client, admin)
    assert "Wuse" not in client.get("/advertisements/?q=lekki").get_data(as_text=True)
    body = client.get("/advertisements/?state=Federal+Capital+Territory+(FCT),+Abuja").get_data(as_text=True)
    assert "Wuse Market Banner" in body and "Lekki Toll" not in body
    assert client.get("/advertisements/?sort=title&page=99").status_code == 200


def test_owner_can_edit_pending_and_history_records_changes(client, staff):
    ad = make_ad(staff)
    login(client, staff)
    data = ad_form_data(title="Renamed Billboard", latitude="6.61", longitude="3.36")
    response = client.post(f"/advertisements/{ad.id}/edit", data=data, content_type="multipart/form-data")
    assert response.status_code == 302
    db.session.refresh(ad)
    assert ad.title == "Renamed Billboard"
    entry = db.session.scalar(select(AdvertisementHistory).where(AdvertisementHistory.action == "updated"))
    assert entry.previous_values["title"] == "Test Billboard"
    assert entry.new_values["title"] == "Renamed Billboard"
    assert entry.new_values["latitude"] == pytest.approx(6.61)


def test_editing_replaces_photo_and_removes_old_file(client, app, staff):
    login(client, staff)
    _post_new(client)
    ad = _only_ad()
    old_file = Path(app.config["UPLOAD_FOLDER"]) / ad.photograph_path
    data = ad_form_data(photograph=image_file(fmt="PNG"))
    client.post(f"/advertisements/{ad.id}/edit", data=data, content_type="multipart/form-data")
    db.session.refresh(ad)
    assert ad.photograph_path.endswith(".png")
    assert (Path(app.config["UPLOAD_FOLDER"]) / ad.photograph_path).is_file()
    assert not old_file.exists()
    assert "photo_replaced" in [h.action for h in ad.history]


def test_staff_cannot_edit_approved_or_others_advertisements(client, staff, staff2):
    approved = make_ad(staff, approval_status="approved")
    other = make_ad(staff2)
    login(client, staff)
    assert client.get(f"/advertisements/{approved.id}/edit").status_code == 403
    assert client.post(f"/advertisements/{approved.id}/edit", data=ad_form_data()).status_code == 403
    assert client.get(f"/advertisements/{other.id}/edit").status_code == 404


def test_editing_rejected_submission_resubmits_it(client, staff):
    ad = make_ad(staff, approval_status="rejected", review_notes="Photo unclear")
    login(client, staff)
    client.post(f"/advertisements/{ad.id}/edit", data=ad_form_data(), content_type="multipart/form-data")
    db.session.refresh(ad)
    assert ad.approval_status == "pending"
    assert "resubmitted" in [h.action for h in ad.history]


def test_staff_editing_checked_permit_details_resets_verification(client, staff):
    ad = make_ad(staff, permit_number="P-1", permit_expiry_date=date.today() + timedelta(days=300),
                 permit_verification_status=PERMIT_CHECKED)
    login(client, staff)
    client.post(f"/advertisements/{ad.id}/edit",
                data=ad_form_data(permit_number="P-2", permit_verification_status=PERMIT_CHECKED),
                content_type="multipart/form-data")
    db.session.refresh(ad)
    assert ad.permit_number == "P-2"
    assert ad.permit_verification_status == "unverified"


# --------------------------------------------------------------------------
# Approval workflow
# --------------------------------------------------------------------------

def test_admin_approves_and_rejects(client, admin, staff):
    first, second = make_ad(staff), make_ad(staff)
    login(client, admin)
    client.post(f"/advertisements/{first.id}/review", data={"decision": "approve", "notes": "Looks good"})
    client.post(f"/advertisements/{second.id}/review", data={"decision": "reject", "notes": "Wrong location"})
    db.session.refresh(first)
    db.session.refresh(second)
    assert first.approval_status == "approved" and first.reviewed_by_id == admin.id and first.reviewed_at
    assert second.approval_status == "rejected" and second.review_notes == "Wrong location"
    assert [h.action for h in first.history][0] == "approved"


def test_rejection_requires_notes(client, admin, staff):
    ad = make_ad(staff)
    login(client, admin)
    client.post(f"/advertisements/{ad.id}/review", data={"decision": "reject", "notes": ""})
    db.session.refresh(ad)
    assert ad.approval_status == "pending"


def test_staff_cannot_approve_even_their_own_submission(client, staff):
    ad = make_ad(staff)
    login(client, staff)
    assert client.post(f"/advertisements/{ad.id}/review", data={"decision": "approve"}).status_code == 403
    db.session.refresh(ad)
    assert ad.approval_status == "pending"


def test_suspension_and_reinstatement(client, admin, staff):
    ad = make_ad(staff)
    login(client, admin)
    # Cannot suspend something that is not approved.
    client.post(f"/advertisements/{ad.id}/review", data={"decision": "suspend", "notes": "x"})
    db.session.refresh(ad)
    assert ad.approval_status == "pending"

    client.post(f"/advertisements/{ad.id}/review", data={"decision": "approve"})
    client.post(f"/advertisements/{ad.id}/review", data={"decision": "suspend", "notes": "Structure unsafe"})
    db.session.refresh(ad)
    assert ad.approval_status == "suspended"
    assert ad.approval_status_label == "Suspended"

    client.post(f"/advertisements/{ad.id}/review", data={"decision": "reinstate"})
    db.session.refresh(ad)
    assert ad.approval_status == "approved"
    assert [h.action for h in ad.history][:3] == ["reinstated", "suspended", "approved"]


def test_suspended_advertisement_is_not_shown_as_approved(client, admin, staff):
    ad = make_ad(staff, approval_status="suspended")
    login(client, admin)
    body = client.get("/advertisements/?approval_status=approved").get_data(as_text=True)
    assert ad.advertisement_code not in body
    body = client.get("/advertisements/?approval_status=suspended").get_data(as_text=True)
    assert ad.advertisement_code in body


def test_review_queue_lists_pending_only(client, admin, staff):
    pending = make_ad(staff, title="Pending One")
    make_ad(staff, title="Approved One", approval_status="approved")
    login(client, admin)
    body = client.get("/advertisements/review-queue").get_data(as_text=True)
    assert "Pending One" in body and "Approved One" not in body
    response = client.post(f"/advertisements/{pending.id}/review", data={"decision": "approve", "next": "queue"})
    assert response.headers["Location"].endswith("/advertisements/review-queue")


# --------------------------------------------------------------------------
# Archive and delete
# --------------------------------------------------------------------------

def test_archive_restore_and_delete_preserve_history(client, app, admin, staff):
    login(client, staff)
    _post_new(client)
    logout(client)
    ad = _only_ad()
    photo = Path(app.config["UPLOAD_FOLDER"]) / ad.photograph_path
    ad_id, code = ad.id, ad.advertisement_code

    login(client, admin)
    assert client.post(f"/advertisements/{ad_id}/delete").status_code == 409  # must archive first
    client.post(f"/advertisements/{ad_id}/archive")
    db.session.refresh(ad)
    assert ad.is_archived
    link = f">{code}</a>"
    assert link not in client.get("/advertisements/").get_data(as_text=True)
    assert link in client.get("/advertisements/?archived=only").get_data(as_text=True)

    client.post(f"/advertisements/{ad_id}/restore")
    db.session.refresh(ad)
    assert not ad.is_archived

    client.post(f"/advertisements/{ad_id}/archive")
    assert client.get(f"/advertisements/{ad_id}/delete").status_code == 200
    client.post(f"/advertisements/{ad_id}/delete")
    db.session.expire_all()
    assert db.session.get(Advertisement, ad_id) is None
    assert not photo.exists()
    actions = [h.action for h in db.session.scalars(
        select(AdvertisementHistory).where(AdvertisementHistory.advertisement_code == code)
        .order_by(AdvertisementHistory.id))]
    assert actions == ["created", "archived", "restored", "archived", "deleted"]


def test_staff_cannot_archive_or_delete(client, staff):
    ad = make_ad(staff)
    login(client, staff)
    assert client.post(f"/advertisements/{ad.id}/archive").status_code == 403
    assert client.get(f"/advertisements/{ad.id}/delete").status_code == 403


# --------------------------------------------------------------------------
# Permit monitoring
# --------------------------------------------------------------------------

@pytest.mark.parametrize("number, expiry_offset, verification, expected", [
    (None, 100, "checked", "missing"),
    ("P1", None, "checked", "missing"),
    ("  ", 100, "checked", "missing"),
    ("P1", -1, "checked", "expired"),
    ("P1", 0, "checked", "expiring_soon"),
    ("P1", 20, "checked", "expiring_soon"),
    ("P1", 30, "unverified", "expiring_soon"),
    ("P1", 31, "checked", "valid"),
    ("P1", 31, "pending_verification", "pending_verification"),
    ("P1", 31, "unverified", "unverified"),
])
def test_permit_condition_calculation(number, expiry_offset, verification, expected):
    today = date(2026, 6, 1)
    expiry = None if expiry_offset is None else today + timedelta(days=expiry_offset)
    assert compute_permit_condition(number, expiry, verification, today=today, warning_days=30) == expected


def test_permit_condition_uses_current_date_not_stored_value(app, staff):
    ad = make_ad(staff, permit_number="P1", permit_verification_status="checked",
                 permit_expiry_date=date.today() + timedelta(days=60))
    assert ad.permit_condition == "valid"
    ad.permit_expiry_date = date.today() - timedelta(days=1)
    assert ad.permit_condition == "expired"


def test_permit_filter_matches_python_calculation(client, admin, staff):
    today = date.today()
    cases = {
        "expired": dict(permit_number="E", permit_expiry_date=today - timedelta(days=3)),
        "expiring_soon": dict(permit_number="S", permit_expiry_date=today + timedelta(days=10)),
        "missing": dict(permit_number=None, permit_expiry_date=None),
        "valid": dict(permit_number="V", permit_expiry_date=today + timedelta(days=90),
                      permit_verification_status="checked"),
        "unverified": dict(permit_number="U", permit_expiry_date=today + timedelta(days=90)),
    }
    ads = {key: make_ad(staff, title=f"Permit {key}", **values) for key, values in cases.items()}
    login(client, admin)
    for key, ad in ads.items():
        assert ad.permit_condition == key
        body = client.get(f"/advertisements/?permit_condition={key}").get_data(as_text=True)
        assert f"Permit {key}" in body
        others = [k for k in ads if k != key]
        assert not any(f"Permit {k}<" in body for k in others)
    body = client.get("/advertisements/permits").get_data(as_text=True)
    assert "Permit expired" in body and "Permit expiring_soon" in body and "Permit valid" not in body


def test_audit_history_records_actor_and_values(client, admin, staff):
    ad = make_ad(staff)
    login(client, admin)
    client.post(f"/advertisements/{ad.id}/review", data={"decision": "approve", "notes": "OK"})
    entry = db.session.scalar(select(AdvertisementHistory).where(AdvertisementHistory.action == "approved"))
    assert entry.actor_id == admin.id
    assert entry.previous_values["approval_status"] == "pending"
    assert entry.new_values["approval_status"] == "approved"
    assert entry.advertisement_code == ad.advertisement_code
    assert "approved" in client.get("/admin/activity").get_data(as_text=True).lower()
