"""GIS map page and the /map/api/advertisements endpoint."""

from datetime import date, timedelta

from app.extensions import db
from app.models import InspectionAssignment

from .conftest import category_id, login, make_ad

API = "/map/api/advertisements"


def _codes(response):
    assert response.status_code == 200
    return {ad["code"] for ad in response.get_json()["advertisements"]}


def test_map_page_renders_with_attribution_hooks(client, staff):
    login(client, staff)
    body = client.get("/map/").get_data(as_text=True)
    assert 'id="ad-map"' in body
    assert "leaflet@1.9.4" in body
    assert "Approval and permit status are separate" in body


def test_api_requires_login(client, app):
    assert client.get(API).status_code == 302


def test_admin_sees_all_staff_sees_only_own(client, admin, staff, staff2):
    mine = make_ad(staff)
    theirs = make_ad(staff2)
    login(client, staff)
    assert _codes(client.get(API)) == {mine.advertisement_code}
    client.post("/auth/logout")
    login(client, admin)
    assert _codes(client.get(API)) == {mine.advertisement_code, theirs.advertisement_code}


def test_records_without_coordinates_are_not_markers(client, admin):
    with_coords = make_ad(admin)
    without = make_ad(admin, latitude=None, longitude=None)
    login(client, admin)
    codes = _codes(client.get(API))
    assert with_coords.advertisement_code in codes
    assert without.advertisement_code not in codes


def test_markers_use_stored_coordinates(client, admin):
    ad = make_ad(admin, latitude=9.0765, longitude=7.3986)
    login(client, admin)
    feature = client.get(API).get_json()["advertisements"][0]
    assert (feature["lat"], feature["lng"]) == (9.0765, 7.3986)
    # Never the Lagos default centre unless that is the real location.
    assert (feature["lat"], feature["lng"]) != (6.5244, 3.3792)
    assert feature["detail_url"] == f"/advertisements/{ad.id}"


def test_api_exposes_only_map_fields(client, admin, staff):
    make_ad(staff, contact_person="Private Person", contact_phone="0800000000")
    login(client, admin)
    feature = client.get(API).get_json()["advertisements"][0]
    assert set(feature) == {
        "id", "code", "title", "category", "advertiser", "address", "city", "state", "lat", "lng",
        "approval_status", "approval_label", "permit_condition", "permit_label", "permit_expiry",
        "photo_url", "detail_url",
    }
    raw = client.get(API).get_data(as_text=True)
    for secret in ("Private Person", "0800000000", staff.email, "password"):
        assert secret not in raw


def test_api_filters(client, admin, staff):
    today = date.today()
    lagos = make_ad(staff, title="Lagos Approved", approval_status="approved", city="Ikeja", lga="Ikeja",
                    permit_number="P", permit_expiry_date=today - timedelta(days=1))
    abuja = make_ad(staff, title="Abuja LED", state_or_territory="Federal Capital Territory (FCT), Abuja",
                    city="Garki", lga="AMAC", latitude=9.03, longitude=7.49,
                    category_id=category_id("Digital LED billboard"))
    login(client, admin)
    assert _codes(client.get(API + "?state=Lagos")) == {lagos.advertisement_code}
    assert _codes(client.get(API + "?city=garki")) == {abuja.advertisement_code}
    assert _codes(client.get(API + "?lga=amac")) == {abuja.advertisement_code}
    assert _codes(client.get(API + f"?category={category_id('Digital LED billboard')}")) == {abuja.advertisement_code}
    assert _codes(client.get(API + "?approval_status=approved")) == {lagos.advertisement_code}
    assert _codes(client.get(API + "?approval_status=pending")) == {abuja.advertisement_code}
    assert _codes(client.get(API + "?permit_condition=expired")) == {lagos.advertisement_code}
    assert _codes(client.get(API + "?q=LED")) == {abuja.advertisement_code}
    # Invalid filter values are ignored rather than erroring.
    assert len(_codes(client.get(API + "?approval_status=bogus&category=abc"))) == 2


def test_api_bounds_filtering(client, admin):
    lagos = make_ad(admin, latitude=6.6, longitude=3.35)
    make_ad(admin, latitude=12.0, longitude=8.52)  # Kano
    login(client, admin)
    assert _codes(client.get(API + "?bbox=6.0,3.0,7.0,4.0")) == {lagos.advertisement_code}
    assert len(_codes(client.get(API + "?bbox=not,a,valid,box"))) == 2


def test_marker_status_fields_keep_approval_and_permit_separate(client, admin):
    make_ad(admin, approval_status="approved", permit_number="P",
            permit_expiry_date=date.today() - timedelta(days=10))
    login(client, admin)
    feature = client.get(API).get_json()["advertisements"][0]
    assert feature["approval_status"] == "approved"
    assert feature["permit_condition"] == "expired"


def test_archived_advertisements_are_not_on_map(client, admin):
    ad = make_ad(admin, is_archived=True)
    login(client, admin)
    assert ad.advertisement_code not in _codes(client.get(API))


def test_inspector_map_shows_only_assigned_advertisements(client, admin, inspector):
    assigned = make_ad(admin)
    make_ad(admin)
    db.session.add(InspectionAssignment(advertisement=assigned, inspector=inspector, assigned_by=admin))
    db.session.commit()
    login(client, inspector)
    assert _codes(client.get(API)) == {assigned.advertisement_code}
