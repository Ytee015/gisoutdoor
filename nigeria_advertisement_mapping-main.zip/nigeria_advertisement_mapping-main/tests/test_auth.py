"""Authentication, registration, roles and CSRF."""

from sqlalchemy import select

from app import create_app
from app.extensions import db
from app.models import ROLE_ADMIN, ROLE_STAFF, User

from .conftest import PASSWORD, login, logout, make_user


def _register(client, **overrides):
    data = {
        "full_name": "New Staffer",
        "email": "new.staff@example.com",
        "organization": "Billboards Nigeria Ltd",
        "phone": "08030000000",
        "password": PASSWORD,
        "confirm_password": PASSWORD,
    }
    data.update(overrides)
    return client.post("/auth/register", data=data)


def test_registration_creates_staff_account_with_hashed_password(client, app):
    response = _register(client)
    assert response.status_code == 302
    user = db.session.scalar(select(User).where(User.email == "new.staff@example.com"))
    assert user is not None
    assert user.role == ROLE_STAFF
    assert user.password_hash != PASSWORD
    assert user.password_hash.startswith(("scrypt:", "pbkdf2:"))
    assert user.check_password(PASSWORD)


def test_registration_ignores_injected_role_field(client, app):
    _register(client, role=ROLE_ADMIN, email="sneaky@example.com")
    user = db.session.scalar(select(User).where(User.email == "sneaky@example.com"))
    assert user.role == ROLE_STAFF


def test_first_registrant_is_not_made_administrator(client, app):
    assert db.session.scalar(select(User)) is None
    _register(client, email="first@example.com")
    assert db.session.scalar(select(User).where(User.email == "first@example.com")).role == ROLE_STAFF


def test_registration_rejects_duplicate_email_case_insensitively(client, staff):
    response = _register(client, email="STAFF@example.com")
    assert response.status_code == 200
    assert "already exists" in response.get_data(as_text=True)


def test_registration_rejects_weak_password(client, app):
    response = _register(client, password="short", confirm_password="short")
    assert response.status_code == 200
    assert "at least 8 characters" in response.get_data(as_text=True)


def test_login_and_logout(client, staff):
    response = login(client, staff)
    assert response.status_code == 302
    assert client.get("/dashboard").status_code == 200
    logout(client)
    response = client.get("/dashboard")
    assert response.status_code == 302
    assert "/auth/login" in response.headers["Location"]


def test_login_rejects_wrong_password(client, staff):
    response = login(client, staff, password="WrongPass1")
    assert response.status_code == 200
    assert "Invalid email address or password" in response.get_data(as_text=True)


def test_deactivated_user_cannot_log_in(client, app):
    user = make_user(ROLE_STAFF, "gone@example.com", is_active=False)
    response = login(client, user)
    assert response.status_code == 200
    assert "deactivated" in response.get_data(as_text=True)


def test_deactivating_logged_in_user_ends_their_access(client, staff):
    login(client, staff)
    staff.is_active = False
    db.session.commit()
    assert client.get("/dashboard").status_code == 302


def test_login_redirects_only_to_safe_next_url(client, staff):
    response = client.post("/auth/login?next=https://evil.example.com/",
                           data={"email": staff.email, "password": PASSWORD})
    assert response.headers["Location"].endswith("/dashboard")
    logout(client)
    response = client.post("/auth/login?next=/advertisements/",
                           data={"email": staff.email, "password": PASSWORD})
    assert response.headers["Location"].endswith("/advertisements/")


def test_private_pages_require_login(client, app):
    for url in ["/dashboard", "/advertisements/", "/map/", "/reports/", "/admin/users",
                "/inspections/dashboard", "/auth/profile"]:
        response = client.get(url)
        assert response.status_code == 302, url
        assert "/auth/login" in response.headers["Location"]


def test_staff_cannot_access_administrator_functions(client, staff):
    login(client, staff)
    for url in ["/admin/users", "/admin/categories", "/admin/authorities", "/admin/locations",
                "/admin/activity", "/advertisements/review-queue", "/advertisements/permits",
                "/inspections/manage", "/inspections/manage/assign"]:
        assert client.get(url).status_code == 403, url
    assert client.post("/admin/users/new", data={"email": "x@example.com"}).status_code == 403


def test_administrator_can_access_administration(client, admin):
    login(client, admin)
    for url in ["/admin/users", "/admin/categories", "/admin/authorities", "/admin/locations",
                "/admin/activity", "/advertisements/review-queue", "/advertisements/permits"]:
        assert client.get(url).status_code == 200, url


def test_profile_update_cannot_change_role(client, staff):
    login(client, staff)
    response = client.post("/auth/profile", data={
        "profile-full_name": "Sam Updated", "profile-organization": "", "profile-phone": "",
        "profile-submit": "Save profile", "role": ROLE_ADMIN,
    })
    assert response.status_code == 302
    db.session.refresh(staff)
    assert staff.full_name == "Sam Updated"
    assert staff.role == ROLE_STAFF


def test_password_change_requires_current_password(client, staff):
    login(client, staff)
    response = client.post("/auth/profile", data={
        "password-current_password": "WrongPass1", "password-new_password": "NewPassw0rd",
        "password-confirm_password": "NewPassw0rd", "password-submit_password": "Change password",
    })
    assert "incorrect" in response.get_data(as_text=True)
    client.post("/auth/profile", data={
        "password-current_password": PASSWORD, "password-new_password": "NewPassw0rd",
        "password-confirm_password": "NewPassw0rd", "password-submit_password": "Change password",
    })
    db.session.refresh(staff)
    assert staff.check_password("NewPassw0rd")


def test_logout_requires_post(client, staff):
    login(client, staff)
    assert client.get("/auth/logout").status_code == 405


def test_csrf_protection_rejects_forms_without_token(tmp_path):
    app = create_app("testing", config_overrides={
        "WTF_CSRF_ENABLED": True, "UPLOAD_FOLDER": str(tmp_path / "uploads"),
    })
    with app.app_context():
        db.create_all()
        response = app.test_client().post("/auth/register", data={
            "full_name": "No Token", "email": "notoken@example.com",
            "password": PASSWORD, "confirm_password": PASSWORD,
        })
        assert response.status_code == 400
        assert db.session.scalar(select(User)) is None
        db.drop_all()


def test_create_admin_cli(app):
    runner = app.test_cli_runner()
    result = runner.invoke(args=["create-admin", "--email", "Boss@Example.com", "--full-name", "Big Boss",
                                 "--password", PASSWORD])
    assert result.exit_code == 0, result.output
    user = db.session.scalar(select(User).where(User.email == "boss@example.com"))
    assert user.role == ROLE_ADMIN and user.check_password(PASSWORD)

    duplicate = runner.invoke(args=["create-admin", "--email", "boss@example.com", "--full-name", "X",
                                    "--password", PASSWORD])
    assert duplicate.exit_code != 0 and "already exists" in duplicate.output

    weak = runner.invoke(args=["create-admin", "--email", "weak@example.com", "--full-name", "Weak",
                               "--password", "abc"])
    assert weak.exit_code != 0
    assert db.session.scalar(select(User).where(User.email == "weak@example.com")) is None


def test_seed_reference_data_is_idempotent(app):
    from app.cli import seed_reference_data
    from app.models import AdvertisementCategory, StateOrTerritory

    assert seed_reference_data() == {"states": 0, "categories": 0, "authorities": 0}
    states = db.session.scalars(select(StateOrTerritory)).all()
    assert len(states) == 37
    fct = [s for s in states if s.is_territory]
    assert len(fct) == 1 and "Federal Capital Territory" in fct[0].name
    assert len(db.session.scalars(select(AdvertisementCategory)).all()) == 14
