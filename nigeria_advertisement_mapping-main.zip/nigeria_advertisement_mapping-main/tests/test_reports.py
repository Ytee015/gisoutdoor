"""Reports page, CSV and PDF exports, and report access control."""

import csv
import io
from datetime import date, timedelta

from .conftest import ad_form_data, image_file, login, make_ad


def _csv_rows(response):
    assert response.status_code == 200
    assert response.mimetype == "text/csv"
    text = response.get_data(as_text=True)
    assert text.startswith("﻿")
    return list(csv.reader(io.StringIO(text.lstrip("﻿"))))


def test_reports_page_shows_summary_and_grouping(client, admin, staff):
    make_ad(staff, state_or_territory="Lagos")
    make_ad(staff, state_or_territory="Kano", latitude=12.0, longitude=8.5)
    login(client, admin)
    body = client.get("/reports/?group=state").get_data(as_text=True)
    assert "Total advertisements" in body
    assert "By state / territory" in body
    assert "Kano" in body and "Lagos" in body


def test_csv_export_contains_filtered_real_records(client, admin, staff):
    lagos = make_ad(staff, title="Lagos Board")
    make_ad(staff, title="Kano Board", state_or_territory="Kano", latitude=12.0, longitude=8.5)
    login(client, admin)
    rows = _csv_rows(client.get("/reports/export.csv?state=Lagos"))
    header, data = rows[0], rows[1:]
    assert header[0] == "Advertisement code" and "Permit condition (calculated today)" in header
    assert [row[0] for row in data] == [lagos.advertisement_code]
    assert "Submitted by" in header  # admins see the submitter


def test_csv_neutralises_formula_injection(client, admin):
    make_ad(admin, title="=HYPERLINK(\"http://evil\",\"x\")", advertiser_name="+cmd|calc")
    login(client, admin)
    data = _csv_rows(client.get("/reports/export.csv"))[1]
    assert data[1].startswith("'=")
    assert data[3].startswith("'+")


def test_staff_reports_include_only_their_records(client, staff, staff2):
    mine = make_ad(staff)
    make_ad(staff2)
    login(client, staff)
    rows = _csv_rows(client.get("/reports/export.csv"))
    assert [row[0] for row in rows[1:]] == [mine.advertisement_code]
    assert "Submitted by" not in rows[0]


def test_preset_reports(client, admin):
    today = date.today()
    expired = make_ad(admin, permit_number="E", permit_expiry_date=today - timedelta(days=1))
    soon = make_ad(admin, permit_number="S", permit_expiry_date=today + timedelta(days=5))
    missing = make_ad(admin)
    login(client, admin)
    assert [r[0] for r in _csv_rows(client.get("/reports/export.csv?permit_condition=expired"))[1:]] == [expired.advertisement_code]
    assert [r[0] for r in _csv_rows(client.get("/reports/export.csv?permit_condition=expiring_soon"))[1:]] == [soon.advertisement_code]
    assert [r[0] for r in _csv_rows(client.get("/reports/export.csv?permit_condition=missing"))[1:]] == [missing.advertisement_code]
    assert len(_csv_rows(client.get("/reports/export.csv?photo=without"))) == 4


def test_date_range_report(client, admin):
    ad = make_ad(admin)
    login(client, admin)
    today = date.today().isoformat()
    assert len(_csv_rows(client.get(f"/reports/export.csv?date_from={today}&date_to={today}"))) == 2
    past = (date.today() - timedelta(days=30)).isoformat()
    assert len(_csv_rows(client.get(f"/reports/export.csv?date_to={past}"))) == 1
    assert ad


def test_pdf_export(client, admin, staff):
    make_ad(staff, title="Very long title " * 12, full_address="A long address " * 10)
    login(client, admin)
    response = client.get("/reports/export.pdf?group=category")
    assert response.status_code == 200
    assert response.mimetype == "application/pdf"
    assert response.data.startswith(b"%PDF")
    assert "attachment" in response.headers["Content-Disposition"]


def test_pdf_export_with_photo_thumbnails(client, admin, staff):
    login(client, staff)
    data = ad_form_data(photograph=image_file())
    client.post("/advertisements/new", data=data, content_type="multipart/form-data")
    client.post("/auth/logout")
    login(client, admin)
    response = client.get("/reports/export.pdf?photos=1")
    assert response.status_code == 200 and response.data.startswith(b"%PDF")
    assert b"/Subtype /Image" in response.data


def test_empty_pdf_report(client, admin):
    login(client, admin)
    response = client.get("/reports/export.pdf")
    assert response.status_code == 200 and response.data.startswith(b"%PDF")


def test_unauthorized_report_access_is_blocked(client, inspector):
    for url in ["/reports/", "/reports/export.csv", "/reports/export.pdf"]:
        assert client.get(url).status_code == 302  # anonymous -> login
    login(client, inspector)
    for url in ["/reports/", "/reports/export.csv", "/reports/export.pdf"]:
        assert client.get(url).status_code == 403
