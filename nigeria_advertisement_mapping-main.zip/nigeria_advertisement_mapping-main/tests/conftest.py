import io
from datetime import date, timedelta

import pytest
from PIL import Image
from sqlalchemy import select

from app import create_app
from app.cli import seed_reference_data
from app.extensions import db as _db
from app.models import (
    ROLE_ADMIN,
    ROLE_INSPECTOR,
    ROLE_STAFF,
    Advertisement,
    AdvertisementCategory,
    User,
)
from app.services import generate_advertisement_code

PASSWORD = "Passw0rd123"


@pytest.fixture
def app(tmp_path):
    """Application bound to a separate in-memory database and temp uploads."""
    app = create_app(
        "testing",
        config_overrides={"UPLOAD_FOLDER": str(tmp_path / "uploads")},
    )
    with app.app_context():
        _db.create_all()
        seed_reference_data()
        yield app
        _db.session.remove()
        _db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def db(app):
    return _db


def make_user(role, email, full_name=None, password=PASSWORD, **extra):
    user = User(full_name=full_name or email.split("@")[0].title(), email=email, role=role, **extra)
    user.set_password(password)
    _db.session.add(user)
    _db.session.commit()
    return user


@pytest.fixture
def admin(app):
    return make_user(ROLE_ADMIN, "admin@example.com", "Ada Admin")


@pytest.fixture
def staff(app):
    return make_user(ROLE_STAFF, "staff@example.com", "Sam Staff")


@pytest.fixture
def staff2(app):
    return make_user(ROLE_STAFF, "other.staff@example.com", "Olu Other")


@pytest.fixture
def inspector(app):
    return make_user(ROLE_INSPECTOR, "inspector@example.com", "Ife Inspector")


@pytest.fixture
def inspector2(app):
    return make_user(ROLE_INSPECTOR, "inspector2@example.com", "Bola Inspector")


def login(client, user_or_email, password=PASSWORD):
    email = user_or_email if isinstance(user_or_email, str) else user_or_email.email
    return client.post("/auth/login", data={"email": email, "password": password})


def logout(client):
    return client.post("/auth/logout")


def image_file(fmt="JPEG", name=None, size=(80, 60), colour=(30, 120, 200)):
    """A real, decodable image in memory (no stock photos involved)."""
    buffer = io.BytesIO()
    Image.new("RGB", size, colour).save(buffer, format=fmt)
    buffer.seek(0)
    extension = {"JPEG": "jpg", "PNG": "png", "WEBP": "webp"}[fmt]
    return buffer, name or f"billboard.{extension}"


def category_id(name="Large roadside billboard"):
    return _db.session.scalar(select(AdvertisementCategory.id).where(AdvertisementCategory.name == name))


def ad_form_data(**overrides):
    data = {
        "title": "Ikorodu Road Gantry",
        "description": "Double-sided gantry billboard.",
        "category_id": str(category_id()),
        "advertiser_name": "Acme Beverages Ltd",
        "contact_person": "Chidi Okafor",
        "contact_phone": "+234 803 000 0000",
        "state_or_territory": "Lagos",
        "city": "Ikeja",
        "lga": "Ikeja",
        "street_or_road": "Ikorodu Road",
        "full_address": "12 Ikorodu Road, Ikeja, Lagos",
        "landmark": "Opposite the filling station",
        "latitude": "6.5966",
        "longitude": "3.3421",
        "advertisement_type": "static",
        "width": "12",
        "height": "4",
        "installation_date": "2025-01-15",
        "condition": "good",
        "permit_number": "LASAA/2025/001",
        "regulatory_authority_id": "0",
        "permit_issue_date": "2025-01-01",
        "permit_expiry_date": (date.today() + timedelta(days=200)).isoformat(),
        "permit_verification_status": "unverified",
    }
    data.update(overrides)
    return data


def make_ad(submitted_by, **overrides):
    """Create an advertisement directly (bypassing the form) for test setup."""
    values = {
        "title": "Test Billboard",
        "category_id": category_id(),
        "advertiser_name": "Test Advertiser",
        "state_or_territory": "Lagos",
        "city": "Ikeja",
        "lga": "Ikeja",
        "full_address": "1 Test Street, Ikeja",
        "latitude": 6.6,
        "longitude": 3.35,
        "advertisement_type": "static",
        "condition": "good",
        "approval_status": "pending",
    }
    values.update(overrides)
    ad = Advertisement(submitted_by=submitted_by, advertisement_code=generate_advertisement_code(), **values)
    _db.session.add(ad)
    _db.session.commit()
    return ad
